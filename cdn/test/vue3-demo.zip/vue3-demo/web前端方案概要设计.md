# Web 前端方案概要设计

| 项 | 内容 |
| --- | --- |
| 项目名称 | Vue3 Admin Lab（vue3-admin-lab） |
| 文档类型 | Web 前端方案概要设计 |
| 版本 | V1.0.0 |
| 编制依据 | 当前仓库已落地实现 |
| 适用阶段 | 概要设计 / 开发对照 / 联调说明 |
| 技术栈 | Vue 3 + TypeScript + Vite + Vue Router + Pinia + Element Plus + Axios |

---

## 1. 文档目的与范围

### 1.1 目的

本文描述本后台管理系统的前端总体方案：目标、架构分层、模块划分、关键流程、接口约定、工程化规范，以及与现有代码的对应关系。供开发对照实现、联调对接和后续扩展使用。

### 1.2 范围

包含：

- 系统定位与建设目标
- 总体架构与目录分层
- 路由鉴权、状态管理、HTTP、WebSocket、UI 反馈
- 页面功能概要与 Vue3 知识点覆盖
- 多环境、Mock、构建与提交规范
- 非功能要求、约束与后续演进

不包含：后端详细设计、数据库设计、运维发布流水线细则。

### 1.3 读者

前端开发、全栈开发、测试、需要了解前端边界的后端联调人员。

---

## 2. 系统概述

### 2.1 定位

本系统是一套**页面精简、能力完整**的管理后台前端。业务页面只覆盖登录、工作台、用户 CRUD、实时通道和环境配置；同时用「Vue3 实验室」把组合式 API、生命周期、内置组件等知识点放进真实后台结构中，避免 Demo 与工程实践脱节。

### 2.2 建设目标

| 编号 | 目标 | 落地方式 |
| --- | --- | --- |
| G1 | Vue3 + TypeScript 工程可运行、可构建 | Vite 8 + `vue-tsc -b` |
| G2 | 中后台 UI 组件体系 | Element Plus（Vue3 对应库，替代 Vue2 的 Element UI） |
| G3 | 多环境可切换，Mock 可配置开关 | `.env.*` + `VITE_USE_MOCK` / `VITE_WS_MOCK` |
| G4 | HTTP 统一封装 | Axios 实例、拦截器、`http` 方法集 |
| G5 | WebSocket 生命周期、心跳、重连 | `AppWebSocket` |
| G6 | 行业通用状态管理 | Pinia + 持久化插件 |
| G7 | 公告 / Loading / Toast / 确认框统一入口 | `src/utils/feedback.ts` |
| G8 | 代码风格统一 | ESLint Flat + Prettier + EditorConfig |
| G9 | 提交可拦截 | Husky + lint-staged + Commitlint |
| G10 | 可自学可交接 | `README.md` 与本文档 |

### 2.3 角色与试用账号

当前 Mock 仅内置超级管理员：

- 账号：`admin`
- 密码：`123456`
- 角色：`admin`
- Token：`mock-token-admin`（Mock 环境）

按钮级权限通过指令 `v-permission` 按角色数组判断，例如「新建用户」仅 `admin` 可见。

---

## 3. 总体架构

### 3.1 逻辑分层

```text
┌─────────────────────────────────────────────┐
│  视图层  views / layouts / components       │
│  指令、插槽、KeepAlive、页面交互             │
├─────────────────────────────────────────────┤
│  组合层  composables                        │
│  useTable / useLifecycleLogger / useWebSocket│
├─────────────────────────────────────────────┤
│  状态层  Pinia stores                       │
│  user（鉴权） app（布局/环境） realtime（WS）│
├─────────────────────────────────────────────┤
│  领域 API  src/api                          │
│  只描述资源路径与类型，不操作 DOM            │
├─────────────────────────────────────────────┤
│  基础设施                                  │
│  request.ts  websocket.ts  feedback.ts      │
│  auth.ts  env.ts  mock adapter              │
└─────────────────────────────────────────────┘
         │                      │
         ▼                      ▼
   HTTP（Axios/Mock）     WS（真实/MockWebSocket）
```

约束：

- 页面不直接拼 URL、不直接 `new WebSocket`
- API 模块不引用 Element Plus
- Mock 只替换传输层（Axios adapter / MockWebSocket），业务代码路径不变

### 3.2 运行时装配

入口 `src/main.ts` 装配顺序：

1. 创建应用与 Pinia，注册 `pinia-plugin-persistedstate`
2. 全局注册 Element Plus 图标
3. `app.use(pinia)` → `app.use(router)` → `app.use(ElementPlus, { locale: zhCn })`
4. `setupDirectives` 注册 `v-focus` / `v-copy` / `v-permission`
5. 挂载 `#app`

`App.vue` 仅渲染根 `router-view`，布局由路由嵌套的 `AdminLayout` 承担。

### 3.3 构建与开发服务

- 构建工具：Vite，开发端口 `5173`
- 路径别名：`@` → `src/`
- 按需能力：`unplugin-auto-import` / `unplugin-vue-components` + `ElementPlusResolver`
- `VITE_USE_MOCK=false` 时，开发服务器将 `/api` 代理到 `VITE_PROXY_TARGET`

---

## 4. 技术选型说明

| 类别 | 选型 | 说明 |
| --- | --- | --- |
| 框架 | Vue 3.5（Composition API + `<script setup>`） | 与生命周期、KeepAlive 演示一致 |
| 语言 | TypeScript 6.x | `vue-tsc` 参与 `build` |
| 路由 | Vue Router 5，History 模式 | `createWebHistory()` |
| 状态 | Pinia 4 | Vue3 官方推荐，替代 Vuex |
| UI | Element Plus | Vue3 中后台事实标准 |
| HTTP | Axios 1 | 自定义 adapter 接入 Mock |
| 实时 | 自研 `AppWebSocket` | 不引入额外 WS 库，便于学习实现 |
| 样式 | 全局 SCSS + 组件 scoped | `src/styles/index.scss` |
| 包管理 | npm | `type: module` |

---

## 5. 目录与模块划分

```text
src/
  api/                 接口声明（auth / user / dashboard）
  composables/         可复用组合函数
  components/          实验室演示组件（非业务组件库）
  directives/          自定义指令
  layouts/             后台壳：侧栏 + 顶栏 + 内容区
  mock/                HTTP Mock 适配器与假数据
  router/              路由表与前置守卫
  stores/              Pinia
  styles/              全局样式变量与基础重置
  types/               插件生成的组件/自动导入类型
  utils/               请求、WS、反馈、环境、Token
  views/               按业务域拆分的页面
  main.ts              应用入口
  App.vue              根视图
  env.d.ts             ImportMetaEnv 类型
```

模块边界：

| 模块 | 职责 | 主要文件 |
| --- | --- | --- |
| 认证 | 登录、登出、Token、路由拦截 | `stores/user.ts` `utils/auth.ts` `router/index.ts` |
| 系统用户 | 分页查询与增删改 | `views/system/user` `api/user.ts` |
| 工作台 | 概览指标、生命周期日志 | `views/dashboard` `api/dashboard.ts` |
| 实时通道 | 连接控制与指标展示 | `views/realtime` `stores/realtime.ts` |
| 环境与反馈 | 环境变量展示、反馈组件演示 | `views/settings` `utils/env.ts` `utils/feedback.ts` |
| 教学实验室 | Vue3 API 集中演示 | `views/learn` `components/*` |

---

## 6. 路由与信息架构

### 6.1 路由表

| 路径 | name | 标题 | 公开 | KeepAlive | 说明 |
| --- | --- | --- | --- | --- | --- |
| `/login` | Login | 登录 | 是 | 否 | 无布局 |
| `/` | — | — | 否 | — | `AdminLayout`，重定向 `/dashboard` |
| `/dashboard` | Dashboard | 工作台 | 否 | 是 | 组件名 `Dashboard` |
| `/system/user` | SystemUser | 用户管理 | 否 | 否 | CRUD |
| `/learn` | Learn | Vue3 实验室 | 否 | 是 | 组件名 `LearnLab` |
| `/realtime` | Realtime | 实时通道 | 否 | 否 | 进入连接、离开断开 |
| `/settings` | Settings | 环境设置 | 否 | 否 | 环境与反馈 |
| `*` | NotFound | 404 | 是 | 否 | 兜底 |

### 6.2 导航守卫

`router.beforeEach`：

1. 设置 `document.title` 为 `{meta.title} - Vue3 Admin Lab`
2. `meta.public === true` 直接放行
3. 无 Token 则跳转 `/login?redirect={fullPath}`
4. 其余放行

登录成功后优先回到 `redirect`，默认 `/dashboard`。

### 6.3 布局与缓存策略

`AdminLayout`：

- 左侧菜单（可折叠 220px / 72px）
- 顶栏：折叠按钮、面包屑、环境标签、MOCK 标签、用户下拉
- 内容区双通道渲染：
  - `meta.keepAlive` 为真：进入 `<keep-alive include="Dashboard,LearnLab">`
  - 否则直接渲染，避免非缓存页被 KeepAlive 卡住

侧栏当前为静态菜单，与路由表保持一致；后续若做动态权限菜单，应以路由 `meta` + 角色生成，而不是再写一份硬编码。

---

## 7. 状态管理设计

采用 Pinia Setup Store。

### 7.1 user

- 状态：`token` `username` `nickname` `roles`
- 计算：`isLogin` `isAdmin`
- 动作：`login` `fetchProfile` `logout`
- 持久化：`persist.pick` 上述四字段（插件写入本地，刷新后恢复）
- Token 另存 `localStorage` 键 `vue3_admin_token`，供路由守卫在 Pinia 水合前读取

### 7.2 app

- 侧栏折叠
- 生命周期日志（最多 40 条，供工作台展示）
- 环境文案（development / staging / production）
- 暴露 `envConfig` 给顶栏 MOCK / 环境 Tag

### 7.3 realtime

- 封装 `AppWebSocket` 实例
- 维护 `status`、`metrics`、`logs`
- 页面 `onUnmounted` 时 `disconnect`，避免路由切换后连接泄漏

原则：跨页面共享、需要持久化或长连接的状态进 Store；一次性表格查询留在页面 / `useTable`。

---

## 8. HTTP 与接口约定

### 8.1 统一响应体

```ts
interface ApiResult<T> {
  code: number    // 0 成功，非 0 业务失败
  message: string
  data: T
}
```

分页：

```ts
interface PageQuery { page: number; pageSize: number; keyword?: string }
interface PageResult<T> { list: T[]; total: number }
```

### 8.2 Axios 封装（`src/utils/request.ts`）

| 项 | 设计 |
| --- | --- |
| baseURL | `VITE_API_BASE_URL` |
| timeout | 15000 ms |
| Mock | `VITE_USE_MOCK=true` 时使用 `mockAdapter` |
| 请求头 | 有 Token 则 `Authorization: Bearer {token}` |
| loading | `config.loading === true` 时调用全局 Loading（计数防闪断） |
| 业务码 | `code !== 0` toast 后 `reject` |
| HTTP 401 | 清 Token，toast，跳转 `/login` |
| silent | 关闭自动 toast |
| 返回值 | 拦截器把 `response.data` 换成业务 `data`，`http.*` 直接得到 T |

对外方法：`http.get/post/put/delete`。

### 8.3 接口清单（与 Mock / 联调对齐）

| 方法 | 路径 | 说明 | 调用方 |
| --- | --- | --- | --- |
| POST | `/auth/login` | 登录，返回 token + user | `api/auth.ts` |
| GET | `/auth/profile` | 当前用户 | `api/auth.ts` |
| POST | `/auth/logout` | 登出 | `api/auth.ts` |
| GET | `/users` | 分页列表，query：page、pageSize、keyword | `api/user.ts` |
| POST | `/users` | 新建 | `api/user.ts` |
| PUT | `/users` | 更新（body 含 id） | `api/user.ts` |
| DELETE | `/users` | 删除，query：id | `api/user.ts` |
| GET | `/dashboard/overview` | 访问量、用户数、消息、转化率、7 日趋势 | `api/dashboard.ts` |

对接真实后端时：关闭 Mock，保持上述路径或在 `src/api` 统一改前缀，**不要在页面里改 URL**。

### 8.4 Mock 方案

- 实现：Axios 自定义 adapter，按 `` `${method} ${pathname}` `` 分发
- 数据：`src/mock/modules.ts`，Mock.js 生成用户，写入内存数组（刷新页面重置）
- 延迟：约 280ms，便于观察 Loading
- 登录校验：仅 `admin / 123456`
- 未知接口：返回 `code=404`，文案带上未匹配的 key

与「开发代理 Mock 服务」相比，adapter 方案不依赖 Vite 中间件版本，开发和预览只要环境变量打开即可走同一套假数据。

---

## 9. WebSocket 方案

### 9.1 协议形态

应用层消息统一 JSON：

```ts
interface WsMessage<T = unknown> {
  event: string
  data: T
  ts: number
}
```

内置事件：

| event | 方向 | 含义 |
| --- | --- | --- |
| ping / pong | 客户端 ↔ 服务端 | 心跳 |
| metrics | 服务端 → 客户端 | 在线、QPS、延迟（Mock 每 2s 推送） |
| client-hello | 客户端 → 服务端 | 页面演示发送 |
| status / open / close / error / reconnecting / heartbeat-timeout / reconnect-failed | 客户端内部 | `AppWebSocket` 生命周期 |

### 9.2 连接状态机

`idle → connecting → open → closing → closed`

异常或心跳超时：`closed → reconnecting → connecting → open`

参数默认值：

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| heartbeatInterval | 15000 ms | 发送 ping 周期 |
| heartbeatTimeout | 8000 ms | 未收到 pong 则主动 close |
| reconnect | true | 非手动断开才重连 |
| reconnectInterval | 2000 ms | 基数，实际等待 = 基数 × 次数 |
| maxReconnect | 8 | 超过触发 `reconnect-failed` |

手动 `disconnect()` 置 `manualClose`，禁止自动重连。

### 9.3 Mock WebSocket

`VITE_WS_MOCK=true` 时使用内存 `MockWebSocket`，接口对齐浏览器 `WebSocket`（`readyState`、`onopen/onmessage/onclose/onerror`、`send/close`）。无真实端口，学习心跳与重连不必起 WS 服务。

### 9.4 页面策略

`/realtime` 进入即 `connect()`，卸载即 `disconnect()`。指标与日志写入 `useRealtimeStore`，便于后续其他页复用同一通道。

---

## 10. UI 与反馈组件

### 10.1 统一反馈（`src/utils/feedback.ts`）

| 能力 | 实现 | 用途 |
| --- | --- | --- |
| toast | `ElMessage`（grouping） | 操作结果、校验失败、接口错误 |
| notify | `ElNotification` | 公告类、非阻断提示 |
| loading | `ElLoading.service` + 引用计数 | 登录、保存、删除等 |
| confirm | `ElMessageBox.confirm` | 删除、退出登录 |
| alert | `ElMessageBox.alert` | 说明性阻断 |

禁止页面直接调用 `ElMessage` 散落配置，以便后续换主题或接入埋点。

### 10.2 视觉基调

CSS 变量（`src/styles/index.scss`）：

- 侧栏 `#0f172a`
- 主色 `#2563eb`
- 内容底 `#f3f5f9`

布局为经典中后台：深色侧栏 + 白顶栏 + 卡片内容。

### 10.3 自定义指令

| 指令 | 行为 |
| --- | --- |
| `v-focus` | `mounted` 时聚焦 |
| `v-copy` | 点击复制绑定值或元素文本 |
| `v-permission="['admin']"` | 无角色则从 DOM 移除 |

权限指令为一次性挂载判断，角色中途变化不会自动恢复节点；若后续做动态切角色，需改为 `updated` 或基于 `v-if` 的组件方案。

---

## 11. 页面功能概要

### 11.1 登录

- Element Plus 表单校验
- 调用 `userStore.login`
- 成功 toast 后 `router.replace(redirect)`
- 演示 `reactive`、表单 ref、异步按钮 loading

### 11.2 工作台

- 请求概览接口，四卡片 + CSS 柱状趋势
- `useLifecycleLogger` 写入 app Store
- `watch(tick)` 演示更新钩子
- KeepAlive：切走再回走 `onActivated`，避免重复 `onMounted` 误解

### 11.3 用户管理

- `useTable`：`onMounted` 拉数、分页、关键词搜索
- 新建 / 编辑对话框、删除 confirm
- `v-permission` 控制新建按钮

### 11.4 Vue3 实验室

分 Tab 覆盖：

- 响应式：`ref` `reactive` `computed` `toRef` `toRefs` `readonly` `shallowRef` `customRef` `watch` `watchEffect`
- 生命周期与组合函数：挂载卸载、`useCountdown`
- provide/inject（`InjectionKey`）、默认/具名/作用域插槽、指令、`defineModel`
- Teleport、Transition、KeepAlive、Suspense（异步 `setup`）

组件名必须为 `LearnLab`，与布局 `keep-alive include` 一致。

### 11.5 实时通道 / 环境设置

- 实时通道：连接、发送、断开、状态 Tag、指标卡片、日志
- 环境设置：展示全部 `VITE_*`，按钮触发各类 feedback；作为联调前的配置核对页

---

## 12. 环境与配置设计

全部客户端可见变量必须以 `VITE_` 开头，修改后需重启 Vite。

| 变量 | 含义 |
| --- | --- |
| `VITE_APP_TITLE` | 应用标题 |
| `VITE_APP_ENV` | 业务环境名（development / staging / production） |
| `VITE_API_BASE_URL` | Axios baseURL |
| `VITE_USE_MOCK` | HTTP 是否走 Mock adapter |
| `VITE_PROXY_TARGET` | 关闭 Mock 时的开发代理目标 |
| `VITE_WS_URL` | WebSocket 地址 |
| `VITE_WS_MOCK` | 是否使用 MockWebSocket |

文件：`.env.development` / `.env.staging` / `.env.production` / `.env.example`。

脚本：`npm run dev` | `dev:staging` | `dev:prod` | `build` | `build:staging`。

默认策略：本地 development **开 Mock**；staging / production **关 Mock**，指向真实或预发地址。

---

## 13. 工程化与质量门禁

### 13.1 代码风格

- ESLint Flat Config：`eslint` + `typescript-eslint` + `eslint-plugin-vue` + `eslint-config-prettier`
- Prettier：无分号、单引号、尾逗号、行宽 100
- EditorConfig：UTF-8、LF、2 空格
- VS Code：保存时 format + ESLint fix（`.vscode/settings.json`）

### 13.2 Git 钩子

| 钩子 | 工具 | 行为 |
| --- | --- | --- |
| pre-commit | lint-staged | 仅检查暂存的 `ts/vue`（eslint --fix + prettier）及 `json/md/scss`（prettier） |
| commit-msg | commitlint | `@commitlint/config-conventional` |

提交示例：`feat: 新增用户导出`、`fix: 修复登录过期跳转`。

`prepare: husky` 保证安装依赖后钩子可用。

### 13.3 构建门禁

`npm run build` = `vue-tsc -b` + `vite build`。类型错误不可打包。

---

## 14. 关键流程

### 14.1 登录

```text
输入账号密码
  → 表单校验
  → POST /auth/login（可带全局 Loading）
  → 写入 token 与用户信息（Store + localStorage）
  → 跳转 redirect 或 /dashboard
失败 → toast，停留登录页
```

### 14.2 鉴权访问

```text
进入非 public 路由
  → 无 token：/login?redirect=原路径
  → 有 token：渲染 AdminLayout + 子页
接口 401
  → removeToken + 回登录页
```

### 14.3 用户删除

```text
点击删除 → confirmBox
  → DELETE /users?id=
  → toast 成功 → 刷新表格
取消则中断，不发请求
```

### 14.4 WebSocket

```text
connect
  → connecting
  → open 后启动心跳
  → 周期 ping，超时未 pong 则 close
  → 非手动关闭：按次数递增延迟重连，最多 8 次
disconnect（手动）
  → 清理定时器，不再重连
```

---

## 15. 非功能需求

| 类型 | 要求 |
| --- | --- |
| 可维护 | 分层清晰，页面不直接打 HTTP/WS |
| 可配置 | 环境与 Mock 不改业务代码 |
| 可观测 | 顶栏展示环境与 MOCK；WS 与生命周期有日志 |
| 体验 | 请求超时 15s；Mock 带短延迟；Loading 引用计数 |
| 安全（前端） | Token 存本地，仅作演示；生产需 HTTPS、Cookie/刷新令牌等另案 |
| 兼容 | 现代浏览器（Vite 默认目标）；History 模式需服务端 fallback |
| 国际化 | 当前固定中文（Element Plus `zh-cn`） |

---

## 16. 约束、风险与后续演进

### 16.1 当前约束

- 无后端，数据在 Mock 内存中，刷新即丢失
- 菜单写死，无动态路由、无按钮级后端鉴权
- Token 无刷新机制；401 使用整页跳转
- WS Mock 不校验业务鉴权
- 权限指令不会响应角色的后续变化

### 16.2 风险

| 风险 | 影响 | 缓解 |
| --- | --- | --- |
| 联调路径与 Mock 不一致 | 关 Mock 后大面积 404 | 以第 8.3 节为契约，变更只改 `src/api` |
| History 部署 404 | 刷新子路由失败 | Nginx `try_files` 到 `index.html` |
| KeepAlive 组件名不一致 | 缓存失效或页签卡死 | `defineOptions({ name })` 与 `include` 同步 |
| 生产误开 Mock | 假数据上线 | production 默认 `VITE_USE_MOCK=false`，发布检查环境变量 |

### 16.3 建议演进（不在本期范围）

1. 动态路由 + 菜单由后端权限下发
2. 用户模块类型从 `mock/modules` 抽到 `src/types`
3. 接入真实 WS，心跳字段与后端对齐
4. E2E（Playwright）覆盖登录、用户 CRUD、WS 连接
5. CI：PR 上跑 `lint` + `vue-tsc` + `build`

---

## 17. 与代码的对照索引

| 设计主题 | 代码入口 |
| --- | --- |
| 应用装配 | `src/main.ts` |
| 路由与守卫 | `src/router/index.ts` |
| 后台布局 / KeepAlive | `src/layouts/AdminLayout.vue` |
| HTTP | `src/utils/request.ts` |
| Mock | `src/mock/adapter.ts` `src/mock/modules.ts` |
| WebSocket | `src/utils/websocket.ts` |
| 反馈组件 | `src/utils/feedback.ts` |
| 环境 | `src/utils/env.ts` `.env.*` |
| 状态 | `src/stores/*.ts` |
| 工程化 | `eslint.config.js` `.prettierrc` `.husky/*` `commitlint.config.js` |

开发执行说明（安装、脚本、学习路径）以仓库根目录 `README.md` 为准；**方案与边界以本文为准**。
