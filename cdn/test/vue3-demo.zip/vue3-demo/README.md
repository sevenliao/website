# Vue3 Admin Lab

面向学习的小型后台管理系统。页面不多，但把 **Vue3 全家桶** 和常见工程化能力串进真实后台场景：登录鉴权、CRUD、环境切换、Mock、Axios、WebSocket、Pinia、统一反馈组件。

技术栈：**Vue3 + TypeScript + Vite + Vue Router + Pinia + Element Plus + Axios**。

> 说明：Vue3 生态对应的 UI 库是 **Element Plus**（原 Element UI 只维护 Vue2）。

## 快速开始

```bash
npm install
npm run dev
```

浏览器打开 `http://localhost:5173`。

试用账号：

- 用户名：`admin`
- 密码：`123456`

## 脚本

| 命令                    | 作用                                      |
| ----------------------- | ----------------------------------------- |
| `npm run dev`           | 开发环境，默认开启 Mock                   |
| `npm run dev:staging`   | 预发配置（`VITE_USE_MOCK=false`，走代理） |
| `npm run dev:prod`      | 使用 production 环境变量本地启动          |
| `npm run build`         | 类型检查 + 生产构建                       |
| `npm run build:staging` | 预发包                                    |
| `npm run preview`       | 预览构建产物                              |
| `npm run lint`          | ESLint                                    |
| `npm run lint:fix`      | ESLint 自动修复                           |
| `npm run format`        | Prettier 格式化                           |

## 环境切换与 Mock

环境文件：

- `.env.development`
- `.env.staging`
- `.env.production`
- `.env.example`（模板）

关键变量：

| 变量                | 含义                                                       |
| ------------------- | ---------------------------------------------------------- |
| `VITE_APP_ENV`      | 业务环境名，顶栏会显示                                     |
| `VITE_API_BASE_URL` | Axios `baseURL`                                            |
| `VITE_USE_MOCK`     | `true` 时使用本地 Mock 适配器，不发真实 HTTP               |
| `VITE_PROXY_TARGET` | `VITE_USE_MOCK=false` 时，开发服务器把 `/api` 代理到该地址 |
| `VITE_WS_URL`       | WebSocket 地址                                             |
| `VITE_WS_MOCK`      | `true` 时使用 `MockWebSocket`                              |

开关 Mock：改对应 `.env.*` 中的 `VITE_USE_MOCK` / `VITE_WS_MOCK`，然后用对应 `npm run dev:*` 启动。

Mock 实现：

- HTTP：`src/mock/adapter.ts` 作为 Axios 自定义 adapter
- 数据：`src/mock/modules.ts`（Mock.js 生成用户列表）
- WS：`src/utils/websocket.ts` 内的 `MockWebSocket`

对接真实后端时：

1. 把 `VITE_USE_MOCK`、`VITE_WS_MOCK` 设为 `false`
2. 填写 `VITE_API_BASE_URL` / `VITE_PROXY_TARGET` / `VITE_WS_URL`
3. 保持 `src/api/*` 路径与后端约定一致即可，页面代码不用改

## 目录结构

```text
src/
  api/              接口函数（只描述资源，不处理 UI）
  composables/      组合式函数（表格、生命周期日志、倒计时、WS）
  components/       实验室演示组件（插槽、inject、Suspense、defineModel）
  directives/       自定义指令：v-focus / v-copy / v-permission
  layouts/          后台布局
  mock/             Mock 适配器与假数据
  router/           路由 + 导航守卫
  stores/           Pinia（user / app / realtime）
  styles/           全局样式
  utils/
    request.ts      Axios 封装（token、loading、错误 toast、401）
    websocket.ts    WS 生命周期、心跳、重连
    feedback.ts     toast / notify / loading / confirm / alert
    env.ts          环境变量读取
    auth.ts         token
  views/            页面
```

## 页面与知识点对照

| 页面        | 路由           | 你可以学到                                                                                                                |
| ----------- | -------------- | ------------------------------------------------------------------------------------------------------------------------- |
| 登录        | `/login`       | `reactive`、表单校验、路由 query 跳转、Pinia 登录                                                                         |
| 工作台      | `/dashboard`   | `onMounted`、`onActivated`、`computed`、`watch`、KeepAlive                                                                |
| 用户管理    | `/system/user` | 组合函数 `useTable`、CRUD、`v-model`、权限指令                                                                            |
| Vue3 实验室 | `/learn`       | 响应式全家桶、生命周期、provide/inject、插槽、指令、Teleport、Transition、KeepAlive、Suspense、`defineModel`、`customRef` |
| 实时通道    | `/realtime`    | WebSocket 封装、心跳、重连、Pinia 跨组件状态                                                                              |
| 环境设置    | `/settings`    | 环境变量、Mock 开关、统一反馈组件演示                                                                                     |

### Vue3 生命周期（组合式）

对应 Options API 的映射，演示写在 `src/composables/useLifecycleLogger.ts` 和工作台日志里：

- `setup` 同步执行（替代 `beforeCreate` / `created`）
- `onBeforeMount` / `onMounted`
- `onBeforeUpdate` / `onUpdated`
- `onBeforeUnmount` / `onUnmounted`
- `onActivated` / `onDeactivated`（配合 KeepAlive）

另外可在实验室看到：

- `ref` / `reactive` / `computed` / `watch` / `watchEffect`
- `toRef` / `toRefs` / `shallowRef` / `readonly` / `customRef`
- `provide` / `inject`（带 `InjectionKey`）
- 默认插槽、具名插槽、作用域插槽
- 自定义指令
- `Teleport` / `Transition` / `KeepAlive` / `Suspense`
- 路由懒加载、全局前置守卫
- Pinia 组合式 Store + 持久化

## Axios 封装

文件：`src/utils/request.ts`

- 统一 `code === 0` 才返回 `data`
- 请求头自动带 `Authorization`
- `loading: true` 会调用全局 Loading
- 业务错误走 toast；401 清 token 并回登录
- `silent: true` 可关闭自动 toast

```ts
import { http } from '@/utils/request'

await http.get('/users', { page: 1, pageSize: 10 })
await http.post('/users', payload, { loading: true })
```

## WebSocket 封装

文件：`src/utils/websocket.ts`

- `connect` / `disconnect` / `send`
- 事件：`open` `close` `error` `message` `status` `pong` `reconnecting` `heartbeat-timeout`
- 定时 ping，超时未 pong 则断开并重连
- 重连次数上限 + 递增间隔
- `mock: true` 时走内存模拟通道，并推送 `metrics`

页面用法见 `src/stores/realtime.ts`、`src/views/realtime/index.vue`。

## 统一反馈组件

文件：`src/utils/feedback.ts`

```ts
import { toast, notify, showLoading, hideLoading, confirmBox, alertBox } from '@/utils/feedback'

toast.success('保存成功')
notify.info('系统公告', '内容')
showLoading('加载中')
await confirmBox({ message: '确定删除吗？' })
```

在「环境设置」页可直接点按钮体验。

## 状态管理

使用 **Pinia**（Vue3 官方推荐，替代 Vuex）：

- `stores/user.ts`：登录态、角色、持久化
- `stores/app.ts`：侧栏、环境文案、生命周期日志
- `stores/realtime.ts`：WS 连接与实时指标

## 代码风格与提交规范

公认组合：

- **ESLint Flat Config** + `typescript-eslint` + `eslint-plugin-vue`
- **Prettier**（与 ESLint 通过 `eslint-config-prettier` 去冲突）
- **EditorConfig**
- **Husky** + **lint-staged**：提交前只检查暂存文件
- **Commitlint** + `@commitlint/config-conventional`

提交信息格式：

```text
feat: 新增用户导出
fix: 修复登录过期跳转
docs: 补充 WebSocket 说明
chore: 调整 eslint 规则
```

常用前缀：`feat` `fix` `docs` `style` `refactor` `perf` `test` `chore` `ci` `build` `revert`。

VS Code 建议安装插件见 `.vscode/extensions.json`，并开启保存时格式化（`.vscode/settings.json`）。

## 学习路径建议

1. 从 `src/main.ts` 看应用装配：Router、Pinia、Element Plus、指令。
2. 看 `src/router/index.ts` 的守卫和懒加载。
3. 走一遍登录 → 工作台，对照生命周期日志。
4. 打开「Vue3 实验室」四个 Tab，对着源码改值看响应。
5. 看 `src/utils/request.ts` 和 `src/mock/`，把 `VITE_USE_MOCK` 关掉想象真实联调。
6. 打开「实时通道」，断连/重连，读 `AppWebSocket`。
7. 试一次 `git commit`，体验 lint-staged 与 commitlint。

## 常见问题

**改了 `.env` 没生效？**  
必须重启 Vite。只有以 `VITE_` 开头的变量会暴露给客户端。

**关闭 Mock 后接口 404？**  
需要真实后端或把 `VITE_PROXY_TARGET` 指到可用服务。

**Commit 被拦截？**  
信息需符合 Conventional Commits；代码需通过 ESLint。不要使用 `--no-verify` 跳过（除非你明确知道在做什么）。
