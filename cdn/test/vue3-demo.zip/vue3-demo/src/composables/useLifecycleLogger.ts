import {
  onActivated,
  onBeforeMount,
  onBeforeUnmount,
  onBeforeUpdate,
  onDeactivated,
  onMounted,
  onUnmounted,
  onUpdated,
} from 'vue'
import { useAppStore } from '@/stores/app'

export function useLifecycleLogger(name: string) {
  const appStore = useAppStore()
  const log = (hook: string) => appStore.pushLog(`${name} → ${hook}`)

  onBeforeMount(() => log('onBeforeMount'))
  onMounted(() => log('onMounted'))
  onBeforeUpdate(() => log('onBeforeUpdate'))
  onUpdated(() => log('onUpdated'))
  onBeforeUnmount(() => log('onBeforeUnmount'))
  onUnmounted(() => log('onUnmounted'))
  onActivated(() => log('onActivated'))
  onDeactivated(() => log('onDeactivated'))

  return { log }
}
