import { onMounted, reactive, ref } from 'vue'

interface Pager {
  page: number
  pageSize: number
  keyword: string
}

export function useTable<T>(fetcher: (query: Pager) => Promise<{ list: T[]; total: number }>) {
  const loading = ref(false)
  const list = ref<T[]>([])
  const total = ref(0)
  const query = reactive<Pager>({
    page: 1,
    pageSize: 10,
    keyword: '',
  })

  async function load() {
    loading.value = true
    try {
      const result = await fetcher(query)
      list.value = result.list
      total.value = result.total
    } finally {
      loading.value = false
    }
  }

  function search() {
    query.page = 1
    return load()
  }

  onMounted(load)

  return { loading, list, total, query, load, search }
}
