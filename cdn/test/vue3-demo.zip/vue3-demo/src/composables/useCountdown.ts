import { onUnmounted, ref } from 'vue'

export function useCountdown(seconds = 5) {
  const remain = ref(seconds)
  const running = ref(false)
  let timer: number | null = null

  function start() {
    remain.value = seconds
    running.value = true
    timer = window.setInterval(() => {
      remain.value -= 1
      if (remain.value <= 0) {
        stop()
      }
    }, 1000)
  }

  function stop() {
    running.value = false
    if (timer) {
      window.clearInterval(timer)
      timer = null
    }
  }

  onUnmounted(stop)

  return { remain, running, start, stop }
}
