import { onUnmounted, ref } from 'vue'
import { AppWebSocket, type WsOptions } from '@/utils/websocket'

export function useWebSocket(options: WsOptions) {
  const status = ref(options.mock ? 'idle' : 'idle')
  const client = new AppWebSocket(options)

  const stop = client.on('status', (value) => {
    status.value = String(value)
  })

  onUnmounted(() => {
    stop()
    client.disconnect()
  })

  return { client, status }
}
