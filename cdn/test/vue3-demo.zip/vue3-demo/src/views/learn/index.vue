<template>
  <div class="page-card">
    <h2 class="page-title">Vue3 实验室</h2>
    <p class="hint">
      一页看完组合式
      API、生命周期、provide/inject、插槽、指令、Teleport、KeepAlive、Transition、Suspense。
    </p>

    <el-tabs v-model="tab">
      <el-tab-pane label="响应式基础" name="reactive">
        <el-space wrap>
          <el-button @click="count += 1">ref count = {{ count }}</el-button>
          <el-button @click="state.n += 1">reactive n = {{ state.n }}</el-button>
          <el-button @click="doubleAlias += 1">toRef 改 doubleAlias</el-button>
        </el-space>
        <ul class="hint">
          <li>computed double = {{ double }}</li>
          <li>toRefs 后的 n = {{ n }}</li>
          <li>readonly 值 = {{ frozen.n }}（页面改不到源对象保护值）</li>
          <li>
            shallowRef.deep.x = {{ shallow.deep.x }}（深层不是响应式，点按钮只会改对象引用才更新）
          </li>
          <li>customRef 防抖文本：{{ debounceText }}</li>
        </ul>
        <el-input v-model="debounceText" placeholder="customRef 防抖输入" style="width: 280px" />
        <el-button style="margin-left: 8px" @click="replaceShallow">替换 shallowRef 对象</el-button>
      </el-tab-pane>

      <el-tab-pane label="生命周期 / 组合函数" name="life">
        <p class="hint">打开工作台和本页，观察右侧/工作台日志中的 onActivated、onDeactivated。</p>
        <el-button @click="innerShow = !innerShow">
          {{ innerShow ? '卸载' : '挂载' }} 子组件
        </el-button>
        <KeepDemo v-if="innerShow" name="toggle" />
        <p>
          组合函数倒计时：{{ remain }}s
          <el-button size="small" :disabled="running" @click="start">开始</el-button>
        </p>
      </el-tab-pane>

      <el-tab-pane label="Provide / 插槽 / 指令" name="provide">
        <InjectChild />
        <SlotPlayground label="demo" style="margin-top: 12px">
          默认内容
          <template #extra>具名 extra</template>
          <template #scoped="{ count: slotCount, label }">
            作用域：{{ label }} / {{ slotCount }}
          </template>
        </SlotPlayground>
        <p>
          自定义指令：
          <el-input v-focus placeholder="自动聚焦" style="width: 200px; margin-right: 8px" />
          <el-button v-copy="'copied from v-copy'">点我复制</el-button>
          <el-button v-permission="['admin']" type="warning">仅 admin 可见</el-button>
        </p>
        <ModelInput v-model="modelText" />
        <p class="hint">defineModel 当前值：{{ modelText }}</p>
      </el-tab-pane>

      <el-tab-pane label="内置组件" name="built-in">
        <el-switch v-model="showPanel" active-text="显示过渡面板" />
        <Transition name="fade">
          <div v-if="showPanel" class="panel">Transition 淡入淡出</div>
        </Transition>
        <el-radio-group v-model="keepName" style="margin: 12px 0">
          <el-radio-button value="A">缓存 A</el-radio-button>
          <el-radio-button value="B">缓存 B</el-radio-button>
        </el-radio-group>
        <keep-alive>
          <KeepDemo :key="keepName" :name="keepName" />
        </keep-alive>
        <Suspense>
          <template #default>
            <AsyncPanel />
          </template>
          <template #fallback>
            <el-skeleton :rows="2" animated />
          </template>
        </Suspense>
      </el-tab-pane>
    </el-tabs>
    <Teleport to="body">
      <div v-if="tab === 'built-in'" class="teleport-badge">Teleport 到 body</div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  customRef,
  provide,
  reactive,
  readonly,
  ref,
  shallowRef,
  toRef,
  toRefs,
  watch,
  watchEffect,
} from 'vue'
import AsyncPanel from '@/components/AsyncPanel.vue'
import InjectChild from '@/components/InjectChild.vue'
import KeepDemo from '@/components/KeepDemo.vue'
import ModelInput from '@/components/ModelInput.vue'
import SlotPlayground from '@/components/SlotPlayground.vue'
import { labKey } from '@/components/lab-key'
import { useCountdown } from '@/composables/useCountdown'
import { useLifecycleLogger } from '@/composables/useLifecycleLogger'

defineOptions({ name: 'LearnLab' })
useLifecycleLogger('LearnLab')

const tab = ref('reactive')
const count = ref(1)
const state = reactive({ n: 1, deep: { x: 1 } })
const { n } = toRefs(state)
const doubleAlias = toRef(state, 'n')
const double = computed(() => count.value * 2)
const frozen = readonly(state)
const shallow = shallowRef({ deep: { x: 1 } })
const modelText = ref('hello defineModel')
const innerShow = ref(true)
const showPanel = ref(true)
const keepName = ref('A')
const { remain, running, start } = useCountdown(5)

function useDebouncedRef(value: string, delay = 400) {
  return customRef((track, trigger) => {
    let inner = value
    let timer: number | null = null
    return {
      get() {
        track()
        return inner
      },
      set(next: string) {
        if (timer) window.clearTimeout(timer)
        timer = window.setTimeout(() => {
          inner = next
          trigger()
        }, delay)
      },
    }
  })
}

const debounceText = useDebouncedRef('')

provide(labKey, {
  theme: computed(() => 'ocean'),
  count,
  add: () => {
    count.value += 1
  },
})

watch(count, (value, oldValue) => {
  console.info('[watch count]', oldValue, '→', value)
})

watchEffect(() => {
  console.info('[watchEffect] count + n =', count.value + state.n)
})

function replaceShallow() {
  shallow.value = { deep: { x: shallow.value.deep.x + 1 } }
}
</script>

<style scoped lang="scss">
.panel {
  margin: 12px 0;
  padding: 12px;
  background: #ecfeff;
  border-radius: 8px;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.teleport-badge {
  position: fixed;
  right: 24px;
  bottom: 24px;
  z-index: 2000;
  background: #0f172a;
  color: #fff;
  padding: 8px 12px;
  border-radius: 999px;
  font-size: 12px;
}
</style>
