<template>
  <div class="page-card">
    <h2 class="page-title">用户管理</h2>
    <p class="hint">
      演示 ref / reactive、表格查询、对话框表单、Pinia 权限指令、统一 confirm/toast。
    </p>

    <div class="toolbar">
      <el-input
        v-model="query.keyword"
        placeholder="搜索用户名 / 昵称"
        style="width: 240px"
        clearable
      />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button v-permission="['admin']" type="success" @click="openCreate">新建用户</el-button>
    </div>

    <el-table v-loading="loading" :data="list" stripe>
      <el-table-column prop="id" label="ID" width="70" />
      <el-table-column prop="username" label="账号" />
      <el-table-column prop="nickname" label="昵称" />
      <el-table-column prop="email" label="邮箱" min-width="180" show-overflow-tooltip />
      <el-table-column prop="role" label="角色" width="100" />
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'info'">
            {{ row.status === 1 ? '启用' : '停用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createdAt" label="创建时间" width="180" />
      <el-table-column label="操作" width="160">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
          <el-button link type="danger" @click="onDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="load"
      />
    </div>

    <el-dialog v-model="visible" :title="form.id ? '编辑用户' : '新建用户'" width="480px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="账号">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="昵称">
          <el-input v-model="form.nickname" />
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="form.role" style="width: 100%">
            <el-option label="admin" value="admin" />
            <el-option label="editor" value="editor" />
            <el-option label="viewer" value="viewer" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" :active-value="1" :inactive-value="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="visible = false">取消</el-button>
        <el-button type="primary" @click="onSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { createUserApi, deleteUserApi, getUserListApi, updateUserApi } from '@/api/user'
import { useTable } from '@/composables/useTable'
import type { UserRecord } from '@/mock/modules'
import { confirmBox, toast } from '@/utils/feedback'

const { loading, list, total, query, load, search } = useTable(getUserListApi)
const visible = ref(false)
const form = reactive<Omit<UserRecord, 'createdAt'> & { createdAt?: string }>({
  id: 0,
  username: '',
  nickname: '',
  email: '',
  role: 'viewer',
  status: 1,
})

function openCreate() {
  Object.assign(form, {
    id: 0,
    username: '',
    nickname: '',
    email: '',
    role: 'viewer',
    status: 1,
  })
  visible.value = true
}

function openEdit(row: unknown) {
  Object.assign(form, row)
  visible.value = true
}

async function onSave() {
  if (form.id) {
    await updateUserApi(form as UserRecord)
  } else {
    await createUserApi({
      username: form.username,
      nickname: form.nickname,
      email: form.email,
      role: form.role,
      status: form.status,
    })
  }
  toast.success('保存成功')
  visible.value = false
  await load()
}

async function onDelete(row: unknown) {
  const record = row as UserRecord
  await confirmBox({ message: `确定删除用户 ${record.nickname} 吗？` })
  await deleteUserApi(record.id)
  toast.success('已删除')
  await load()
}
</script>

<style scoped lang="scss">
.toolbar {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
