<template>
  <div class="page-card">
    <h2 class="page-title">环境与反馈封装</h2>
    <p class="hint">
      通过 <code>vite --mode</code> 切换 development / staging / production。Mock 由
      <code>VITE_USE_MOCK</code> 控制，不改业务代码即可开关。
    </p>

    <el-descriptions :column="2" border>
      <el-descriptions-item label="标题">{{ envConfig.title }}</el-descriptions-item>
      <el-descriptions-item label="MODE">{{ envConfig.mode }}</el-descriptions-item>
      <el-descriptions-item label="APP_ENV">{{ envConfig.appEnv }}</el-descriptions-item>
      <el-descriptions-item label="API_BASE_URL">{{ envConfig.apiBaseUrl }}</el-descriptions-item>
      <el-descriptions-item label="USE_MOCK">{{
        envConfig.useMock ? 'true' : 'false'
      }}</el-descriptions-item>
      <el-descriptions-item label="WS_MOCK">{{
        envConfig.wsMock ? 'true' : 'false'
      }}</el-descriptions-item>
      <el-descriptions-item label="WS_URL" :span="2">{{ envConfig.wsUrl }}</el-descriptions-item>
    </el-descriptions>

    <h3>统一反馈组件</h3>
    <el-space wrap>
      <el-button @click="toast.success('保存成功')">Toast 成功</el-button>
      <el-button @click="toast.error('操作失败')">Toast 失败</el-button>
      <el-button @click="notify.info('系统公告', '这是封装后的 Notification')"
        >公告 Notify</el-button
      >
      <el-button @click="onLoading">Loading 1.2s</el-button>
      <el-button type="warning" @click="onConfirm">Confirm 弹框</el-button>
      <el-button @click="alertBox('这是统一 alert 封装')">Alert 弹框</el-button>
    </el-space>

    <h3>切换环境命令</h3>
    <el-alert type="info" show-icon :closable="false">
      <pre>
npm run dev            # development + mock
npm run dev:staging    # staging，走代理/真实接口
npm run dev:prod       # production 配置
npm run build:staging  # 预发包</pre>
    </el-alert>
  </div>
</template>

<script setup lang="ts">
import { alertBox, confirmBox, hideLoading, notify, showLoading, toast } from '@/utils/feedback'
import { envConfig } from '@/utils/env'

async function onLoading() {
  showLoading('请稍候...')
  await new Promise((resolve) => setTimeout(resolve, 1200))
  hideLoading()
  toast.success('Loading 结束')
}

async function onConfirm() {
  await confirmBox({ title: '公告确认', message: '是否继续这项操作？' })
  toast.success('你点击了确定')
}
</script>

<style scoped>
h3 {
  margin: 24px 0 12px;
}

pre {
  margin: 0;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
</style>
