<template>
  <div>
    <h2 class="page-title">工作台</h2>
    <p class="hint">
      本页演示 <code>onMounted / onActivated / watch / computed</code>。它被 KeepAlive
      缓存，切走再回来会触发 onActivated 而不是重新 mounted。
    </p>

    <el-row :gutter="16" class="cards">
      <el-col v-for="item in cards" :key="item.label" :span="6">
        <div class="page-card stat">
          <div class="label">{{ item.label }}</div>
          <div class="value">{{ item.value }}</div>
        </div>
      </el-col>
    </el-row>

    <el-row :gutter="16">
      <el-col :span="14">
        <div class="page-card">
          <h3>近 7 日访问</h3>
          <div class="bars">
            <div v-for="item in overview?.trend ?? []" :key="item.day" class="bar-item">
              <div class="bar" :style="{ height: `${item.value / 4}px` }"></div>
              <span>{{ item.day }}</span>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="page-card">
          <div class="log-head">
            <h3>生命周期日志</h3>
            <div class="log-actions">
              <el-button size="small" @click="tick += 1">触发更新</el-button>
              <el-button size="small" @click="appStore.clearLogs()">清空</el-button>
            </div>
          </div>
          <el-scrollbar height="220px">
            <p v-for="(item, index) in appStore.lifecycleLogs" :key="index" class="log">
              {{ item }}
            </p>
          </el-scrollbar>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { computed, onActivated, onMounted, ref, watch } from 'vue'
import { getOverviewApi, type OverviewData } from '@/api/dashboard'
import { useLifecycleLogger } from '@/composables/useLifecycleLogger'
import { useAppStore } from '@/stores/app'

defineOptions({ name: 'Dashboard' })

const appStore = useAppStore()
const overview = ref<OverviewData | null>(null)
const tick = ref(0)
useLifecycleLogger('Dashboard')

const cards = computed(() => [
  { label: '访问量', value: overview.value?.visits ?? '-' },
  { label: '用户数', value: overview.value?.users ?? '-' },
  { label: '消息数', value: overview.value?.messages ?? '-' },
  { label: '转化率', value: overview.value ? `${overview.value.conversion}%` : '-' },
])

watch(tick, (value) => {
  appStore.pushLog(`Dashboard watch(tick) = ${value}`)
})

onMounted(async () => {
  overview.value = await getOverviewApi()
})

onActivated(() => {
  appStore.pushLog('Dashboard 从缓存激活（KeepAlive）')
})
</script>

<style scoped lang="scss">
.cards {
  margin-bottom: 16px;
}

.stat .label {
  color: #64748b;
}

.stat .value {
  font-size: 28px;
  font-weight: 700;
  margin-top: 8px;
}

.bars {
  height: 220px;
  display: flex;
  align-items: flex-end;
  gap: 18px;
}

.bar-item {
  flex: 1;
  text-align: center;
  color: #64748b;
  font-size: 12px;
}

.bar {
  background: linear-gradient(180deg, #60a5fa, #2563eb);
  border-radius: 8px 8px 0 0;
  margin-bottom: 8px;
}

.log-head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;

  h3 {
    margin: 0;
    flex: 1;
    white-space: nowrap;
  }
}

.log-actions {
  display: flex;
  gap: 8px;
}

.log {
  margin: 0 0 6px;
  font-size: 12px;
  color: #334155;
}
</style>
