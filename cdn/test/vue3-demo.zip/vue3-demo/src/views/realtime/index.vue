<template>
  <div>
    <h2 class="page-title">实时通道</h2>
    <p class="hint">
      封装了 WebSocket 连接、心跳 ping/pong、超时断开、指数间隔重连。当前
      {{ envConfig.wsMock ? '使用 MockWebSocket，无需真实服务' : envConfig.wsUrl }}。
    </p>

    <el-space wrap style="margin-bottom: 16px">
      <el-button type="primary" @click="realtime.connect">连接</el-button>
      <el-button @click="realtime.sendDemo">发送消息</el-button>
      <el-button type="danger" @click="realtime.disconnect">断开</el-button>
      <el-tag>{{ realtime.status }}</el-tag>
    </el-space>

    <el-row :gutter="16">
      <el-col :span="8">
        <div class="page-card">
          <div class="label">在线</div>
          <div class="value">{{ realtime.metrics.online }}</div>
        </div>
      </el-col>
      <el-col :span="8">
        <div class="page-card">
          <div class="label">QPS</div>
          <div class="value">{{ realtime.metrics.qps }}</div>
        </div>
      </el-col>
      <el-col :span="8">
        <div class="page-card">
          <div class="label">延迟 ms</div>
          <div class="value">{{ realtime.metrics.latency }}</div>
        </div>
      </el-col>
    </el-row>

    <div class="page-card" style="margin-top: 16px">
      <h3>通道日志</h3>
      <el-scrollbar height="280px">
        <p v-for="(item, index) in realtime.logs" :key="index" class="log">{{ item }}</p>
      </el-scrollbar>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onUnmounted } from 'vue'
import { useRealtimeStore } from '@/stores/realtime'
import { envConfig } from '@/utils/env'

const realtime = useRealtimeStore()
realtime.connect()

onUnmounted(() => {
  realtime.disconnect()
})
</script>

<style scoped>
.label {
  color: #64748b;
}
.value {
  font-size: 28px;
  font-weight: 700;
  margin-top: 8px;
}
.log {
  margin: 0 0 6px;
  font-size: 13px;
}
</style>
