<template>
  <div class="wrap">
    <h2>404</h2>
    <p>页面不存在</p>
    <el-button type="primary" @click="router.push('/')">回到首页</el-button>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()
</script>

<style scoped>
.wrap {
  min-height: 60vh;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 8px;
}
</style>
