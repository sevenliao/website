import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { getProfileApi, loginApi, logoutApi, type LoginPayload } from '@/api/auth'
import { getToken, removeToken, setToken } from '@/utils/auth'

export const useUserStore = defineStore(
  'user',
  () => {
    const token = ref(getToken())
    const nickname = ref('')
    const username = ref('')
    const roles = ref<string[]>([])

    const isLogin = computed(() => Boolean(token.value))
    const isAdmin = computed(() => roles.value.includes('admin'))

    async function login(payload: LoginPayload) {
      const result = await loginApi(payload)
      token.value = result.token
      setToken(result.token)
      nickname.value = result.user.nickname
      username.value = result.user.username
      roles.value = result.user.roles
    }

    async function fetchProfile() {
      const profile = await getProfileApi()
      nickname.value = profile.nickname
      username.value = profile.username
      roles.value = profile.roles
    }

    async function logout() {
      try {
        await logoutApi()
      } finally {
        token.value = ''
        nickname.value = ''
        username.value = ''
        roles.value = []
        removeToken()
      }
    }

    return { token, nickname, username, roles, isLogin, isAdmin, login, fetchProfile, logout }
  },
  {
    persist: {
      pick: ['token', 'nickname', 'username', 'roles'],
    },
  },
)
