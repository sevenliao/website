import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { AppWebSocket, type WsStatus } from '@/utils/websocket'
import { envConfig } from '@/utils/env'

interface Metrics {
  online: number
  qps: number
  latency: number
}

export const useRealtimeStore = defineStore('realtime', () => {
  const status = ref<WsStatus>('idle')
  const logs = ref<string[]>([])
  const metrics = ref<Metrics>({ online: 0, qps: 0, latency: 0 })
  const client = ref<AppWebSocket | null>(null)

  const connected = computed(() => status.value === 'open')

  function append(message: string) {
    logs.value.unshift(`${new Date().toLocaleTimeString()} ${message}`)
    logs.value = logs.value.slice(0, 50)
  }

  function connect() {
    if (client.value) client.value.disconnect()
    const ws = new AppWebSocket({
      url: envConfig.wsUrl,
      mock: envConfig.wsMock,
    })
    ws.on('status', (value) => {
      status.value = value as WsStatus
    })
    ws.on('open', () => append('连接成功'))
    ws.on('close', () => append('连接关闭'))
    ws.on('reconnecting', (count) => append(`正在重连：第 ${count} 次`))
    ws.on('heartbeat-timeout', () => append('心跳超时，准备重连'))
    ws.on('metrics', (payload) => {
      const message = payload as { data: Metrics }
      metrics.value = message.data
      append(`收到指标 online=${message.data.online} qps=${message.data.qps}`)
    })
    ws.connect()
    client.value = ws
  }

  function disconnect() {
    client.value?.disconnect()
    client.value = null
    status.value = 'closed'
    append('手动断开')
  }

  function sendDemo() {
    const ok = client.value?.send('client-hello', { from: 'admin-lab' })
    append(ok ? '已发送 client-hello' : '发送失败，当前未连接')
  }

  return { status, logs, metrics, connected, connect, disconnect, sendDemo }
})
