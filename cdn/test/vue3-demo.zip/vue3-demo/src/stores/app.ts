import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { envConfig } from '@/utils/env'

export const useAppStore = defineStore('app', () => {
  const sidebarCollapsed = ref(false)
  const lifecycleLogs = ref<string[]>([])

  const envLabel = computed(() => {
    const map: Record<string, string> = {
      development: '开发环境',
      staging: '预发环境',
      production: '生产环境',
    }
    return map[envConfig.appEnv] ?? envConfig.appEnv
  })

  function toggleSidebar() {
    sidebarCollapsed.value = !sidebarCollapsed.value
  }

  function pushLog(message: string) {
    const time = new Date().toLocaleTimeString()
    lifecycleLogs.value.unshift(`[${time}] ${message}`)
    lifecycleLogs.value = lifecycleLogs.value.slice(0, 40)
  }

  function clearLogs() {
    lifecycleLogs.value = []
  }

  return {
    sidebarCollapsed,
    lifecycleLogs,
    envLabel,
    toggleSidebar,
    pushLog,
    clearLogs,
    envConfig,
  }
})
