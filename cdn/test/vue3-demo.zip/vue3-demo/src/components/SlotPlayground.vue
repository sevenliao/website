<template>
  <div class="box">
    <p>默认插槽：<slot>空内容</slot></p>
    <p>具名插槽：<slot name="extra"></slot></p>
    <p>
      作用域插槽：
      <slot name="scoped" :count="count" :label="label"></slot>
    </p>
    <el-button size="small" @click="count += 1">作用域计数 +1</el-button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

defineProps<{ label: string }>()
const count = ref(1)
</script>
