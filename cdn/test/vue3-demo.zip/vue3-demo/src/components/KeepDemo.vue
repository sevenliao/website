<template>
  <div>
    <p>KeepAlive 子页 {{ name }}，本地计数 {{ count }}（切走再回来应保留）</p>
    <el-button size="small" @click="count += 1">+1</el-button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useLifecycleLogger } from '@/composables/useLifecycleLogger'

const props = defineProps<{ name: string }>()
defineOptions({ name: 'KeepDemo' })
useLifecycleLogger(`KeepDemo:${props.name}`)
const count = ref(0)
</script>
