<template>
  <div class="inject-box">
    子组件通过 inject 拿到：{{ theme }} / {{ count }}
    <el-button size="small" @click="add">调用 provide 的方法</el-button>
  </div>
</template>

<script setup lang="ts">
import { inject } from 'vue'
import { labKey } from './lab-key'

const { theme, count, add } = inject(labKey)!
</script>

<style scoped>
.inject-box {
  padding: 12px;
  background: #eff6ff;
  border-radius: 8px;
}
</style>
