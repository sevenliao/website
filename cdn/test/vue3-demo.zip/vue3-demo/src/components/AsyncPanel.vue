<template>
  <p>这是异步组件，用于演示 Suspense。延迟 {{ delay }}ms 后才 setup 完成。</p>
</template>

<script setup lang="ts">
const delay = 600
await new Promise((resolve) => setTimeout(resolve, delay))
</script>
