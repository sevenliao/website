import type { ComputedRef, InjectionKey, Ref } from 'vue'

export interface LabContext {
  theme: ComputedRef<string>
  count: Ref<number>
  add: () => void
}

export const labKey: InjectionKey<LabContext> = Symbol('lab')
