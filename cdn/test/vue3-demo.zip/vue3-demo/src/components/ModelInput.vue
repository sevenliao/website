<template>
  <el-input v-model="model" placeholder="defineModel 双向绑定" />
</template>

<script setup lang="ts">
const model = defineModel<string>({ default: '' })
</script>
