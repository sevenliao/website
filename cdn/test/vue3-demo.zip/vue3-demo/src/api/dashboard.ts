import { http } from '@/utils/request'

export interface OverviewData {
  visits: number
  users: number
  messages: number
  conversion: number
  trend: Array<{ day: string; value: number }>
}

export function getOverviewApi() {
  return http.get<OverviewData>('/dashboard/overview')
}
