import { http } from '@/utils/request'

export interface LoginPayload {
  username: string
  password: string
}

export interface LoginResult {
  token: string
  user: {
    id: number
    username: string
    nickname: string
    roles: string[]
    avatar: string
  }
}

export function loginApi(data: LoginPayload) {
  return http.post<LoginResult>('/auth/login', data, { loading: true })
}

export function logoutApi() {
  return http.post<boolean>('/auth/logout')
}

export function getProfileApi() {
  return http.get<LoginResult['user']>('/auth/profile')
}
