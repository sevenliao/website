import type { UserRecord } from '@/mock/modules'
import type { PageQuery, PageResult } from '@/mock/helpers'
import { http } from '@/utils/request'

export function getUserListApi(params: PageQuery) {
  return http.get<PageResult<UserRecord>>('/users', params)
}

export function createUserApi(data: Omit<UserRecord, 'id' | 'createdAt'>) {
  return http.post<UserRecord>('/users', data, { loading: true })
}

export function updateUserApi(data: UserRecord) {
  return http.put<UserRecord>('/users', data, { loading: true })
}

export function deleteUserApi(id: number) {
  return http.delete<boolean>('/users', { id }, { loading: true })
}
