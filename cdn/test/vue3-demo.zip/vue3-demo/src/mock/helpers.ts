import type { AxiosResponse, InternalAxiosRequestConfig } from 'axios'

export interface ApiResult<T = unknown> {
  code: number
  message: string
  data: T
}

export interface PageQuery {
  page: number
  pageSize: number
  keyword?: string
}

export interface PageResult<T> {
  list: T[]
  total: number
}

export type MockHandler = (config: InternalAxiosRequestConfig) => ApiResult

export function ok<T>(data: T, message = 'ok'): ApiResult<T> {
  return { code: 0, message, data }
}

export function fail(message: string, code = 400): ApiResult<null> {
  return { code, message, data: null }
}

export function createAxiosResponse(
  config: InternalAxiosRequestConfig,
  payload: ApiResult,
  status = 200,
): AxiosResponse<ApiResult> {
  return {
    data: payload,
    status,
    statusText: status === 200 ? 'OK' : 'Error',
    headers: {},
    config,
  }
}

export function parseBody<T>(config: InternalAxiosRequestConfig): T {
  const { data } = config
  if (!data) return {} as T
  if (typeof data === 'string') {
    try {
      return JSON.parse(data) as T
    } catch {
      return {} as T
    }
  }
  return data as T
}

export function parseQuery(url = '') {
  const query = url.split('?')[1] ?? ''
  return Object.fromEntries(new URLSearchParams(query))
}

export function delay(ms = 240) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
