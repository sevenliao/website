import Mock from 'mockjs'
import { fail, ok, parseBody, parseQuery, type MockHandler } from './helpers'

export interface UserRecord {
  id: number
  username: string
  nickname: string
  email: string
  role: 'admin' | 'editor' | 'viewer'
  status: 0 | 1
  createdAt: string
}

const users: UserRecord[] = Mock.mock({
  'list|18': [
    {
      'id|+1': 1,
      username: '@word(5, 8)',
      nickname: '@cname',
      email: '@email',
      'role|1': ['admin', 'editor', 'viewer'],
      'status|1': [0, 1],
      createdAt: '@datetime',
    },
  ],
}).list

users.unshift({
  id: 0,
  username: 'admin',
  nickname: '超级管理员',
  email: 'admin@vue3.lab',
  role: 'admin',
  status: 1,
  createdAt: '2026-01-01 00:00:00',
})

export const authHandlers: Record<string, MockHandler> = {
  'post /auth/login': (config) => {
    const body = parseBody<{ username: string; password: string }>(config)
    if (body.username === 'admin' && body.password === '123456') {
      return ok({
        token: 'mock-token-admin',
        user: {
          id: 0,
          username: 'admin',
          nickname: '超级管理员',
          roles: ['admin'],
          avatar: '',
        },
      })
    }
    return fail('账号或密码错误（试用账号 admin / 123456）', 401)
  },
  'get /auth/profile': () =>
    ok({
      id: 0,
      username: 'admin',
      nickname: '超级管理员',
      roles: ['admin'],
      avatar: '',
    }),
  'post /auth/logout': () => ok(true),
}

export const userHandlers: Record<string, MockHandler> = {
  'get /users': (config) => {
    const query = parseQuery(config.url)
    const page = Number(query.page || 1)
    const pageSize = Number(query.pageSize || 10)
    const keyword = (query.keyword || '').toLowerCase()
    const filtered = users.filter(
      (item) =>
        !keyword ||
        item.username.toLowerCase().includes(keyword) ||
        item.nickname.includes(keyword),
    )
    const start = (page - 1) * pageSize
    return ok({
      list: filtered.slice(start, start + pageSize),
      total: filtered.length,
    })
  },
  'post /users': (config) => {
    const body = parseBody<Omit<UserRecord, 'id' | 'createdAt'>>(config)
    const id = Math.max(...users.map((item) => item.id)) + 1
    const record: UserRecord = {
      ...body,
      id,
      createdAt: Mock.mock('@datetime'),
    }
    users.unshift(record)
    return ok(record, '创建成功')
  },
  'put /users': (config) => {
    const body = parseBody<UserRecord>(config)
    const index = users.findIndex((item) => item.id === body.id)
    if (index < 0) return fail('用户不存在', 404)
    users[index] = { ...users[index], ...body }
    return ok(users[index], '更新成功')
  },
  'delete /users': (config) => {
    const query = parseQuery(config.url)
    const id = Number(query.id)
    const index = users.findIndex((item) => item.id === id)
    if (index < 0) return fail('用户不存在', 404)
    users.splice(index, 1)
    return ok(true, '删除成功')
  },
}

export const dashboardHandlers: Record<string, MockHandler> = {
  'get /dashboard/overview': () =>
    ok({
      visits: Mock.mock('@integer(1200, 9800)'),
      users: users.length,
      messages: Mock.mock('@integer(20, 180)'),
      conversion: Mock.mock('@float(1, 8, 1, 1)'),
      trend: Array.from({ length: 7 }, (_, index) => ({
        day: `周${'日一二三四五六'[index]}`,
        value: Mock.mock('@integer(80, 360)'),
      })),
    }),
}
