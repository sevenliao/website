import type { AxiosAdapter } from 'axios'
import { createAxiosResponse, delay } from './helpers'
import { authHandlers, dashboardHandlers, userHandlers } from './modules'

const routes = {
  ...authHandlers,
  ...userHandlers,
  ...dashboardHandlers,
}

function normalizeUrl(url = '') {
  const pathname = url.split('?')[0]
  return pathname.replace(/\/\d+$/, '')
}

export const mockAdapter: AxiosAdapter = async (config) => {
  await delay(280)
  const method = (config.method ?? 'get').toLowerCase()
  const url = normalizeUrl(config.url)
  const key = `${method} ${url}`
  const handler = routes[key]
  if (!handler) {
    return createAxiosResponse(config, {
      code: 404,
      message: `未找到 Mock 接口：${key}`,
      data: null,
    })
  }
  return createAxiosResponse(config, handler(config))
}
