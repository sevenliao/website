import type { App, DirectiveBinding } from 'vue'
import { toast } from '@/utils/feedback'
import { useUserStore } from '@/stores/user'

const focus = {
  mounted(el: HTMLElement) {
    el.focus()
  },
}

const copy = {
  mounted(el: HTMLElement, binding: DirectiveBinding<string>) {
    el.style.cursor = 'pointer'
    el.addEventListener('click', () => {
      void navigator.clipboard.writeText(binding.value || el.innerText)
      toast.success('已复制')
    })
  },
}

const permission = {
  mounted(el: HTMLElement, binding: DirectiveBinding<string[]>) {
    const store = useUserStore()
    const need = binding.value ?? []
    const ok = need.some((role) => store.roles.includes(role))
    if (!ok) {
      el.parentNode?.removeChild(el)
    }
  },
}

export function setupDirectives(app: App) {
  app.directive('focus', focus)
  app.directive('copy', copy)
  app.directive('permission', permission)
}
