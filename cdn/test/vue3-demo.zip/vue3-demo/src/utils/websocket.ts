export type WsStatus = 'idle' | 'connecting' | 'open' | 'closing' | 'closed' | 'reconnecting'

export interface WsMessage<T = unknown> {
  event: string
  data: T
  ts: number
}

export interface WsOptions {
  url: string
  mock?: boolean
  heartbeatInterval?: number
  heartbeatTimeout?: number
  reconnect?: boolean
  reconnectInterval?: number
  maxReconnect?: number
  pingEvent?: string
  pongEvent?: string
}

type Listener = (payload?: unknown) => void

class MockWebSocket {
  static CONNECTING = 0
  static OPEN = 1
  static CLOSING = 2
  static CLOSED = 3

  readyState = MockWebSocket.CONNECTING
  onopen: ((event: Event) => void) | null = null
  onclose: ((event: CloseEvent) => void) | null = null
  onerror: ((event: Event) => void) | null = null
  onmessage: ((event: MessageEvent<string>) => void) | null = null

  private timer: number | null = null
  private pushTimer: number | null = null

  private url: string

  constructor(url: string) {
    this.url = url
    window.setTimeout(() => {
      this.readyState = MockWebSocket.OPEN
      this.onopen?.(new Event('open'))
      this.pushTimer = window.setInterval(() => {
        this.emit({
          event: 'metrics',
          data: {
            online: Math.floor(Math.random() * 80) + 20,
            qps: Math.floor(Math.random() * 300) + 40,
            latency: Math.floor(Math.random() * 80) + 12,
          },
          ts: Date.now(),
        })
      }, 2000)
    }, 180)
    void this.url
  }

  send(raw: string) {
    const parsed = JSON.parse(raw) as WsMessage
    if (parsed.event === 'ping') {
      this.timer = window.setTimeout(() => {
        this.emit({ event: 'pong', data: 'pong', ts: Date.now() })
      }, 80)
    }
  }

  close() {
    this.readyState = MockWebSocket.CLOSED
    if (this.timer) window.clearTimeout(this.timer)
    if (this.pushTimer) window.clearInterval(this.pushTimer)
    this.onclose?.(new CloseEvent('close'))
  }

  private emit(payload: WsMessage) {
    this.onmessage?.(new MessageEvent('message', { data: JSON.stringify(payload) }))
  }
}

export class AppWebSocket {
  status: WsStatus = 'idle'
  private socket: WebSocket | MockWebSocket | null = null
  private heartbeatTimer: number | null = null
  private timeoutTimer: number | null = null
  private reconnectTimer: number | null = null
  private reconnectCount = 0
  private manualClose = false
  private listeners = new Map<string, Set<Listener>>()
  private options: Required<WsOptions>

  constructor(options: WsOptions) {
    this.options = {
      heartbeatInterval: 15000,
      heartbeatTimeout: 8000,
      reconnect: true,
      reconnectInterval: 2000,
      maxReconnect: 8,
      pingEvent: 'ping',
      pongEvent: 'pong',
      mock: false,
      ...options,
    }
  }

  on(event: string, listener: Listener) {
    const set = this.listeners.get(event) ?? new Set()
    set.add(listener)
    this.listeners.set(event, set)
    return () => this.off(event, listener)
  }

  off(event: string, listener: Listener) {
    this.listeners.get(event)?.delete(listener)
  }

  connect() {
    this.manualClose = false
    this.setStatus(this.reconnectCount > 0 ? 'reconnecting' : 'connecting')
    const SocketImpl = this.options.mock ? MockWebSocket : WebSocket
    this.socket = new SocketImpl(this.options.url)

    this.socket.onopen = () => {
      this.reconnectCount = 0
      this.setStatus('open')
      this.startHeartbeat()
      this.emit('open')
    }

    this.socket.onmessage = (event: MessageEvent<string>) => {
      const payload = this.parse(event.data)
      if (payload.event === this.options.pongEvent) {
        this.clearHeartbeatTimeout()
        this.emit('pong', payload)
        return
      }
      this.emit('message', payload)
      this.emit(payload.event, payload)
    }

    this.socket.onerror = () => {
      this.emit('error')
    }

    this.socket.onclose = () => {
      this.clearTimers()
      this.setStatus('closed')
      this.emit('close')
      if (!this.manualClose && this.options.reconnect) {
        this.tryReconnect()
      }
    }
  }

  send(event: string, data: unknown = {}) {
    if (!this.socket || this.socket.readyState !== 1) return false
    const payload: WsMessage = { event, data, ts: Date.now() }
    this.socket.send(JSON.stringify(payload))
    return true
  }

  disconnect() {
    this.manualClose = true
    this.clearTimers()
    this.setStatus('closing')
    this.socket?.close()
    this.socket = null
    this.setStatus('closed')
  }

  private tryReconnect() {
    if (this.reconnectCount >= this.options.maxReconnect) {
      this.emit('reconnect-failed')
      return
    }
    this.reconnectCount += 1
    this.setStatus('reconnecting')
    this.emit('reconnecting', this.reconnectCount)
    const wait = this.options.reconnectInterval * this.reconnectCount
    this.reconnectTimer = window.setTimeout(() => this.connect(), wait)
  }

  private startHeartbeat() {
    this.clearTimers()
    this.heartbeatTimer = window.setInterval(() => {
      this.send(this.options.pingEvent, 'ping')
      this.timeoutTimer = window.setTimeout(() => {
        this.emit('heartbeat-timeout')
        this.socket?.close()
      }, this.options.heartbeatTimeout)
    }, this.options.heartbeatInterval)
  }

  private clearHeartbeatTimeout() {
    if (this.timeoutTimer) {
      window.clearTimeout(this.timeoutTimer)
      this.timeoutTimer = null
    }
  }

  private clearTimers() {
    this.clearHeartbeatTimeout()
    if (this.heartbeatTimer) {
      window.clearInterval(this.heartbeatTimer)
      this.heartbeatTimer = null
    }
    if (this.reconnectTimer) {
      window.clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
  }

  private parse(raw: string): WsMessage {
    try {
      return JSON.parse(raw) as WsMessage
    } catch {
      return { event: 'raw', data: raw, ts: Date.now() }
    }
  }

  private setStatus(status: WsStatus) {
    this.status = status
    this.emit('status', status)
  }

  private emit(event: string, payload?: unknown) {
    this.listeners.get(event)?.forEach((listener) => listener(payload))
  }
}
