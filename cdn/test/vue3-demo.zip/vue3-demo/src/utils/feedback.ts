import { ElLoading, ElMessage, ElMessageBox, ElNotification } from 'element-plus'
import type { LoadingInstance } from 'element-plus/es/components/loading/src/loading'

let loadingCount = 0
let loadingInstance: LoadingInstance | null = null

export const toast = {
  success(message: string) {
    ElMessage.success({ message, grouping: true })
  },
  error(message: string) {
    ElMessage.error({ message, grouping: true })
  },
  warning(message: string) {
    ElMessage.warning({ message, grouping: true })
  },
  info(message: string) {
    ElMessage.info({ message, grouping: true })
  },
}

export const notify = {
  success(title: string, message = '') {
    ElNotification.success({ title, message })
  },
  error(title: string, message = '') {
    ElNotification.error({ title, message })
  },
  warning(title: string, message = '') {
    ElNotification.warning({ title, message })
  },
  info(title: string, message = '') {
    ElNotification.info({ title, message })
  },
}

export function showLoading(text = '加载中...') {
  loadingCount += 1
  if (!loadingInstance) {
    loadingInstance = ElLoading.service({
      lock: true,
      text,
      background: 'rgba(15, 23, 42, 0.35)',
    })
  }
}

export function hideLoading() {
  loadingCount = Math.max(0, loadingCount - 1)
  if (loadingCount === 0 && loadingInstance) {
    loadingInstance.close()
    loadingInstance = null
  }
}

export async function confirmBox(options: {
  title?: string
  message: string
  type?: 'warning' | 'info' | 'success' | 'error'
  confirmButtonText?: string
  cancelButtonText?: string
}) {
  return ElMessageBox.confirm(options.message, options.title ?? '确认操作', {
    type: options.type ?? 'warning',
    confirmButtonText: options.confirmButtonText ?? '确定',
    cancelButtonText: options.cancelButtonText ?? '取消',
    draggable: true,
  })
}

export async function alertBox(message: string, title = '提示') {
  return ElMessageBox.alert(message, title, { confirmButtonText: '知道了' })
}

export const feedback = {
  toast,
  notify,
  showLoading,
  hideLoading,
  confirm: confirmBox,
  alert: alertBox,
}
