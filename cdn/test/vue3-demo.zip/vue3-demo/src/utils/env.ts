export const envConfig = {
  title: import.meta.env.VITE_APP_TITLE,
  appEnv: import.meta.env.VITE_APP_ENV,
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL,
  useMock: import.meta.env.VITE_USE_MOCK === 'true',
  wsUrl: import.meta.env.VITE_WS_URL,
  wsMock: import.meta.env.VITE_WS_MOCK === 'true',
  mode: import.meta.env.MODE,
} as const
