import axios, { type AxiosRequestConfig, type InternalAxiosRequestConfig } from 'axios'
import { getToken, removeToken } from '@/utils/auth'
import { envConfig } from '@/utils/env'
import { hideLoading, showLoading, toast } from '@/utils/feedback'
import { mockAdapter } from '@/mock/adapter'
import type { ApiResult } from '@/mock/helpers'

interface RequestOptions {
  loading?: boolean
  silent?: boolean
}

declare module 'axios' {
  interface AxiosRequestConfig {
    loading?: boolean
    silent?: boolean
  }
}

const service = axios.create({
  baseURL: envConfig.apiBaseUrl,
  timeout: 15000,
  adapter: envConfig.useMock ? mockAdapter : undefined,
})

service.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (config.loading) showLoading()
  const token = getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

service.interceptors.response.use(
  (response) => {
    if (response.config.loading) hideLoading()
    const payload = response.data as ApiResult
    if (payload.code !== 0) {
      if (!response.config.silent) toast.error(payload.message || '请求失败')
      return Promise.reject(payload)
    }
    response.data = payload.data
    return response
  },
  (error: unknown) => {
    const config = (error as { config?: InternalAxiosRequestConfig })?.config
    if (config?.loading) hideLoading()
    const status = (error as { response?: { status?: number } })?.response?.status
    if (status === 401) {
      removeToken()
      toast.error('登录已过期，请重新登录')
      window.location.href = '/login'
    } else if (!config?.silent) {
      toast.error('网络异常，请稍后重试')
    }
    return Promise.reject(error)
  },
)

export async function request<T>(config: AxiosRequestConfig & RequestOptions) {
  const response = await service.request<T>(config)
  return response.data
}

export const http = {
  get<T>(url: string, params?: unknown, options?: RequestOptions) {
    return request<T>({ url, method: 'get', params, ...options })
  },
  post<T>(url: string, data?: unknown, options?: RequestOptions) {
    return request<T>({ url, method: 'post', data, ...options })
  },
  put<T>(url: string, data?: unknown, options?: RequestOptions) {
    return request<T>({ url, method: 'put', data, ...options })
  },
  delete<T>(url: string, params?: unknown, options?: RequestOptions) {
    return request<T>({ url, method: 'delete', params, ...options })
  },
}
