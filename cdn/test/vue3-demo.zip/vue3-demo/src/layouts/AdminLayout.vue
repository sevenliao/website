<template>
  <el-container class="layout">
    <el-aside :width="appStore.sidebarCollapsed ? '72px' : '220px'" class="aside">
      <div class="brand">
        <span class="logo">V3</span>
        <span v-show="!appStore.sidebarCollapsed" class="brand-text">Admin Lab</span>
      </div>
      <el-menu
        :default-active="route.path"
        router
        :collapse="appStore.sidebarCollapsed"
        background-color="#0f172a"
        text-color="#cbd5e1"
        active-text-color="#93c5fd"
      >
        <el-menu-item index="/dashboard">
          <el-icon><Odometer /></el-icon>
          <span>工作台</span>
        </el-menu-item>
        <el-menu-item index="/system/user">
          <el-icon><User /></el-icon>
          <span>用户管理</span>
        </el-menu-item>
        <el-menu-item index="/learn">
          <el-icon><Opportunity /></el-icon>
          <span>Vue3 实验室</span>
        </el-menu-item>
        <el-menu-item index="/realtime">
          <el-icon><Connection /></el-icon>
          <span>实时通道</span>
        </el-menu-item>
        <el-menu-item index="/settings">
          <el-icon><Setting /></el-icon>
          <span>环境设置</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="left">
          <el-icon class="fold" @click="appStore.toggleSidebar">
            <Fold v-if="!appStore.sidebarCollapsed" />
            <Expand v-else />
          </el-icon>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item>后台</el-breadcrumb-item>
            <el-breadcrumb-item>{{ route.meta.title }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="right">
          <el-tag :type="envTagType" effect="dark">{{ appStore.envLabel }}</el-tag>
          <el-tag v-if="appStore.envConfig.useMock" type="warning">MOCK</el-tag>
          <el-dropdown @command="onCommand">
            <span class="user">
              {{ userStore.nickname || userStore.username }}
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人资料</el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>
      <el-main class="main">
        <router-view v-slot="{ Component, route: current }">
          <keep-alive :include="['Dashboard', 'LearnLab']">
            <component :is="Component" v-if="current.meta.keepAlive" :key="String(current.name)" />
          </keep-alive>
          <component :is="Component" v-if="!current.meta.keepAlive" :key="String(current.name)" />
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  ArrowDown,
  Connection,
  Expand,
  Fold,
  Odometer,
  Opportunity,
  Setting,
  User,
} from '@element-plus/icons-vue'
import { useAppStore } from '@/stores/app'
import { useUserStore } from '@/stores/user'
import { confirmBox, toast } from '@/utils/feedback'

const route = useRoute()
const router = useRouter()
const appStore = useAppStore()
const userStore = useUserStore()

const envTagType = computed(() => {
  if (appStore.envConfig.appEnv === 'production') return 'danger'
  if (appStore.envConfig.appEnv === 'staging') return 'warning'
  return 'success'
})

async function onCommand(command: string) {
  if (command === 'profile') {
    toast.info(`当前用户：${userStore.nickname}`)
    return
  }
  if (command === 'logout') {
    await confirmBox({ message: '确定退出登录吗？', type: 'warning' })
    await userStore.logout()
    await router.push('/login')
  }
}
</script>

<style scoped lang="scss">
.layout {
  min-height: 100vh;
}

.aside {
  background: var(--admin-sidebar);
  transition: width 0.2s ease;
  overflow: hidden;
}

.brand {
  height: 60px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 16px;
  color: #fff;
  font-weight: 700;
}

.logo {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: #2563eb;
  display: grid;
  place-items: center;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-bottom: 1px solid #e2e8f0;
}

.left,
.right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.fold {
  cursor: pointer;
  font-size: 18px;
}

.user {
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.main {
  padding: 20px;
}
</style>
