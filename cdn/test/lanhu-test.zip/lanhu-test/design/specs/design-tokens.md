# 蓝湖 Design Tokens

> 由 AI 根据设计稿截图或可访问页面写入，再同步到
> `src/styles/element-variables.scss`（Element 变量）和
> `src/styles/variables.scss`（业务变量）。
> 仅凭截图得到的值，在「蓝湖值」列注明「截图估算」。下表在还原前是示例值。

| Token | 蓝湖值 | 代码变量 | 落盘文件 |
|---|---|---|---|
| 主色 | #2F6BFF（示例，待替换） | `$--color-primary` | element-variables.scss |
| 成功色 | #00B578 | `$--color-success` | element-variables.scss |
| 警告色 | #FF8F1F | `$--color-warning` | element-variables.scss |
| 危险色 | #F4333C | `$--color-danger` | element-variables.scss |
| 页面背景 | #F5F7FA | `$color-bg-page` | variables.scss |
| 表头背景 | #F7F8FA | `$color-bg-table-header` | variables.scss + global.scss |
| 正文色 | #4E5969 | `$color-text-regular` | variables.scss |
| 标题色 | #1D2129 | `$color-text-primary` | variables.scss |
| 边框色 | #E5E6EB | `$color-border` | variables.scss |
| 正文字号 | 14px | `$--font-size-base` | element-variables.scss |
| 主按钮高 | 36px | `$--button-medium-height` | element-variables.scss |
| 圆角 | 6px | `$--border-radius-base` | element-variables.scss |
| 顶部栏高 | 56px | `$header-height` | variables.scss |
| 侧边栏宽 | 220px | `$aside-width` | variables.scss |

## 同步规则
1. 先改本表，再改 `element-variables.scss`，Element 组件自动换肤
2. 再改 `variables.scss`，页面自定义样式使用这些变量
3. 全局 token 只在首次还原或设计规范变化时更新；单页特例不写进本表
