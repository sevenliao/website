# 说法示例（可选）

不必复制本文件。直接说设计稿在哪、要什么页面即可。AI 按 `AGENT.md` 和 `design/WORKFLOW.md` 执行。

## 首次还原

```
设计稿在 design/screenshots/order-list.png。
请还原成订单列表，路由 /order/list。
看不清或缺少的内容再问我。
```

只有链接时：

```
请打开这个页面并还原：https://example.com/order/list
路由用 /order/list。读不到样式或需要登录时再问我。
```

## 继续改一轮

```
和设计稿再对一次，把还不一致的地方直接改掉。
```

只想改某几处时再点名，例如按钮高度、操作列、卡片间距。
