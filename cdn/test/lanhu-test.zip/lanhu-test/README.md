# lanhu-test1 — 蓝湖设计稿还原项目模板

Vue2 + Element UI 项目模板。用自然语言把蓝湖设计稿还原成页面：
你提供截图或链接，AI 提取规范、生成代码，并在浏览器里对照修正。

## 快速开始

```bash
cd /Users/liao/Project/test/lanhu/test1
npm install
npm run serve
```

浏览器打开 http://localhost:8080 可看到示例列表页。

## 标准 SOP

你每次只做两件事：给出设计入口，并用一句话说明要还原的页面。标注、变量、路由、启动和对照都由 AI 完成。判断不了的内容，AI 会向你提问。

**你提供其中一种即可**

- 对话里直接附上设计稿截图
- 把截图或导出图片放到 `design/screenshots/`，告诉 AI 文件名
- 给出可访问的页面链接（蓝湖分享页、已上线页面）。能打开时，AI 读取真实样式，比纯截图更准

**你这样说就行**（Cursor 和 Qoder 都会调用项目 skill `lanhu-restore`）

```
/lanhu-restore 设计稿在 design/screenshots/order-list.png，还原成订单列表，路由 /order/list
```

不写 `/lanhu-restore`、直接说「还原这张蓝湖设计稿」也可以。

不知道页面名或路由时，直接说「按这张图还原，路由你来定」。

**AI 自动完成**

1. 从截图估算，或从可访问页面读取颜色、字号、圆角、间距、组件尺寸
2. 写入 `design/specs/design-tokens.md`，并同步 `element-variables.scss`、`variables.scss`
3. 生成 `src/views/<模块>/<页面>.vue` 和路由，用 mock 数据让页面可预览
4. 启动项目，在浏览器打开目标页，对照设计稿修改，主动迭代最多 3 轮
5. 做完后说明已对齐的部分，以及仍需你确认的差异

**只有这些情况才需要你补充**

- 自定义图标：AI 会点名，让你放进 `src/assets/icons/`
- 页面要登录、验证码，或链接打不开
- 截图模糊，又没有可访问页面，关键尺寸看不清
- 同一份设计里主色等全局规范互相冲突

逐步操作说明见 [使用指南.md](./使用指南.md)。完整步骤、输入优先级和验收清单见 `design/WORKFLOW.md`。AI 的执行规则在 `AGENT.md`。

## 目录说明

| 路径 | 作用 |
|---|---|
| `.cursor/skills/lanhu-restore/` | 还原流程 skill，Cursor 版（`/lanhu-restore`） |
| `.qoder/skills/lanhu-restore/` | 还原流程 skill，Qoder 版（`/lanhu-restore`） |
| `.qoder/rules/lanhu-restore.md` | 还原规则，Qoder 版（始终生效） |
| `AGENT.md` | AI 执行本 SOP 的项目规则 |
| `design/WORKFLOW.md` | 给人看的完整 SOP |
| `design/screenshots/` | 设计稿截图投放目录（也可在对话里直接发图） |
| `design/specs/design-tokens.md` | 设计 token 表，由 AI 根据设计稿写入 |
| `design/prompts/page-restore-prompt.md` | 可选说法示例，不必复制 |
| `src/styles/element-variables.scss` | Element UI 主题变量 |
| `src/styles/variables.scss` | 业务设计变量 |
| `src/views/example/ExampleList.vue` | 还原模板页 |
| `src/components/SearchForm` | 配置化筛选表单 |
| `src/components/ProTable` | 表格 + 分页 |

## 常见问题

**Q: 还要手抄主色、按钮高度这些标注吗？**
不用。把截图或链接给 AI。截图得到的是估算值，会在 token 表里标明；能打开真实页面时，以页面上的样式为准。

**Q: 生成的颜色和设计稿不一致？**
让 AI 再对一次截图，或补一个可访问链接。全局主色只维护 `element-variables.scss` 里的一份。

**Q: 设计稿有 Element 没有的组件？**
AI 用原生 HTML + SCSS 写在页面里，样式仍走 `variables.scss`。第二次出现再封装。

**Q: 一次还原多个页面？**
一次一个页面。多页面时先让 AI 列出路由，再逐页还原。
