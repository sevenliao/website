<template>
  <!--
    蓝湖还原模板页（标准后台列表页）
    新页面由 AI 按设计稿生成到 src/views/<模块>/<页面>.vue，
    可参考本页的筛选区、表格和布局，不必手工复制后再改。
  -->
  <el-container class="page">
    <el-aside :width="$asideWidth" class="aside">
      <div class="logo">管理系统</div>
      <el-menu default-active="1" background-color="#001529" text-color="rgba(255,255,255,.7)" active-text-color="#fff">
        <el-menu-item index="1"><i class="el-icon-user"></i><span>用户管理</span></el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header :height="$headerHeight" class="header">
        <span class="title">用户管理</span>
      </el-header>

      <el-main class="main">
        <!-- 筛选区：优先使用已封装的 SearchForm -->
        <el-form :inline="true" :model="query" class="filter">
          <el-form-item label="用户名">
            <el-input v-model="query.name" placeholder="请输入用户名" clearable />
          </el-form-item>
          <el-form-item label="状态">
            <el-select v-model="query.status" placeholder="全部" clearable>
              <el-option label="启用" :value="1" />
              <el-option label="停用" :value="0" />
            </el-select>
          </el-form-item>
          <el-form-item label="创建时间">
            <el-date-picker v-model="query.range" type="daterange"
              start-placeholder="开始日期" end-placeholder="结束日期" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" @click="onSearch">查询</el-button>
            <el-button icon="el-icon-refresh-left" @click="onReset">重置</el-button>
          </el-form-item>
        </el-form>

        <!-- 表格卡片 -->
        <div class="table-card">
          <div class="table-toolbar">
            <span class="card-title">用户列表</span>
            <el-button type="primary" icon="el-icon-plus" @click="onAdd">新增用户</el-button>
          </div>

          <el-table :data="list" border stripe>
            <el-table-column prop="name" label="用户名" min-width="120" />
            <el-table-column prop="phone" label="手机号" min-width="130" />
            <el-table-column label="状态" width="100">
              <template slot-scope="{ row }">
                <el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">
                  {{ row.status === 1 ? '启用' : '停用' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="160" fixed="right">
              <template slot-scope="{ row }">
                <el-button type="text" size="small" @click="onEdit(row)">编辑</el-button>
                <el-button type="text" size="small" @click="onDelete(row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>

          <el-pagination class="pager" background layout="total, sizes, prev, pager, next, jumper"
            :total="total" :page-sizes="[10, 20, 50]" :current-page.sync="query.page"
            :page-size.sync="query.size" @current-change="fetchList" @size-change="fetchList" />
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
// 规范：样式值取自 src/styles/variables.scss，不写死魔法数字
import { asideWidth, headerHeight } from '@/styles/layout-constants'

export default {
  name: 'ExampleList',
  data() {
    return {
      query: { name: '', status: '', range: null, page: 1, size: 10 },
      list: [],
      total: 0
    }
  },
  computed: {
    $asideWidth: () => asideWidth,
    $headerHeight: () => headerHeight
  },
  created() { this.fetchList() },
  methods: {
    async fetchList() {
      // TODO: 替换为真实接口
      this.list = [
        { name: '张三', phone: '138****0000', status: 1 },
        { name: '李四', phone: '139****1111', status: 0 }
      ]
      this.total = 2
    },
    onSearch() { this.query.page = 1; this.fetchList() },
    onReset() { this.query = { name: '', status: '', range: null, page: 1, size: 10 }; this.fetchList() },
    onAdd() { this.$message.info('打开新增弹窗') },
    onEdit(row) { this.$message.info('编辑 ' + row.name) },
    onDelete(row) { this.$confirm(`确认删除 ${row.name}？`, '提示', { type: 'warning' }) }
  }
}
</script>

<style lang="scss" scoped>
.aside { background: #001529; }
.logo {
  height: 56px; line-height: 56px; text-align: center;
  color: #fff; font-size: $font-size-title; font-weight: 600;
}
.header {
  background: #fff; display: flex; align-items: center;
  box-shadow: $shadow-card; position: relative; z-index: 1;
}
.title { font-size: $font-size-title; color: $color-text-primary; font-weight: 600; }
.main { padding: $spacing-md; }
.filter {
  background: #fff; padding: $spacing-md $spacing-md 0;
  border-radius: 8px; box-shadow: $shadow-card; margin-bottom: $spacing-md;
}
.card-title { font-size: $font-size-base; font-weight: 600; color: $color-text-primary; }
</style>
