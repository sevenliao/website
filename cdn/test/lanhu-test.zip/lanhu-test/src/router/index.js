import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  { path: '/', redirect: '/example/list' },
  {
    path: '/example/list',
    component: () => import('@/views/example/ExampleList.vue')
  }
]

export default new VueRouter({ routes })
