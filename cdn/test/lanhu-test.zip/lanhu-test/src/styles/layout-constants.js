// 与 src/styles/variables.scss 保持同步的 JS 常量（供组件内绑定使用）
export const asideWidth = '220px'   // $aside-width
export const headerHeight = '56px'  // $header-height
