<template>
  <!-- 封装说明：表格 + 分页一体化组件 -->
  <div class="table-card">
    <div class="table-toolbar" v-if="$slots.toolbar || title">
      <span class="title">{{ title }}</span>
      <slot name="toolbar" />
    </div>
    <el-table :data="data" border stripe v-bind="$attrs" v-on="$listeners">
      <slot />
    </el-table>
    <el-pagination class="pager" background layout="total, sizes, prev, pager, next, jumper"
      :total="total" :current-page.sync="page" :page-size.sync="size"
      @current-change="$emit('refresh')" @size-change="$emit('refresh')" />
  </div>
</template>

<script>
export default {
  name: 'ProTable',
  props: {
    title: String,
    data: { type: Array, default: () => [] },
    total: { type: Number, default: 0 }
  },
  data() { return { page: 1, size: 10 } }
}
</script>
