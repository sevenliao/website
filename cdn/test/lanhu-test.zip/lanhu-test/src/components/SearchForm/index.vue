<template>
  <!-- 封装说明：配置化筛选表单，props 传入 fields 配置即可生成筛选区 -->
  <el-form :inline="true" :model="value" class="search-form">
    <el-form-item v-for="f in fields" :key="f.key" :label="f.label">
      <el-input v-if="f.type === 'input'" v-model="value[f.key]" :placeholder="f.placeholder" clearable />
      <el-select v-else-if="f.type === 'select'" v-model="value[f.key]" :placeholder="f.placeholder" clearable>
        <el-option v-for="o in f.options" :key="o.value" :label="o.label" :value="o.value" />
      </el-select>
      <el-date-picker v-else-if="f.type === 'daterange'" v-model="value[f.key]" type="daterange"
        start-placeholder="开始日期" end-placeholder="结束日期" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" icon="el-icon-search" @click="$emit('search')">查询</el-button>
      <el-button icon="el-icon-refresh-left" @click="$emit('reset')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  name: 'SearchForm',
  props: {
    fields: { type: Array, required: true }, // [{ key, label, type, options?, placeholder? }]
    value: { type: Object, required: true }
  }
}
</script>

<style lang="scss" scoped>
.search-form { background: #fff; padding: $spacing-md $spacing-md 0; border-radius: 8px; box-shadow: $shadow-card; }
</style>
