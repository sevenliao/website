module.exports = {
  transpileDependencies: true,
  css: {
    loaderOptions: {
      sass: {
        // theme-chalk 源码使用旧语法，屏蔽其弃用警告
        sassOptions: {
          quietDeps: true,
          silenceDeprecations: ['import', 'legacy-js-api', 'global-builtin', 'slash-div', 'mixed-decls']
        },
        // 全局注入：element 主题变量 + 业务设计变量
        // element-theme.scss 自行 @import 变量，注入 @use 会与其冲突
        additionalData: (content, loaderContext) => {
          if (loaderContext.resourcePath.endsWith('element-theme.scss')) return content
          return `
            @use "@/styles/element-variables.scss" as *;
            @use "@/styles/variables.scss" as *;
          ` + content
        }
      }
    }
  }
}
