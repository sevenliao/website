# AGENT.md — AI 助手工作规则（蓝湖设计稿还原项目）

> 本文件是给 AI IDE（Cline / Roo Code / Cursor / Copilot 等）的项目级指令。
> 打开本项目后，AI 应遵守以下全部规则。

## 1. 项目技术栈

- Vue 2（Options API）+ Element UI 2.x（已全局注册，无需 import）
- 样式：SCSS，已通过 vue.config.js 全局注入以下变量文件，**禁止在组件里重复 @use/@import**
  - `@/styles/element-variables.scss`（Element 主题变量）
  - `@/styles/variables.scss`（业务 Design Tokens）
- 路由：vue-router 3，路由定义在 `src/router/index.js`
- 无 TypeScript，组件用 `<script>` 默认导出

## 2. 标准 SOP：自然语言还原设计稿

用户给出设计稿截图、本地图片或可访问链接，并要求还原页面时，按本节做完。不要要求用户手抄标注，不要要求用户打开或粘贴 `design/prompts/` 里的模板。

人只提供设计入口和页面目标。标注提取、变量落盘、生成代码、启动预览、对照修正都由 AI 完成。只有无法判断时才向用户提问。

### 输入

接受任意一种，有多种时一起用：

- 对话中的设计稿截图
- 本地图片，默认目录 `design/screenshots/`，也接受用户给出的其他路径
- 可访问 URL（蓝湖分享页、已上线页面）

页面名或路由没说清时：能从文件名或画面标题推断就先用，并在回复里写明假设。推断不了再问。

### 执行顺序

1. **提取规范**
   - 能打开页面：读取真实样式（颜色、字号、圆角、间距、按钮和输入框高度）
   - 只有截图：根据图像估算，在 `design/specs/design-tokens.md` 的对应行标明「截图估算」
   - 两者都有：数值以页面实测为准，布局和文案以设计稿截图为准
2. **写入 token**（保持三者一致）
   - `design/specs/design-tokens.md`
   - `src/styles/element-variables.scss`：主色、成功/警告/危险色、基础字号、圆角、按钮高度
   - `src/styles/variables.scss`：页面背景、表头背景、文字色、边框、间距、布局尺寸
   - 全局 token 只在首次还原或用户说明设计规范变了时改。单页特例写在页面内，并使用已有变量
3. **生成页面**
   - 路径：`src/views/<模块>/<页面>.vue`，PascalCase
   - 同时把路由写入 `src/router/index.js`，不要只在回复里建议用户自己加
   - 组件映射见下表
   - 接口未接入前，在 `data()` 放 mock，并标注 `// TODO: 替换为真实接口`
4. **对照迭代**
   - 依赖未安装时先 `npm install`，开发服务未启动则 `npm run serve`
   - 用浏览器打开目标路由，对照设计稿修改实现
   - 主动最多 3 轮，每轮处理当前最明显的 3～5 处差异
   - 结束后说明已改内容和仍需用户确认的差异
5. **提问边界**  
   遇到下列情况停下来问，一次问清，不要猜测后继续：
   - 自定义图标或插画，请用户放入 `src/assets/icons/` 或 `src/assets/images/`
   - 登录、验证码，或链接无法访问
   - 截图看不清，又没有可访问页面，关键尺寸无法估计
   - 全局主色、字号、圆角在材料里互相冲突

### 组件映射

| 设计稿元素 | 实现 |
|---|---|
| 筛选/搜索区 | `@/components/SearchForm`（配置化）或 el-form inline |
| 表格+分页 | `@/components/ProTable` |
| 弹窗 | `el-dialog` |
| 状态标签 | `el-tag`（type 按语义：success/info/warning/danger） |
| 分页 | `el-pagination`，layout 用 `total, sizes, prev, pager, next, jumper` |
| 布局 | `el-container/el-header/el-aside/el-main`，**禁止绝对定位堆砌** |

生成时同时遵守：

- 主按钮和主题色用 `type="primary"`，不把色值写死在组件上
- 图标优先 `el-icon-*`；自定义图标向用户要文件，不要用占位图假装还原
- 自定义样式使用 `variables.scss` 的 `$color-*`、`$spacing-*`、`$font-size-*`，禁止魔法数字
- 一次只还原用户当前指定的一个页面

用户只说「再对一次设计稿」时，从第 4 步继续，不要重新要求准备素材。

### 禁忌

- 不要新建与设计无关的目录结构
- 不要引入 Element UI 以外的 UI 库
- 不要在单文件组件里引入 element-variables.scss / variables.scss（已全局注入）
- 不要删除 `design/` 目录下的文档
- 不要把「请用户先填 token 表」当作还原的前置步骤

## 3. 目录结构约定

```
src/
  views/<模块>/<页面>.vue   # 页面（还原产物）
  components/               # 封装组件（SearchForm / ProTable，可扩展）
  styles/                   # 变量与全局样式（单一事实来源）
  assets/images|icons       # 按需放入的自定义切图
design/
  screenshots/              # 用户投放的设计稿截图
  specs/design-tokens.md    # token 表（AI 写入，截图估算需标明）
  prompts/                  # 可选说法示例，不是必经步骤
  WORKFLOW.md               # 给人看的 SOP
```

## 4. 设计变量速查

- Element 换肤：`src/styles/element-variables.scss` 的 `$--color-primary` 等
- 业务样式：`src/styles/variables.scss` 的 `$color-*`、`$spacing-*`、`$font-size-*`
- 新增 token：先写 `design/specs/design-tokens.md`，再改对应 scss
