import { startFixtureServer } from '../tests/e2e/fixture-server.js';

const server = await startFixtureServer(Number(process.env.FIXTURE_PORT ?? 4500));
console.info('本地测试文档服务已启动：');
console.info(`  示例需求文档：      ${server.baseUrl}/doc.html`);
console.info(`  需要登录的文档：    ${server.baseUrl}/protected   （登录页上点“登录”即可）`);
console.info(`  正文在 iframe 中：  ${server.baseUrl}/frame-host`);
console.info('按 Ctrl+C 停止。');

process.on('SIGINT', () => {
  void server.close().then(() => process.exit(0));
});
