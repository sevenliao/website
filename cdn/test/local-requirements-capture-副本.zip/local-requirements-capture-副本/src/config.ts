import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export interface AppConfig {
  projectRoot: string;
  host: string;
  port: number;
  browserProfileDir: string;
  requirementsDir: string;
  navigationTimeoutMs: number;
  headless: boolean;
}

const LOOPBACK_HOSTS = new Set(['127.0.0.1', '::1', 'localhost']);

export const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function loadDotEnv(root: string): void {
  const envFile = path.join(root, '.env');
  if (fs.existsSync(envFile)) process.loadEnvFile(envFile);
}

function parsePositiveInt(value: string | undefined, fallback: number, name: string): number {
  if (value === undefined || value === '') return fallback;
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new Error(`环境变量 ${name} 必须是正整数，当前值：${value}`);
  return n;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env, root = PROJECT_ROOT): AppConfig {
  if (env === process.env) loadDotEnv(root);

  const host = env.HOST?.trim() || '127.0.0.1';
  if (!LOOPBACK_HOSTS.has(host)) {
    throw new Error(`HOST=${host} 不是回环地址。为安全起见，本工具只允许监听 127.0.0.1 / ::1 / localhost。`);
  }

  return {
    projectRoot: root,
    host,
    port: parsePositiveInt(env.PORT, 3789, 'PORT'),
    browserProfileDir: path.resolve(root, env.BROWSER_PROFILE_DIR || 'data/browser-profile'),
    requirementsDir: path.resolve(root, env.REQUIREMENTS_DIR || 'docs/requirements'),
    navigationTimeoutMs: parsePositiveInt(env.NAVIGATION_TIMEOUT_MS, 45_000, 'NAVIGATION_TIMEOUT_MS'),
    headless: env.HEADLESS === 'true',
  };
}
