import { AppError } from './errors.js';

const MAX_URL_LENGTH = 4096;

/**
 * Validates a user supplied document URL. Only http/https URLs are accepted and
 * embedded credentials are rejected so they never end up in logs or status output.
 */
export function validateDocumentUrl(input: unknown): URL {
  if (typeof input !== 'string' || input.trim() === '') {
    throw new AppError(400, 'INVALID_URL', '请输入需求文档 URL。', {
      hint: '示例：https://example.com/docs/requirement-1',
    });
  }
  const raw = input.trim();
  if (raw.length > MAX_URL_LENGTH) {
    throw new AppError(400, 'INVALID_URL', `URL 过长（超过 ${MAX_URL_LENGTH} 个字符）。`);
  }

  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new AppError(400, 'INVALID_URL', `URL 格式不合法：${raw}`, {
      hint: '请输入以 http:// 或 https:// 开头的完整地址。',
    });
  }

  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new AppError(400, 'INVALID_URL', `不支持的协议 "${url.protocol}"，仅支持 http 和 https。`, {
      hint: '请输入以 http:// 或 https:// 开头的完整地址。',
    });
  }
  if (!url.hostname) {
    throw new AppError(400, 'INVALID_URL', 'URL 缺少主机名。');
  }
  if (url.username || url.password) {
    throw new AppError(400, 'INVALID_URL', 'URL 中不允许包含用户名或密码。', {
      hint: '请去掉 URL 中的账号信息，在打开的浏览器中手动登录。',
    });
  }
  return url;
}

/** Removes query string and fragment for log output so tokens in URLs are not printed. */
export function redactUrl(raw: string | null | undefined): string {
  if (!raw) return '';
  try {
    const url = new URL(raw);
    return `${url.protocol}//${url.host}${url.pathname}${url.search ? '?…' : ''}`;
  } catch {
    return '[invalid url]';
  }
}
