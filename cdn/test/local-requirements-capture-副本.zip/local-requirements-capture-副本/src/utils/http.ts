import type { ErrorRequestHandler, NextFunction, Request, RequestHandler, Response } from 'express';
import type { ApiFailure, ApiSuccess } from '../types/index.js';
import { AppError } from './errors.js';

export const CLIENT_HEADER = 'x-lrc-client';
const LOOPBACK_HOSTNAMES = new Set(['127.0.0.1', 'localhost', '[::1]', '::1']);

export function sendOk<T>(res: Response, data: T, status = 200): void {
  const body: ApiSuccess<T> = { ok: true, data };
  res.status(status).json(body);
}

function hostnameOf(hostHeader: string): string {
  if (hostHeader.startsWith('[')) return hostHeader.slice(0, hostHeader.indexOf(']') + 1);
  return hostHeader.split(':')[0] ?? '';
}

/**
 * Blocks requests that do not originate from the local tool page:
 * - Host must be a loopback name (defeats DNS rebinding).
 * - Mutating API calls need a custom header, which a cross-site page cannot send without a
 *   CORS preflight that this server never approves.
 * - If an Origin header is present it must be a loopback origin.
 */
export const localOnly: RequestHandler = (req: Request, _res: Response, next: NextFunction) => {
  const host = req.headers.host ?? '';
  if (!LOOPBACK_HOSTNAMES.has(hostnameOf(host).toLowerCase())) {
    next(new AppError(403, 'FORBIDDEN_HOST', '仅允许通过 127.0.0.1 或 localhost 访问本工具。'));
    return;
  }
  const origin = req.headers.origin;
  if (origin && origin !== 'null') {
    let originHost = '';
    try { originHost = new URL(origin).hostname; } catch { /* invalid origin */ }
    if (!LOOPBACK_HOSTNAMES.has(originHost)) {
      next(new AppError(403, 'FORBIDDEN_ORIGIN', '拒绝来自外部网站的请求。'));
      return;
    }
  } else if (origin === 'null') {
    next(new AppError(403, 'FORBIDDEN_ORIGIN', '拒绝来自未知来源的请求。'));
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.path.startsWith('/api/')) {
    if (req.headers[CLIENT_HEADER] !== 'web') {
      next(new AppError(403, 'MISSING_CLIENT_HEADER', '请求缺少本地工具标识，已拒绝。', {
        hint: '请通过本地工具页面操作，不要从其他网站或脚本直接调用接口。',
      }));
      return;
    }
    if (!req.is('application/json')) {
      next(new AppError(415, 'UNSUPPORTED_CONTENT_TYPE', '请求体必须是 JSON（Content-Type: application/json）。'));
      return;
    }
  }
  next();
};

export const securityHeaders: RequestHandler = (_req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self'",
      "img-src 'self' http: https: data:",
      "connect-src 'self'",
      "object-src 'none'",
      "frame-src 'none'",
      "base-uri 'none'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ].join('; '),
  );
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  next();
};

export const notFoundApi: RequestHandler = (req, _res, next) => {
  next(new AppError(404, 'NOT_FOUND', `接口不存在：${req.method} ${req.path}`));
};

export function createErrorHandler(logger: Pick<Console, 'error' | 'warn'> = console): ErrorRequestHandler {
  return (err, req, res, _next) => {
    let appErr: AppError;
    if (err instanceof AppError) {
      appErr = err;
    } else if (err?.type === 'entity.parse.failed') {
      appErr = new AppError(400, 'INVALID_JSON', '请求体不是合法的 JSON。');
    } else if (err?.type === 'entity.too.large') {
      appErr = new AppError(413, 'PAYLOAD_TOO_LARGE', '请求内容过大。', { hint: 'Markdown 内容不能超过 10MB。' });
    } else {
      appErr = new AppError(500, 'INTERNAL_ERROR', `服务器内部错误：${err instanceof Error ? err.message : String(err)}`, {
        hint: '请查看启动服务的终端日志获取详细信息。',
      });
    }
    // Only log code/message/path: never request bodies, cookies or headers.
    const line = `[api] ${req.method} ${req.path} -> ${appErr.status} ${appErr.code}: ${appErr.message}`;
    if (appErr.status >= 500) logger.error(line, err instanceof AppError ? '' : err);
    else logger.warn(line);

    const body: ApiFailure = {
      ok: false,
      error: { code: appErr.code, message: appErr.message, hint: appErr.hint, details: appErr.details },
    };
    res.status(appErr.status).json(body);
  };
}
