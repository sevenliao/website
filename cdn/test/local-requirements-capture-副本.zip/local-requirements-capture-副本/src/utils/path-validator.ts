import path from 'node:path';
import { AppError } from './errors.js';

const MAX_BASENAME_LENGTH = 120;
// eslint-disable-next-line no-control-regex
const FORBIDDEN_CHARS = /[<>:"/\\|?*\u0000-\u001f\u007f]/;
const WINDOWS_RESERVED = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;

/**
 * Validates a user supplied Markdown file name and returns it with a single `.md` suffix.
 * Only a bare file name is accepted: directory separators, `..`, absolute paths and
 * control characters are rejected rather than silently rewritten.
 */
export function normalizeMarkdownFileName(input: unknown): string {
  if (typeof input !== 'string' || input.trim() === '') {
    throw new AppError(400, 'INVALID_FILE_NAME', '请输入文件名。');
  }
  const trimmed = input.trim();

  if (trimmed.includes('..') || path.isAbsolute(trimmed) || /^[a-zA-Z]:/.test(trimmed)) {
    throw new AppError(400, 'INVALID_FILE_NAME', `文件名不能包含路径：${trimmed}`, {
      hint: '只需填写文件名，例如 "login-requirement"，文件会保存到需求文档目录。',
    });
  }
  if (FORBIDDEN_CHARS.test(trimmed)) {
    throw new AppError(400, 'INVALID_FILE_NAME', `文件名包含不允许的字符：${trimmed}`, {
      hint: '文件名不能包含 / \\ : * ? " < > | 或控制字符。',
    });
  }

  const base = trimmed.replace(/\.md$/i, '').trim();
  if (base === '' || base.startsWith('.')) {
    throw new AppError(400, 'INVALID_FILE_NAME', '文件名不能为空，也不能以 "." 开头。');
  }
  if (base.endsWith('.') || base.endsWith(' ')) {
    throw new AppError(400, 'INVALID_FILE_NAME', '文件名不能以 "." 或空格结尾。');
  }
  if (WINDOWS_RESERVED.test(base)) {
    throw new AppError(400, 'INVALID_FILE_NAME', `"${base}" 是系统保留名称，请换一个文件名。`);
  }
  if ([...base].length > MAX_BASENAME_LENGTH) {
    throw new AppError(400, 'INVALID_FILE_NAME', `文件名过长（最多 ${MAX_BASENAME_LENGTH} 个字符）。`);
  }
  return `${base}.md`;
}

/**
 * Resolves `relative` inside `baseDir` and throws if the result escapes the directory.
 */
export function resolveInsideDirectory(baseDir: string, relative: string): string {
  const base = path.resolve(baseDir);
  const target = path.resolve(base, relative);
  if (!isPathInside(base, target)) {
    throw new AppError(400, 'PATH_OUTSIDE_ALLOWED_DIR', '目标路径超出了允许的需求文档目录。');
  }
  return target;
}

export function isPathInside(baseDir: string, target: string): boolean {
  const rel = path.relative(path.resolve(baseDir), path.resolve(target));
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

/** Builds a safe default file name from a document title, keeping CJK characters. */
export function suggestFileName(title: string, fallback = 'requirement'): string {
  const cleaned = title
    .normalize('NFKC')
    .replace(/[<>:"/\\|?*\u0000-\u001f\u007f]/g, ' ')
    .replace(/[\s.]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase();
  const limited = [...cleaned].slice(0, 80).join('').replace(/-$/, '');
  if (!limited || WINDOWS_RESERVED.test(limited)) return fallback;
  return limited;
}
