import { Router } from 'express';
import type { CaptureRequest, CaptureService } from '../services/capture-service.js';
import type { ExtractionMode } from '../types/index.js';
import { AppError } from '../utils/errors.js';
import { sendOk } from '../utils/http.js';

const MODES: readonly ExtractionMode[] = ['auto', 'body', 'selector'];

export function parseCaptureRequest(body: unknown): CaptureRequest {
  const b = (body ?? {}) as Record<string, unknown>;
  const mode = (b.mode ?? 'auto') as ExtractionMode;
  if (!MODES.includes(mode)) {
    throw new AppError(400, 'INVALID_CAPTURE_OPTIONS', `未知的提取模式：${String(b.mode)}`);
  }
  if (b.selector !== undefined && typeof b.selector !== 'string') {
    throw new AppError(400, 'INVALID_CAPTURE_OPTIONS', 'selector 必须是字符串。');
  }
  const selector = typeof b.selector === 'string' ? b.selector.trim() : undefined;
  if (selector && selector.length > 500) {
    throw new AppError(400, 'INVALID_SELECTOR', 'CSS 选择器过长。');
  }
  return {
    mode,
    selector,
    includeHidden: b.includeHidden === true,
    waitForNetworkIdle: b.waitForNetworkIdle !== false,
    autoScroll: b.autoScroll === true,
  };
}

export function createCaptureRouter(capture: CaptureService): Router {
  const router = Router();
  router.post('/', async (req, res) => {
    sendOk(res, await capture.capture(parseCaptureRequest(req.body)));
  });
  return router;
}
