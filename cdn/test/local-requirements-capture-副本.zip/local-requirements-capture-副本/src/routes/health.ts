import { Router } from 'express';
import { sendOk } from '../utils/http.js';

export function createHealthRouter(info: { requirementsDir: string; version: string }): Router {
  const router = Router();
  const startedAt = new Date().toISOString();
  router.get('/', (_req, res) => {
    sendOk(res, {
      status: 'ok',
      version: info.version,
      startedAt,
      uptimeSeconds: Math.round(process.uptime()),
      node: process.version,
      requirementsDir: info.requirementsDir,
    });
  });
  return router;
}
