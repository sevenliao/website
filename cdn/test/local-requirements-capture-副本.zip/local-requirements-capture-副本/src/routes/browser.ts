import { Router } from 'express';
import type { BrowserController } from '../services/browser-manager.js';
import { sendOk } from '../utils/http.js';
import { validateDocumentUrl } from '../utils/url-validator.js';

export function createBrowserRouter(browser: BrowserController): Router {
  const router = Router();

  router.post('/open', async (req, res) => {
    const url = validateDocumentUrl(req.body?.url);
    sendOk(res, await browser.open(url));
  });

  router.get('/status', async (_req, res) => {
    sendOk(res, await browser.status());
  });

  router.post('/close', async (_req, res) => {
    await browser.close();
    sendOk(res, await browser.status());
  });

  return router;
}
