import { Router } from 'express';
import type { ResourceFetcher } from '../services/asset-service.js';
import type { FileService } from '../services/file-service.js';
import { sendOk } from '../utils/http.js';

export function createSaveRouter(files: FileService, fetcher: ResourceFetcher): Router {
  const router = Router();

  router.post('/check', async (req, res) => {
    sendOk(res, await files.describeTarget(req.body?.fileName));
  });

  router.post('/', async (req, res) => {
    const body = req.body ?? {};
    const result = await files.save(
      {
        fileName: body.fileName,
        markdown: body.markdown,
        overwrite: body.overwrite,
        downloadImages: body.downloadImages,
      },
      fetcher,
    );
    sendOk(res, result);
  });

  return router;
}
