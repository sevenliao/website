import fs from 'node:fs/promises';
import { chromium, type BrowserContext, type Frame, type Page, type Response } from 'playwright';
import type {
  BrowserSnapshotResult,
  BrowserStatus,
  CaptureWarning,
  FrameSnapshot,
  NavigationState,
  PageSnapshot,
  SnapshotOptions,
} from '../types/index.js';
import { AppError, errorMessage } from '../utils/errors.js';
import { redactUrl } from '../utils/url-validator.js';
import { AUTO_SCROLL_SCRIPT, PAGE_SNAPSHOT_SCRIPT } from './page-snapshot-script.js';

export interface BrowserManagerOptions {
  profileDir: string;
  headless: boolean;
  navigationTimeoutMs: number;
  logger?: Pick<Console, 'info' | 'warn' | 'error'>;
}

export interface FetchedResource {
  contentType: string;
  body: Buffer;
}

/** Abstraction used by routes and services; lets tests substitute a fake browser. */
export interface BrowserController {
  open(url: URL): Promise<BrowserStatus>;
  status(): Promise<BrowserStatus>;
  snapshot(options: SnapshotOptions): Promise<BrowserSnapshotResult>;
  fetchResource(url: string): Promise<FetchedResource>;
  close(): Promise<void>;
}

const LOGIN_URL_PATTERN = /(login|signin|sign-in|sso|oauth|auth|passport|cas\/)/i;
const MAX_FRAMES = 10;
const MAX_RESOURCE_BYTES = 20 * 1024 * 1024;

function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise<T>((resolve) => {
    const timer = setTimeout(() => resolve(fallback), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      () => { clearTimeout(timer); resolve(fallback); },
    );
  });
}

/** Maps Playwright / Chromium navigation errors to user facing errors. */
export function mapNavigationError(err: unknown, url: string, timeoutMs: number): AppError {
  const msg = errorMessage(err);
  const opts = { cause: err, details: { url: redactUrl(url) } };
  if (/Timeout .*exceeded/i.test(msg) || /TimeoutError/.test(msg)) {
    return new AppError(504, 'NAVIGATION_TIMEOUT', `页面在 ${Math.round(timeoutMs / 1000)} 秒内没有加载完成。`, {
      ...opts,
      hint: '浏览器窗口仍保持打开。如果页面已在浏览器中显示，可以直接等待其加载后点击“开始采集”；否则请检查网络后重试。',
    });
  }
  if (/ERR_NAME_NOT_RESOLVED|ERR_NAME_RESOLUTION_FAILED/.test(msg)) {
    return new AppError(502, 'DNS_ERROR', '无法解析目标域名（DNS 错误）。', {
      ...opts,
      hint: '请检查 URL 拼写、网络连接，或是否需要连接公司 VPN / 内网。',
    });
  }
  if (/ERR_CERT_|ERR_SSL_|SSL_PROTOCOL_ERROR/.test(msg)) {
    return new AppError(502, 'TLS_ERROR', '目标网站的 TLS/SSL 证书校验失败。', {
      ...opts,
      hint: '请确认地址正确、系统时间准确；公司内网证书需要先安装到系统信任列表。本工具不会忽略证书错误。',
    });
  }
  if (/ERR_CONNECTION_REFUSED|ERR_CONNECTION_RESET|ERR_CONNECTION_CLOSED|ERR_CONNECTION_TIMED_OUT|ERR_ADDRESS_UNREACHABLE|ERR_INTERNET_DISCONNECTED|ERR_NETWORK_CHANGED|ERR_PROXY/.test(msg)) {
    return new AppError(502, 'NETWORK_ERROR', '无法连接到目标网站。', {
      ...opts,
      hint: '请检查网络、代理或 VPN 设置，并确认目标网站可访问。',
    });
  }
  if (/ERR_UNSAFE_PORT/.test(msg)) {
    return new AppError(400, 'UNSAFE_PORT', '浏览器拒绝访问该端口（Chromium 将其视为不安全端口）。', {
      ...opts,
      hint: '请确认 URL 中的端口号是否正确。',
    });
  }
  if (/ERR_ABORTED/.test(msg)) {
    return new AppError(502, 'NAVIGATION_ABORTED', '页面导航被中断（可能被重定向、下载或在浏览器中被手动打断）。', {
      ...opts,
      hint: '请查看浏览器窗口当前显示的页面；如果目标文档已经打开，可以直接采集。',
    });
  }
  if (/closed|Target page, context or browser has been closed/i.test(msg)) {
    return browserClosedError(err);
  }
  return new AppError(502, 'NAVIGATION_FAILED', `打开页面失败：${msg.split('\n')[0]}`, {
    ...opts,
    hint: '请确认 URL 可以在普通浏览器中访问后重试。',
  });
}

function browserClosedError(cause?: unknown): AppError {
  return new AppError(409, 'BROWSER_CLOSED', '浏览器或页面已被关闭。', {
    cause,
    hint: '请重新点击“打开浏览器”。登录状态保存在本地浏览器数据目录中，通常无需重新登录。',
  });
}

function mapLaunchError(err: unknown): AppError {
  const msg = errorMessage(err);
  if (/Executable doesn't exist|browserType\.launch.*install/i.test(msg)) {
    return new AppError(500, 'BROWSER_NOT_INSTALLED', '未找到 Playwright Chromium 浏览器。', {
      cause: err,
      hint: '请在项目目录执行：npx playwright install chromium，然后重试。',
    });
  }
  if (/ProcessSingleton|SingletonLock|profile.*in use|user data directory is already in use/i.test(msg)) {
    return new AppError(409, 'PROFILE_LOCKED', '浏览器用户数据目录正被另一个浏览器进程占用。', {
      cause: err,
      hint: '请关闭之前由本工具打开的 Chromium 窗口或其他占用该目录的进程后重试。',
    });
  }
  return new AppError(500, 'BROWSER_LAUNCH_FAILED', `启动浏览器失败：${msg.split('\n')[0]}`, { cause: err });
}

export class BrowserManager implements BrowserController {
  private context: BrowserContext | null = null;
  private activePage: Page | null = null;
  private launching: Promise<BrowserContext> | null = null;
  private navigating = false;
  private capturing = false;
  private navigationState: NavigationState = 'idle';
  private lastHttpStatus: number | null = null;
  private lastError: string | null = null;
  private readonly log: Pick<Console, 'info' | 'warn' | 'error'>;

  constructor(private readonly options: BrowserManagerOptions) {
    this.log = options.logger ?? console;
  }

  async open(url: URL): Promise<BrowserStatus> {
    if (this.launching) {
      throw new AppError(409, 'BROWSER_BUSY', '浏览器正在启动，请稍候。', { hint: '请等待当前启动完成，不要重复点击。' });
    }
    if (this.navigating) {
      throw new AppError(409, 'BROWSER_BUSY', '浏览器正在打开页面，请稍候。', { hint: '请等待当前页面加载完成，不要重复点击。' });
    }
    if (this.capturing) {
      throw new AppError(409, 'CAPTURE_IN_PROGRESS', '正在采集当前页面，请等待采集完成后再打开新地址。');
    }

    this.navigating = true;
    try {
      const context = await this.ensureContext();
      const page = await this.ensurePage(context);
      this.navigationState = 'navigating';
      this.lastError = null;
      this.lastHttpStatus = null;
      this.log.info(`[browser] navigate ${redactUrl(url.href)}`);
      let response: Response | null;
      try {
        response = await page.goto(url.href, {
          waitUntil: 'domcontentloaded',
          timeout: this.options.navigationTimeoutMs,
        });
      } catch (err) {
        const appErr = mapNavigationError(err, url.href, this.options.navigationTimeoutMs);
        this.navigationState = 'error';
        this.lastError = appErr.message;
        this.log.warn(`[browser] navigation failed: ${appErr.code}`);
        throw appErr;
      }
      this.lastHttpStatus = response?.status() ?? null;
      try { await page.bringToFront(); } catch { /* window may be minimised */ }
      return await this.status();
    } finally {
      this.navigating = false;
    }
  }

  async status(): Promise<BrowserStatus> {
    const page = this.currentPage();
    let title: string | null = null;
    let readyState: string | null = null;
    let loginSuspected = false;
    if (page) {
      title = await withTimeout(page.title(), 1000, null);
      const info = await withTimeout(
        page.evaluate(`({ readyState: document.readyState, pwd: !!document.querySelector('input[type="password"]') })`) as Promise<{ readyState: string; pwd: boolean }>,
        1000,
        null,
      );
      readyState = info?.readyState ?? null;
      loginSuspected = Boolean(info?.pwd) || LOGIN_URL_PATTERN.test(safePath(page.url()));
    }
    return {
      running: this.context !== null,
      launching: this.launching !== null,
      navigating: this.navigating,
      capturing: this.capturing,
      headless: this.options.headless,
      pageCount: this.context?.pages().length ?? 0,
      currentUrl: page ? page.url() : null,
      title,
      readyState,
      navigationState: this.navigationState,
      lastHttpStatus: this.lastHttpStatus,
      lastError: this.lastError,
      loginSuspected,
    };
  }

  async snapshot(options: SnapshotOptions): Promise<BrowserSnapshotResult> {
    if (this.capturing) {
      throw new AppError(409, 'CAPTURE_IN_PROGRESS', '正在采集中，请勿重复点击。');
    }
    if (this.launching || this.navigating) {
      throw new AppError(409, 'BROWSER_BUSY', '浏览器正在启动或打开页面，请等待完成后再采集。');
    }
    const page = this.currentPage();
    if (!this.context || !page) {
      throw new AppError(409, 'BROWSER_NOT_OPEN', '浏览器尚未打开或没有可采集的页面。', {
        hint: '请先输入 URL 并点击“打开浏览器”。',
      });
    }
    const pageUrl = page.url();
    if (!/^https?:/i.test(pageUrl)) {
      throw new AppError(409, 'NO_DOCUMENT_PAGE', `当前页面不是网页文档（${pageUrl}）。`, {
        hint: '请在浏览器中打开需要采集的文档页面后再试。',
      });
    }

    this.capturing = true;
    const warnings: CaptureWarning[] = [];
    try {
      if (options.waitForNetworkIdle) {
        try {
          await page.waitForLoadState('networkidle', { timeout: 10_000 });
        } catch (err) {
          if (page.isClosed()) throw err;
          warnings.push({
            code: 'NETWORK_IDLE_TIMEOUT',
            message: '页面在 10 秒内仍有网络请求（常见于长连接/轮询页面），已按当前已渲染内容采集。',
          });
        }
      }
      if (options.autoScroll) {
        await withTimeout(page.evaluate(AUTO_SCROLL_SCRIPT), 30_000, null);
      }

      const script = `(${PAGE_SNAPSHOT_SCRIPT})(${JSON.stringify({ includeHidden: options.includeHidden })})`;
      const main = (await page.evaluate(script)) as PageSnapshot;
      if (main.readyState !== 'complete') {
        warnings.push({ code: 'PAGE_STILL_LOADING', message: `采集时页面 readyState 为 "${main.readyState}"，内容可能尚未加载完整。` });
      }

      const frames: FrameSnapshot[] = [];
      const childFrames = page.frames().filter((f) => f !== page.mainFrame()).slice(0, MAX_FRAMES);
      for (const frame of childFrames) {
        const snap = await this.snapshotFrame(frame, script);
        if (snap) frames.push(snap);
      }
      return { main, frames, lastHttpStatus: this.lastHttpStatus, warnings };
    } catch (err) {
      if (err instanceof AppError) throw err;
      if (page.isClosed() || !this.context) throw browserClosedError(err);
      const msg = errorMessage(err);
      if (/Execution context was destroyed|navigat/i.test(msg)) {
        throw new AppError(409, 'PAGE_NAVIGATED', '采集过程中页面发生了跳转或刷新。', {
          cause: err,
          hint: '请等待页面稳定后重新点击“开始采集”。',
        });
      }
      throw new AppError(500, 'SNAPSHOT_FAILED', `读取页面内容失败：${msg.split('\n')[0]}`, { cause: err });
    } finally {
      this.capturing = false;
    }
  }

  async fetchResource(url: string): Promise<FetchedResource> {
    if (!this.context) {
      throw new AppError(409, 'BROWSER_NOT_OPEN', '浏览器未打开，无法使用登录状态下载资源。');
    }
    const response = await this.context.request.get(url, { timeout: 30_000, failOnStatusCode: false });
    if (!response.ok()) {
      throw new Error(`HTTP ${response.status()}`);
    }
    const body = await response.body();
    if (body.length > MAX_RESOURCE_BYTES) throw new Error('文件超过 20MB 限制');
    return { contentType: response.headers()['content-type'] ?? '', body };
  }

  async close(): Promise<void> {
    const ctx = this.context;
    this.resetState();
    if (ctx) {
      try { await ctx.close(); } catch (err) { this.log.warn(`[browser] close failed: ${errorMessage(err)}`); }
    }
  }

  private async snapshotFrame(frame: Frame, script: string): Promise<FrameSnapshot | null> {
    if (frame.isDetached() || !/^https?:/i.test(frame.url())) return null;
    const snap = await withTimeout(frame.evaluate(script) as Promise<PageSnapshot>, 5000, null);
    return snap ? { ...snap, frameUrl: frame.url() } : null;
  }

  private currentPage(): Page | null {
    if (!this.context) return null;
    if (this.activePage && !this.activePage.isClosed()) return this.activePage;
    const pages = this.context.pages().filter((p) => !p.isClosed());
    this.activePage = pages.at(-1) ?? null;
    return this.activePage;
  }

  private async ensurePage(context: BrowserContext): Promise<Page> {
    const existing = this.currentPage();
    if (existing) return existing;
    const page = await context.newPage();
    this.trackPage(page);
    this.activePage = page;
    return page;
  }

  private async ensureContext(): Promise<BrowserContext> {
    if (this.context) return this.context;
    this.launching = this.launch();
    try {
      return await this.launching;
    } finally {
      this.launching = null;
    }
  }

  private async launch(): Promise<BrowserContext> {
    await fs.mkdir(this.options.profileDir, { recursive: true });
    this.log.info(`[browser] launching Chromium (headless=${this.options.headless})`);
    let context: BrowserContext;
    try {
      context = await chromium.launchPersistentContext(this.options.profileDir, {
        headless: this.options.headless,
        viewport: null,
        acceptDownloads: false,
        args: ['--no-first-run', '--no-default-browser-check'],
      });
    } catch (err) {
      throw mapLaunchError(err);
    }
    context.setDefaultTimeout(15_000);
    context.on('close', () => {
      if (this.context === context) {
        this.log.info('[browser] context closed');
        this.resetState();
      }
    });
    context.on('page', (page) => {
      this.trackPage(page);
      // Follow new tabs/popups (e.g. SSO windows or "open in new tab" links).
      this.activePage = page;
    });
    for (const page of context.pages()) this.trackPage(page);
    this.context = context;
    this.activePage = context.pages()[0] ?? null;
    return context;
  }

  private trackPage(page: Page): void {
    page.on('close', () => {
      if (this.activePage === page) this.activePage = null;
    });
    page.on('framenavigated', (frame) => {
      if (frame === page.mainFrame() && page === this.activePage) this.navigationState = 'navigating';
    });
    // A failed navigation still "loads" Chromium's internal error page.
    const loadedState = (state: NavigationState): NavigationState =>
      page.url().startsWith('chrome-error://') ? 'error' : state;
    page.on('domcontentloaded', () => {
      if (page === this.activePage) this.navigationState = loadedState('domcontentloaded');
    });
    page.on('load', () => {
      if (page === this.activePage) this.navigationState = loadedState('loaded');
    });
  }

  private resetState(): void {
    this.context = null;
    this.activePage = null;
    this.navigationState = 'idle';
    this.navigating = false;
    this.capturing = false;
  }
}

function safePath(raw: string): string {
  try {
    const u = new URL(raw);
    return u.hostname + u.pathname;
  } catch {
    return '';
  }
}
