import TurndownService from 'turndown';
import * as cheerio from 'cheerio';
import type { CaptureWarning, ConversionResult } from '../types/index.js';
import { AppError, errorMessage } from '../utils/errors.js';

type TNode = TurndownService.Node;

const KEEP_TABLE_ATTRS = new Set(['colspan', 'rowspan', 'href', 'src', 'alt', 'title']);

function childElements(node: TNode, names: string[]): HTMLElement[] {
  return Array.from(node.childNodes).filter(
    (c): c is HTMLElement => c.nodeType === 1 && names.includes((c as HTMLElement).nodeName),
  );
}

function tableRows(table: TNode): HTMLElement[] {
  const rows: HTMLElement[] = [];
  for (const child of childElements(table, ['THEAD', 'TBODY', 'TFOOT', 'TR'])) {
    if (child.nodeName === 'TR') rows.push(child);
    else rows.push(...childElements(child as unknown as TNode, ['TR']));
  }
  return rows;
}

function isComplexTable(table: TNode, rows: HTMLElement[]): boolean {
  if (table.querySelector('table')) return true;
  for (const row of rows) {
    for (const cell of childElements(row as unknown as TNode, ['TD', 'TH'])) {
      const colspan = Number(cell.getAttribute('colspan') ?? '1');
      const rowspan = Number(cell.getAttribute('rowspan') ?? '1');
      if (colspan > 1 || rowspan > 1) return true;
    }
  }
  return false;
}

function cleanTableHtml(html: string): string {
  const $ = cheerio.load(html, null, false);
  $('*').each((_, el) => {
    if (el.type !== 'tag') return;
    for (const name of Object.keys(el.attribs)) {
      if (!KEEP_TABLE_ATTRS.has(name)) $(el).removeAttr(name);
    }
  });
  return $.html()
    .replace(/>\s+</g, '><')
    .replace(/<(\/?)(table|thead|tbody|tfoot|tr)>/g, '\n<$1$2>')
    .trim();
}

function fence(code: string, language = ''): string {
  const longest = Math.max(2, ...Array.from(code.matchAll(/`+/g), (m) => m[0].length));
  const marker = '`'.repeat(Math.max(3, longest + 1));
  return `\n\n${marker}${language}\n${code.replace(/\n$/, '')}\n${marker}\n\n`;
}

function classOf(node: unknown): string {
  return (node as HTMLElement | null)?.getAttribute?.('class') ?? '';
}

function languageOf(node: TNode | null): string {
  const cls = `${classOf(node)} ${classOf(node?.parentNode)}`;
  const m = cls.match(/(?:language|lang)-([\w+#.-]+)/);
  return m?.[1] ?? '';
}

interface ConversionCounters {
  complexTables: number;
}

function createService(counters: ConversionCounters): TurndownService {
  const service = new TurndownService({
    headingStyle: 'atx',
    hr: '---',
    bulletListMarker: '-',
    codeBlockStyle: 'fenced',
    fence: '```',
    emDelimiter: '*',
    strongDelimiter: '**',
    linkStyle: 'inlined',
  });

  service.remove(['script', 'style', 'noscript', 'template', 'button', 'select', 'textarea', 'canvas', 'head']);

  const cellToMarkdown = (cell: HTMLElement): string =>
    service
      .turndown(cell.innerHTML || '')
      .trim()
      .replace(/[ \t]*\n+[ \t]*/g, '<br>')
      .replace(/\|/g, '\\|')
      .trim();

  service.addRule('table', {
    filter: 'table',
    replacement: (_content, node) => {
      const rows = tableRows(node);
      if (rows.length === 0) return '';
      if (isComplexTable(node, rows)) {
        counters.complexTables++;
        return `\n\n${cleanTableHtml((node as HTMLElement).outerHTML)}\n\n`;
      }
      const matrix = rows.map((r) => childElements(r as unknown as TNode, ['TD', 'TH']).map(cellToMarkdown));
      const width = Math.max(...matrix.map((r) => r.length));
      if (width === 0) return '';
      if (width === 1 && matrix.length === 1) return `\n\n${matrix[0]?.[0] ?? ''}\n\n`;
      const pad = (r: string[]) => Array.from({ length: width }, (_, i) => r[i] ?? '');
      const line = (r: string[]) => `| ${pad(r).join(' | ')} |`;
      const [head, ...body] = matrix;
      const out = [line(head ?? []), `| ${Array(width).fill('---').join(' | ')} |`, ...body.map(line)];
      return `\n\n${out.join('\n')}\n\n`;
    },
  });

  service.addRule('preWithoutCode', {
    filter: (node) => node.nodeName === 'PRE' && !(node.firstChild && node.firstChild.nodeName === 'CODE'),
    replacement: (_content, node) => fence(node.textContent ?? '', languageOf(node)),
  });

  service.addRule('fencedCode', {
    filter: (node) => node.nodeName === 'PRE' && !!node.firstChild && node.firstChild.nodeName === 'CODE',
    replacement: (_content, node) => {
      const code = node.firstChild as unknown as TNode;
      return fence(code.textContent ?? '', languageOf(code));
    },
  });

  service.addRule('strikethrough', {
    filter: ['del', 's', 'strike' as keyof HTMLElementTagNameMap],
    replacement: (content) => (content.trim() ? `~~${content}~~` : ''),
  });

  service.addRule('checkbox', {
    filter: (node) => node.nodeName === 'INPUT' && ['checkbox', 'radio'].includes(node.getAttribute('type') ?? ''),
    replacement: (_content, node) => (node.hasAttribute('checked') ? '[x] ' : '[ ] '),
  });

  service.addRule('listItem', {
    filter: 'li',
    replacement: (content, node, options) => {
      const parent = node.parentNode as HTMLElement | null;
      let prefix = `${options.bulletListMarker} `;
      if (parent?.nodeName === 'OL') {
        const start = Number(parent.getAttribute('start') ?? '1') || 1;
        prefix = `${start + Array.prototype.indexOf.call(parent.children, node)}. `;
      }
      const body = content
        .replace(/^\n+/, '')
        .replace(/\n+$/, '\n')
        .replace(/^(\[[ x]\]) +/, '$1 ')
        .replace(/\n/gm, `\n${' '.repeat(prefix.length)}`);
      return prefix + body + (node.nextSibling && !/\n$/.test(body) ? '\n' : '');
    },
  });

  service.addRule('emptyLink', {
    filter: (node) => node.nodeName === 'A' && !!node.getAttribute('href') && !node.textContent?.trim() && !node.querySelector('img'),
    replacement: () => '',
  });

  service.addRule('media', {
    filter: ['video', 'audio', 'embed', 'object'],
    replacement: (_content, node) => {
      const el = node as HTMLElement;
      const src = el.getAttribute('src') || el.getAttribute('data') || el.querySelector('source')?.getAttribute('src') || '';
      const label = el.nodeName === 'AUDIO' ? '音频' : el.nodeName === 'VIDEO' ? '视频' : '嵌入对象';
      return src ? `\n\n[${label}](${src})\n\n` : `\n\n[${label}（无地址）]\n\n`;
    },
  });

  return service;
}

export function htmlToMarkdown(html: string): ConversionResult {
  const warnings: CaptureWarning[] = [];
  const counters: ConversionCounters = { complexTables: 0 };
  let markdown: string;
  try {
    markdown = createService(counters).turndown(html);
  } catch (err) {
    throw new AppError(500, 'MARKDOWN_CONVERSION_FAILED', `HTML 转 Markdown 失败：${errorMessage(err)}`, {
      cause: err,
      hint: '可以尝试改用“整页提取”或自定义选择器缩小采集范围后重试。',
    });
  }
  if (counters.complexTables > 0) {
    warnings.push({
      code: 'COMPLEX_TABLE',
      message: `${counters.complexTables} 个表格包含合并单元格或嵌套表格，无法用 Markdown 表格表示，已保留为精简 HTML 表格。`,
    });
  }
  markdown = markdown
    .replace(/[ \t]+$/gm, (m) => (m === '  ' ? m : ''))
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return { markdown, warnings };
}

function yamlString(value: string): string {
  return JSON.stringify(value);
}

export interface DocumentMeta {
  title: string;
  sourceUrl: string;
  capturedAt: string;
}

/**
 * Wraps the converted body with YAML front matter. Fields that are unknown are omitted
 * instead of invented. A leading `# title` is added only when the body has no H1.
 */
export function buildMarkdownDocument(meta: DocumentMeta, body: string): string {
  const lines = ['---'];
  if (meta.title) lines.push(`title: ${yamlString(meta.title)}`);
  if (meta.sourceUrl) lines.push(`source_url: ${yamlString(meta.sourceUrl)}`);
  if (meta.capturedAt) lines.push(`captured_at: ${yamlString(meta.capturedAt)}`);
  lines.push('---', '');
  const hasH1 = /^# \S/m.test(body);
  if (meta.title && !hasH1) lines.push(`# ${meta.title}`, '');
  return `${lines.join('\n')}\n${body}\n`;
}
