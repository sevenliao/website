import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import type { CaptureWarning, SaveResult, SaveTargetInfo } from '../types/index.js';
import { AppError, errorMessage } from '../utils/errors.js';
import { isPathInside, normalizeMarkdownFileName, resolveInsideDirectory } from '../utils/path-validator.js';
import { localizeImages, type ResourceFetcher } from './asset-service.js';

export const MAX_MARKDOWN_BYTES = 10 * 1024 * 1024;

export interface SaveRequest {
  fileName: unknown;
  markdown: unknown;
  overwrite?: unknown;
  downloadImages?: unknown;
}

function mapWriteError(err: unknown, target: string): AppError {
  const code = (err as NodeJS.ErrnoException)?.code;
  const hints: Record<string, string> = {
    EACCES: '没有写入权限，请检查需求文档目录的权限。',
    EPERM: '操作系统拒绝写入，请检查目录权限或文件是否被其他程序锁定。',
    ENOSPC: '磁盘空间不足，请清理磁盘后重试。',
    EROFS: '目标位置是只读文件系统。',
    EISDIR: '目标路径是一个目录，请换一个文件名。',
  };
  return new AppError(500, 'FILE_WRITE_FAILED', `写入文件失败（${code ?? 'unknown'}）：${target}`, {
    cause: err,
    hint: hints[code ?? ''] ?? `错误信息：${errorMessage(err)}`,
  });
}

export class FileService {
  constructor(private readonly requirementsDir: string, private readonly projectRoot: string) {}

  get directory(): string {
    return path.resolve(this.requirementsDir);
  }

  async describeTarget(fileNameInput: unknown): Promise<SaveTargetInfo> {
    const fileName = normalizeMarkdownFileName(fileNameInput);
    const absolutePath = resolveInsideDirectory(this.directory, fileName);
    return {
      fileName,
      absolutePath,
      relativePath: path.relative(this.projectRoot, absolutePath).split(path.sep).join('/'),
      exists: await this.exists(absolutePath),
    };
  }

  async save(request: SaveRequest, fetcher?: ResourceFetcher): Promise<SaveResult> {
    if (typeof request.markdown !== 'string' || request.markdown.trim() === '') {
      throw new AppError(400, 'EMPTY_MARKDOWN', 'Markdown 内容为空，无法保存。', { hint: '请先采集页面或在编辑区输入内容。' });
    }
    if (Buffer.byteLength(request.markdown, 'utf8') > MAX_MARKDOWN_BYTES) {
      throw new AppError(413, 'MARKDOWN_TOO_LARGE', 'Markdown 内容超过 10MB，无法保存。');
    }
    const overwrite = request.overwrite === true;
    const target = await this.describeTarget(request.fileName);

    await this.ensureDirectory();
    await this.assertNoSymlinkEscape(target.absolutePath);

    if (target.exists && !overwrite) {
      throw new AppError(409, 'FILE_EXISTS', `文件已存在：${target.relativePath}`, {
        hint: '请确认是否覆盖，或修改文件名后再保存。',
        details: { relativePath: target.relativePath, absolutePath: target.absolutePath },
      });
    }

    let markdown = request.markdown;
    let assets: SaveResult['assets'] = null;
    const warnings: CaptureWarning[] = [];
    if (request.downloadImages === true) {
      if (!fetcher) throw new AppError(500, 'DOWNLOADER_UNAVAILABLE', '图片下载器不可用。');
      const stem = target.fileName.replace(/\.md$/, '');
      const result = await localizeImages(markdown, {
        markdownDir: this.directory,
        assetsDir: resolveInsideDirectory(this.directory, path.join('assets', stem)),
        fetcher,
      });
      markdown = result.markdown;
      assets = { downloaded: result.downloaded, failed: result.failed };
      if (result.failed.length > 0) {
        warnings.push({
          code: 'IMAGE_DOWNLOAD_FAILED',
          message: `${result.failed.length} 张图片下载失败，Markdown 中保留了它们的原始 URL。`,
        });
      }
    }

    await this.write(target.absolutePath, markdown, overwrite);
    return {
      ...target,
      exists: true,
      bytes: Buffer.byteLength(markdown, 'utf8'),
      overwritten: target.exists,
      assets,
      warnings,
    };
  }

  private async write(absolutePath: string, content: string, overwrite: boolean): Promise<void> {
    try {
      if (!overwrite) {
        // 'wx' fails if the file appeared after the existence check.
        await fs.writeFile(absolutePath, content, { encoding: 'utf8', flag: 'wx' });
        return;
      }
      const tmp = path.join(path.dirname(absolutePath), `.${path.basename(absolutePath)}.${crypto.randomUUID()}.tmp`);
      try {
        await fs.writeFile(tmp, content, { encoding: 'utf8', flag: 'wx' });
        await fs.rename(tmp, absolutePath);
      } catch (err) {
        await fs.rm(tmp, { force: true });
        throw err;
      }
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'EEXIST') {
        throw new AppError(409, 'FILE_EXISTS', `文件已存在：${path.basename(absolutePath)}`, {
          hint: '请确认是否覆盖，或修改文件名后再保存。',
        });
      }
      throw mapWriteError(err, absolutePath);
    }
  }

  private async ensureDirectory(): Promise<void> {
    try {
      await fs.mkdir(this.directory, { recursive: true });
    } catch (err) {
      throw mapWriteError(err, this.directory);
    }
  }

  private async assertNoSymlinkEscape(absolutePath: string): Promise<void> {
    const realDir = await fs.realpath(this.directory);
    const stat = await fs.lstat(absolutePath).catch(() => null);
    if (stat?.isSymbolicLink()) {
      throw new AppError(400, 'PATH_OUTSIDE_ALLOWED_DIR', '目标文件是符号链接，出于安全考虑拒绝写入。');
    }
    if (stat?.isDirectory()) {
      throw new AppError(400, 'INVALID_FILE_NAME', '目标路径是一个目录，请换一个文件名。');
    }
    const realParent = await fs.realpath(path.dirname(absolutePath));
    if (realParent !== realDir && !isPathInside(realDir, realParent)) {
      throw new AppError(400, 'PATH_OUTSIDE_ALLOWED_DIR', '目标路径超出了允许的需求文档目录。');
    }
  }

  private async exists(p: string): Promise<boolean> {
    try {
      await fs.lstat(p);
      return true;
    } catch {
      return false;
    }
  }
}
