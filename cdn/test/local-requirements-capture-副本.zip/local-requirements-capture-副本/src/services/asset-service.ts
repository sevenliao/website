import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { errorMessage } from '../utils/errors.js';
import { isPathInside } from '../utils/path-validator.js';

export type ResourceFetcher = (url: string) => Promise<{ contentType: string; body: Buffer }>;

export interface LocalizeOptions {
  /** Directory that holds the Markdown file. Image paths are written relative to it. */
  markdownDir: string;
  /** Absolute directory where images for this document are stored (must be inside markdownDir). */
  assetsDir: string;
  fetcher: ResourceFetcher;
  maxImages?: number;
}

export interface LocalizeResult {
  markdown: string;
  downloaded: number;
  failed: { url: string; reason: string }[];
}

const IMAGE_PATTERN = /!\[([^\]]*)\]\((https?:\/\/[^\s)]+)(\s+"[^"]*")?\)/g;

const EXTENSIONS: Record<string, string> = {
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/jpg': '.jpg',
  'image/gif': '.gif',
  'image/webp': '.webp',
  'image/svg+xml': '.svg',
  'image/bmp': '.bmp',
  'image/avif': '.avif',
};

/**
 * Downloads remote images referenced by Markdown image syntax and rewrites them to
 * relative paths. Each rewritten image keeps its original URL in an HTML comment; images
 * that fail to download are left untouched and reported, never silently dropped.
 */
export async function localizeImages(markdown: string, options: LocalizeOptions): Promise<LocalizeResult> {
  if (!isPathInside(options.markdownDir, options.assetsDir)) {
    throw new Error('assets 目录必须位于需求文档目录内');
  }
  const urls = [...new Set(Array.from(markdown.matchAll(IMAGE_PATTERN), (m) => m[2] as string))];
  const limit = options.maxImages ?? 200;
  const failed: LocalizeResult['failed'] = [];
  const localPaths = new Map<string, string>();

  for (const [index, url] of urls.entries()) {
    if (index >= limit) {
      failed.push({ url, reason: `超过单次最多下载 ${limit} 张图片的限制` });
      continue;
    }
    try {
      const { contentType, body } = await options.fetcher(url);
      const mime = contentType.split(';')[0]?.trim().toLowerCase() ?? '';
      if (!mime.startsWith('image/')) {
        // Login-protected images often redirect to an HTML login page.
        throw new Error(`返回的不是图片（Content-Type: ${mime || '未知'}），可能需要登录或无权限`);
      }
      const ext = EXTENSIONS[mime] ?? '.img';
      const name = crypto.createHash('sha1').update(url).digest('hex').slice(0, 16) + ext;
      await fs.mkdir(options.assetsDir, { recursive: true });
      await fs.writeFile(path.join(options.assetsDir, name), body);
      const rel = path.relative(options.markdownDir, path.join(options.assetsDir, name)).split(path.sep).join('/');
      // Only characters that break a Markdown link destination are escaped, so CJK names stay readable.
      localPaths.set(url, rel.replace(/[ ()<>]/g, (c) => encodeURIComponent(c)));
    } catch (err) {
      // Playwright appends a multi-line call log (incl. request headers); keep only the summary.
      const reason = errorMessage(err).split('\n')[0]?.replace(/^apiRequestContext\.\w+:\s*/, '') ?? '';
      failed.push({ url, reason });
    }
  }

  const rewritten = markdown.replace(IMAGE_PATTERN, (whole, alt: string, url: string, title: string | undefined) => {
    const local = localPaths.get(url);
    if (!local) return whole;
    return `![${alt}](${local}${title ?? ''})<!-- original-src: ${url} -->`;
  });
  return { markdown: rewritten, downloaded: localPaths.size, failed };
}
