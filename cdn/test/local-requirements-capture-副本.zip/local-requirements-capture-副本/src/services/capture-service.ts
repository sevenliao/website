import type {
  BrowserSnapshotResult,
  CaptureResult,
  CaptureWarning,
  ExtractOptions,
  PageSnapshot,
  SnapshotOptions,
} from '../types/index.js';
import { AppError } from '../utils/errors.js';
import { suggestFileName } from '../utils/path-validator.js';
import type { BrowserController } from './browser-manager.js';
import { extractContent, statsFromHtml } from './content-extractor.js';
import { buildMarkdownDocument, htmlToMarkdown } from './markdown-converter.js';

export interface CaptureRequest extends ExtractOptions, SnapshotOptions {}

/** Chooses which document to extract: the main page, or a frame holding most of the text. */
function chooseSource(snapshot: BrowserSnapshotResult, warnings: CaptureWarning[]): PageSnapshot {
  const { main, frames } = snapshot;
  if (main.iframeCount > 0) {
    warnings.push({
      code: 'IFRAME_PRESENT',
      message: `页面包含 ${main.iframeCount} 个 iframe，iframe 内的内容不会合并进正文（仅保留其链接）。`,
    });
  }
  const richest = [...frames].sort((a, b) => b.bodyTextLength - a.bodyTextLength)[0];
  if (richest && richest.bodyTextLength >= 200 && richest.bodyTextLength > main.bodyTextLength * 2) {
    warnings.push({
      code: 'IFRAME_CONTENT_USED',
      message: `主页面文字很少，正文似乎位于 iframe（${richest.frameUrl}）中，已改为采集该 iframe 的内容。`,
    });
    return { ...richest, title: main.title || richest.title };
  }
  return main;
}

function pageLevelWarnings(snapshot: BrowserSnapshotResult, source: PageSnapshot, textLength: number): CaptureWarning[] {
  const warnings: CaptureWarning[] = [];
  const status = snapshot.lastHttpStatus;
  if (status === 401 || status === 403) {
    warnings.push({ code: 'HTTP_ERROR_STATUS', message: `打开页面时服务器返回 HTTP ${status}，可能需要登录或没有该文档的访问权限。` });
  } else if (status !== null && status >= 400) {
    warnings.push({ code: 'HTTP_ERROR_STATUS', message: `打开页面时服务器返回 HTTP ${status}，请确认文档地址是否正确。` });
  }
  if (source.hasPasswordField && textLength < 2000) {
    warnings.push({
      code: 'LOGIN_SUSPECTED',
      message: '当前页面包含密码输入框，可能是登录页。请先在浏览器窗口中完成登录并打开目标文档，再重新采集。',
    });
  }
  if (source.largeCanvasCount > 0) {
    warnings.push({
      code: 'CANVAS_PRESENT',
      message: `页面中有 ${source.largeCanvasCount} 个较大的 Canvas 画布，其中的文字/图形无法被提取（部分在线文档用 Canvas 渲染正文）。`,
    });
  }
  if (source.shadowRootCount > 0) {
    warnings.push({
      code: 'SHADOW_DOM_PRESENT',
      message: `页面使用了 ${source.shadowRootCount} 个 Shadow DOM 组件，已尽量展开其内容，结构可能与页面显示不完全一致。`,
    });
  }
  return warnings;
}

export class CaptureService {
  constructor(private readonly browser: BrowserController, private readonly now: () => Date = () => new Date()) {}

  async capture(request: CaptureRequest): Promise<CaptureResult> {
    if (request.mode === 'selector' && !request.selector?.trim()) {
      throw new AppError(400, 'INVALID_SELECTOR', '“自定义选择器”模式需要填写 CSS 选择器。');
    }
    const snapshot = await this.browser.snapshot({
      includeHidden: request.includeHidden,
      waitForNetworkIdle: request.waitForNetworkIdle,
      autoScroll: request.autoScroll,
    });
    const capturedAt = this.now().toISOString();
    const warnings: CaptureWarning[] = [...snapshot.warnings];
    const source = chooseSource(snapshot, warnings);

    let extraction;
    try {
      extraction = extractContent(
        { html: source.html, url: source.url, pageTitle: source.title, ogTitle: source.ogTitle },
        { mode: request.mode, selector: request.selector },
      );
    } catch (err) {
      if (err instanceof AppError && err.code === 'EMPTY_CONTENT') {
        const extra = pageLevelWarnings(snapshot, source, 0).map((w) => w.message);
        throw new AppError(err.status, err.code, err.message, { hint: [err.hint, ...extra].filter(Boolean).join(' ') });
      }
      throw err;
    }
    warnings.push(...extraction.warnings, ...pageLevelWarnings(snapshot, source, extraction.textLength));

    const conversion = htmlToMarkdown(extraction.contentHtml);
    warnings.push(...conversion.warnings);

    const sourceUrl = snapshot.main.url;
    const markdown = buildMarkdownDocument({ title: extraction.title, sourceUrl, capturedAt }, conversion.markdown);

    return {
      title: extraction.title,
      sourceUrl,
      capturedAt,
      markdown,
      stats: statsFromHtml(extraction.contentHtml, conversion.markdown),
      warnings,
      strategy: extraction.strategy,
      suggestedFileName: suggestFileName(extraction.title),
    };
  }
}
