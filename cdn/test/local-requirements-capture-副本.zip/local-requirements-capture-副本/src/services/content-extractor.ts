import * as cheerio from 'cheerio';
import type { CheerioAPI, Cheerio } from 'cheerio';
import type { AnyNode, Element } from 'domhandler';
import type { CaptureWarning, ContentStats, ExtractionResult, ExtractOptions } from '../types/index.js';
import { AppError } from '../utils/errors.js';

/**
 * Candidate main-content containers, in priority order. Entries are generic semantic
 * elements or well-known rich-text editor / wiki classes; none of them are guesses about a
 * specific private site's DOM.
 */
export const CONTENT_SELECTORS: readonly string[] = [
  'article',
  'main',
  '[role="main"]',
  '#main-content',
  '.wiki-content',
  '.markdown-body',
  '.notion-page-content',
  '.ProseMirror',
  '.ql-editor',
  '.ck-content',
  '.mce-content-body',
  '[contenteditable="true"]',
  '.document',
  '.doc-content',
  '.content',
  '#content',
];

const ALWAYS_REMOVE = [
  'script', 'style', 'noscript', 'template', 'link', 'meta', 'base',
  'button', 'select', 'textarea', 'dialog', 'form[role="search"]',
  'input:not([type="checkbox"]):not([type="radio"])',
  '[role="toolbar"]', '[role="menubar"]', '[role="menu"]', '[role="tooltip"]', '[role="search"]',
  '[aria-hidden="true"]:not(:has(img))',
].join(',');

const SEMANTIC_NOISE = [
  'nav', 'aside', '[role="navigation"]', '[role="complementary"]', '[role="banner"]', '[role="contentinfo"]',
].join(',');

const NOISE_PATTERN = /(^|[-_\s])(sidebar|side-bar|sidenav|navbar|nav-bar|menu|breadcrumb|toolbar|advert|ads?|ad-?banner|sponsor|cookie|consent|popup|modal|share|social|footer|header-bar|topbar|top-bar)([-_\s]|$)/i;

const UNSUPPORTED_TAGS = ['video', 'audio', 'object', 'embed', 'math'];

const MIN_CONTENT_CHARS = 200;
/** Below this coverage of the page text, the container is treated as unreliable. */
const FALLBACK_COVERAGE = 0.25;
const PARTIAL_COVERAGE = 0.5;
const MAX_DATA_URI_LENGTH = 2048;
const LAZY_IMAGE_ATTRS = ['data-src', 'data-original', 'data-lazy-src', 'data-actualsrc', 'data-url'];

export interface ExtractInput {
  html: string;
  url: string;
  pageTitle?: string;
  ogTitle?: string;
}

function textLength($el: Cheerio<AnyNode>): number {
  return $el.text().replace(/\s+/g, '').length;
}

function attrText(el: Element): string {
  return `${el.attribs.id ?? ''} ${el.attribs.class ?? ''}`;
}

function cleanCommon($: CheerioAPI, $root: Cheerio<AnyNode>): void {
  $root.find(ALWAYS_REMOVE).remove();
  $root.find('[data-lrc-hidden]').remove();
}

/** Removes navigation-like blocks. Pattern based removal is limited to small blocks. */
function removeNoise($: CheerioAPI, $root: Cheerio<AnyNode>, totalChars: number, removeSemantic: boolean): void {
  if (removeSemantic) {
    $root.find(SEMANTIC_NOISE).remove();
    $root.children('header, footer').remove();
    $root.find('body > header, body > footer').remove();
  } else {
    // Inside an identified content container keep <header> (often holds the title) but drop navs.
    $root.find('nav, [role="navigation"]').remove();
  }
  const limit = Math.max(totalChars * 0.2, 1);
  $root.find('[class], [id]').each((_, node) => {
    const el = node as Element;
    if (!NOISE_PATTERN.test(attrText(el))) return;
    const $el = $(el);
    if ($el.find('h1, h2, h3, table').length > 0) return;
    if (textLength($el) <= limit) $el.remove();
  });
}

function resolveUrl(value: string | undefined, base: string): string | null {
  if (!value) return null;
  const v = value.trim();
  if (v.startsWith('#') || v.startsWith('data:')) return v;
  try {
    const u = new URL(v, base);
    if (!['http:', 'https:', 'mailto:', 'tel:'].includes(u.protocol)) return null;
    return u.href;
  } catch {
    return null;
  }
}

function normalizeUrlsAndMedia($: CheerioAPI, $root: Cheerio<AnyNode>, baseUrl: string, warnings: CaptureWarning[]): void {
  $root.find('a[href]').each((_, node) => {
    const $a = $(node);
    const href = resolveUrl($a.attr('href'), baseUrl);
    if (href === null) $a.removeAttr('href');
    else $a.attr('href', href);
  });

  let omittedDataImages = 0;
  $root.find('img').each((_, node) => {
    const $img = $(node);
    let raw = $img.attr('src') ?? '';
    if (!raw || (raw.startsWith('data:') && raw.length <= MAX_DATA_URI_LENGTH)) {
      raw = LAZY_IMAGE_ATTRS.map((a) => $img.attr(a)).find((v) => v && v.trim()) ?? raw;
    }
    if (raw.startsWith('data:')) {
      if (raw.length > MAX_DATA_URI_LENGTH) {
        omittedDataImages++;
        const alt = $img.attr('alt')?.trim();
        $img.replaceWith(`<span>[内嵌图片${alt ? `：${alt}` : ''}（data URI 已省略）]</span>`);
        return;
      }
      // Tiny data URIs are tracking pixels / placeholders.
      $img.remove();
      return;
    }
    const src = resolveUrl(raw, baseUrl);
    if (!src) {
      $img.remove();
      return;
    }
    $img.attr('src', src);
  });
  if (omittedDataImages > 0) {
    warnings.push({
      code: 'DATA_IMAGE_OMITTED',
      message: `${omittedDataImages} 张以 data URI 内嵌的图片体积较大，未写入 Markdown，仅保留占位文字。`,
    });
  }

  $root.find('iframe').each((_, node) => {
    const $f = $(node);
    const src = resolveUrl($f.attr('src'), baseUrl);
    $f.replaceWith(src && !src.startsWith('data:') ? `<p>[嵌入内容：<a href="${escapeAttr(src)}">${escapeHtml(src)}</a>]</p>` : '');
  });
  $root.find('svg').each((_, node) => {
    const $svg = $(node);
    const label = $svg.attr('aria-label') || $svg.find('title').first().text();
    $svg.replaceWith(label ? `<span>[图形：${escapeHtml(label)}]</span>` : '');
  });
  $root.find('canvas').remove();
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escapeAttr(s: string): string {
  return escapeHtml(s).replace(/"/g, '&quot;');
}

/** Characters inside an enclosing <main>/[role=main] that are not part of the chosen container. */
function textOutsideInMainArea($: CheerioAPI, $candidate: Cheerio<Element>): number {
  const $main = $candidate.parents('main, [role="main"]').first();
  if ($main.length === 0) return 0;
  const $clone = $main.clone();
  removeNoise($, $clone, textLength($main), false);
  return Math.max(0, textLength($clone) - textLength($candidate));
}

function pickCandidate($: CheerioAPI, $body: Cheerio<Element>): { el: Cheerio<Element>; selector: string } | null {
  for (const selector of CONTENT_SELECTORS) {
    const matches = $body.find(selector).toArray() as Element[];
    if (matches.length === 0) continue;
    let best: Element | null = null;
    let bestLen = 0;
    for (const m of matches) {
      const len = textLength($(m));
      if (len > bestLen) { best = m; bestLen = len; }
    }
    if (best && bestLen >= 50) return { el: $(best), selector };
  }
  return null;
}

export function computeStats($: CheerioAPI, $root: Cheerio<AnyNode>): Omit<ContentStats, 'characters'> {
  return {
    headings: $root.find('h1, h2, h3, h4, h5, h6').length,
    paragraphs: $root.find('p').length,
    lists: $root.find('ul, ol').length,
    tables: $root.find('table').length,
    images: $root.find('img').length,
    links: $root.find('a[href]').length,
    codeBlocks: $root.find('pre').length,
    blockquotes: $root.find('blockquote').length,
  };
}

/**
 * Extracts the main document content from a full page HTML snapshot.
 * Throws EMPTY_CONTENT when nothing meaningful is left after cleaning.
 */
export function extractContent(input: ExtractInput, options: ExtractOptions = { mode: 'auto' }): ExtractionResult {
  const $ = cheerio.load(input.html);
  const warnings: CaptureWarning[] = [];
  const $body = $('body').length ? $('body') : $.root().children().first() as Cheerio<Element>;

  cleanCommon($, $body);
  const totalChars = textLength($body);

  let $content: Cheerio<AnyNode>;
  let strategy: ExtractionResult['strategy'];

  if (options.mode === 'selector') {
    const selector = options.selector?.trim();
    if (!selector) {
      throw new AppError(400, 'INVALID_SELECTOR', '请选择“自定义选择器”模式时，需要填写 CSS 选择器。');
    }
    let matches: Cheerio<Element>;
    try {
      matches = $body.find(selector) as Cheerio<Element>;
    } catch (err) {
      throw new AppError(400, 'INVALID_SELECTOR', `CSS 选择器无效：${selector}`, { cause: err });
    }
    if (matches.length === 0) {
      throw new AppError(422, 'SELECTOR_NOT_FOUND', `页面中没有找到匹配 "${selector}" 的元素。`, {
        hint: '请在浏览器开发者工具中确认选择器，或改用“自动识别”模式。',
      });
    }
    const wrapper = $('<div></div>');
    matches.each((_, m) => { wrapper.append($(m).clone()); });
    $content = wrapper;
    removeNoise($, $content, totalChars, false);
    strategy = { type: 'selector', selector, coverage: 0 };
  } else if (options.mode === 'body') {
    $content = $body.clone();
    removeNoise($, $content, totalChars, true);
    strategy = { type: 'body', selector: 'body', coverage: 0 };
  } else {
    const candidate = pickCandidate($, $body);
    if (candidate) {
      const candidateChars = textLength(candidate.el);
      const coverage = totalChars > 0 ? candidateChars / totalChars : 0;
      if (coverage < FALLBACK_COVERAGE && totalChars >= MIN_CONTENT_CHARS) {
        $content = $body.clone();
        removeNoise($, $content, totalChars, true);
        strategy = { type: 'body-fallback', selector: 'body', coverage: 0 };
        warnings.push({
          code: 'CONTENT_PARTIAL',
          message: `识别到的正文容器 "${candidate.selector}" 只包含页面约 ${Math.round(coverage * 100)}% 的文字，为避免丢失内容已回退为整页提取（已去除导航、页脚等）。可改用自定义选择器精确指定正文。`,
        });
      } else {
        $content = candidate.el.clone();
        removeNoise($, $content, candidateChars, false);
        strategy = { type: 'candidate', selector: candidate.selector, coverage: 0 };
        if (coverage < PARTIAL_COVERAGE && totalChars >= MIN_CONTENT_CHARS) {
          warnings.push({
            code: 'CONTENT_PARTIAL',
            message: `正文容器 "${candidate.selector}" 约占页面文字的 ${Math.round(coverage * 100)}%，其余部分已作为导航/侧边栏排除。请核对是否有正文遗漏。`,
          });
        }
        const outside = textOutsideInMainArea($, candidate.el);
        if (outside > Math.max(20, candidateChars * 0.05)) {
          warnings.push({
            code: 'CONTENT_PARTIAL',
            message: `主内容区域（main）中还有约 ${outside} 个字符位于 "${candidate.selector}" 之外，未被采集。如有遗漏，请改用自定义选择器 "main" 或整页提取。`,
          });
        }
      }
    } else {
      $content = $body.clone();
      removeNoise($, $content, totalChars, true);
      strategy = { type: 'body-fallback', selector: 'body', coverage: 0 };
      warnings.push({
        code: 'CONTAINER_NOT_FOUND',
        message: '未识别到常见正文容器（main / article / 富文本编辑器等），已按整页提取并去除导航、页脚。请检查是否混入无关内容。',
      });
    }
  }

  normalizeUrlsAndMedia($, $content, input.url, warnings);

  const unsupported = UNSUPPORTED_TAGS.filter((t) => $content.find(t).length > 0);
  if (unsupported.length > 0) {
    warnings.push({
      code: 'UNSUPPORTED_ELEMENT',
      message: `正文包含无法直接转换为 Markdown 的元素（${unsupported.join(', ')}），已尽量保留其链接，请人工核对。`,
    });
  }

  const contentChars = textLength($content);
  const imageCount = $content.find('img').length;
  if (contentChars === 0 && imageCount === 0) {
    throw new AppError(422, 'EMPTY_CONTENT', '没有从当前页面提取到正文内容。', {
      hint: '可能原因：页面尚未加载完成、需要登录或无访问权限、正文在 Canvas 中渲染、或正文容器识别错误。请在浏览器中确认文档已显示后重试，或尝试“整页提取”/自定义选择器。',
    });
  }
  if (contentChars < MIN_CONTENT_CHARS) {
    warnings.push({
      code: 'CONTENT_SHORT',
      message: `提取到的正文只有 ${contentChars} 个字符，内容可能不完整（页面未加载完、需要登录或正文位于 iframe / Canvas 中）。`,
    });
  }
  strategy.coverage = totalChars > 0 ? Math.min(1, contentChars / totalChars) : 0;

  const h1 = $content.find('h1').first().text().replace(/\s+/g, ' ').trim();
  // The first <h1> of the content is usually the document title; <title> often carries a site suffix.
  const title = (h1 || input.pageTitle?.trim() || input.ogTitle?.trim() || '').replace(/\s+/g, ' ');

  const contentHtml = $.html($content.contents());
  return { title, contentHtml, strategy, textLength: contentChars, warnings };
}

export function statsFromHtml(contentHtml: string, markdown: string): ContentStats {
  const $ = cheerio.load(`<div id="lrc-root">${contentHtml}</div>`);
  return { characters: markdown.length, ...computeStats($, $('#lrc-root')) };
}
