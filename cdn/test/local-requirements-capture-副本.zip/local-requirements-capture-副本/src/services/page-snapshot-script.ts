/**
 * Script evaluated inside the target page. It must stay a plain string: when it is a
 * TypeScript function, tsx/esbuild may inject helpers (e.g. `__name`) that do not exist
 * in the page context.
 *
 * It clones <body>, walks the live DOM and the clone in lockstep, removes elements that
 * are not rendered (display:none / visibility:hidden), resolves link and image URLs to
 * absolute form (including common lazy-load attributes) and inlines open shadow roots.
 * The live page DOM is never modified.
 */
export const PAGE_SNAPSHOT_SCRIPT = String.raw`
((options) => {
  const includeHidden = !!(options && options.includeHidden);
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'LINK', 'META']);
  const LAZY_ATTRS = ['data-src', 'data-original', 'data-lazy-src', 'data-actualsrc', 'data-url'];
  const body = document.body;
  const result = {
    url: location.href,
    title: document.title || '',
    ogTitle: (document.querySelector('meta[property="og:title"]') || {}).content || '',
    html: '',
    readyState: document.readyState,
    bodyTextLength: 0,
    hasPasswordField: false,
    iframeCount: 0,
    canvasCount: 0,
    largeCanvasCount: 0,
    shadowRootCount: 0,
    hiddenRemovedCount: 0,
  };
  if (!body) return result;

  const abs = (value) => {
    if (!value) return '';
    try { return new URL(value, document.baseURI).href; } catch (e) { return value; }
  };

  const clone = body.cloneNode(true);
  const liveWalker = document.createTreeWalker(body, NodeFilter.SHOW_ELEMENT);
  const cloneWalker = document.createTreeWalker(clone, NodeFilter.SHOW_ELEMENT);
  const shadowHosts = [];
  let live = liveWalker.currentNode;
  let cl = cloneWalker.currentNode;

  while (live && cl) {
    const tag = live.tagName;
    if (!SKIP.has(tag)) {
      const style = getComputedStyle(live);
      if (!includeHidden && live !== body && (style.display === 'none' || style.visibility === 'hidden')) {
        cl.setAttribute('data-lrc-hidden', '1');
      }
      if (tag === 'A' && live.hasAttribute('href')) {
        cl.setAttribute('href', live.href);
      } else if (tag === 'IMG') {
        let src = live.currentSrc || live.getAttribute('src') || '';
        if (!src || src.startsWith('data:image/gif') || src.startsWith('data:image/svg')) {
          for (const attr of LAZY_ATTRS) {
            if (live.getAttribute(attr)) { src = live.getAttribute(attr); break; }
          }
        }
        cl.setAttribute('src', src.startsWith('data:') ? src : abs(src));
        cl.removeAttribute('srcset');
        if (live.naturalWidth) cl.setAttribute('data-lrc-width', String(live.naturalWidth));
      } else if (tag === 'IFRAME') {
        result.iframeCount++;
        cl.setAttribute('src', abs(live.getAttribute('src')));
      } else if (tag === 'CANVAS') {
        result.canvasCount++;
        if (live.width * live.height > 200 * 200) result.largeCanvasCount++;
      } else if (tag === 'INPUT') {
        if (live.type === 'password' && style.display !== 'none') result.hasPasswordField = true;
        if (live.type === 'checkbox' || live.type === 'radio') {
          if (live.checked) cl.setAttribute('checked', ''); else cl.removeAttribute('checked');
        }
      } else if (tag === 'VIDEO' || tag === 'AUDIO' || tag === 'SOURCE' || tag === 'EMBED') {
        if (live.getAttribute('src')) cl.setAttribute('src', abs(live.getAttribute('src')));
      }
      if (live.shadowRoot) {
        result.shadowRootCount++;
        shadowHosts.push([cl, live.shadowRoot.innerHTML]);
      }
    }
    live = liveWalker.nextNode();
    cl = cloneWalker.nextNode();
  }

  for (const [host, html] of shadowHosts) {
    if (host.getAttribute('data-lrc-hidden')) continue;
    const wrapper = document.createElement('div');
    wrapper.setAttribute('data-lrc-shadow', '1');
    wrapper.innerHTML = html;
    host.appendChild(wrapper);
  }

  if (!includeHidden) {
    const hidden = clone.querySelectorAll('[data-lrc-hidden]');
    result.hiddenRemovedCount = hidden.length;
    hidden.forEach((el) => el.remove());
  }
  clone.querySelectorAll('script,style,noscript,template,link,meta').forEach((el) => el.remove());

  result.bodyTextLength = (body.innerText || '').trim().length;
  const titleEl = document.createElement('title');
  titleEl.textContent = result.title;
  result.html = '<!DOCTYPE html><html><head>' + titleEl.outerHTML + '</head>' + clone.outerHTML + '</html>';
  return result;
})
`;

/** Scrolls the window and the largest scrollable element to trigger lazy loading. */
export const AUTO_SCROLL_SCRIPT = String.raw`
(async () => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const targets = [document.scrollingElement || document.documentElement];
  let best = null;
  let bestArea = 0;
  for (const el of document.querySelectorAll('body *')) {
    if (el.scrollHeight > el.clientHeight + 200) {
      const style = getComputedStyle(el);
      if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
        const area = el.clientWidth * el.clientHeight;
        if (area > bestArea) { best = el; bestArea = area; }
      }
    }
  }
  if (best) targets.push(best);
  for (const el of targets) {
    const start = el.scrollTop;
    for (let i = 0; i < 60; i++) {
      const before = el.scrollTop;
      el.scrollTop = before + Math.max(400, el.clientHeight * 0.8);
      await sleep(150);
      if (el.scrollTop === before) break;
    }
    await sleep(300);
    el.scrollTop = start;
  }
  return true;
})()
`;
