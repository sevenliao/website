import path from 'node:path';
import { createRequire } from 'node:module';
import express, { type Express } from 'express';
import type { AppConfig } from './config.js';
import { createBrowserRouter } from './routes/browser.js';
import { createCaptureRouter } from './routes/capture.js';
import { createHealthRouter } from './routes/health.js';
import { createSaveRouter } from './routes/save.js';
import type { ResourceFetcher } from './services/asset-service.js';
import type { BrowserController } from './services/browser-manager.js';
import { CaptureService } from './services/capture-service.js';
import { FileService } from './services/file-service.js';
import { AppError } from './utils/errors.js';
import { createErrorHandler, localOnly, notFoundApi, securityHeaders } from './utils/http.js';

export interface AppDependencies {
  config: Pick<AppConfig, 'projectRoot' | 'requirementsDir'>;
  browser: BrowserController;
  logger?: Pick<Console, 'info' | 'warn' | 'error'>;
  /** Fallback fetcher used for image downloads when the browser is not running. */
  fallbackFetch?: ResourceFetcher;
}

const require = createRequire(import.meta.url);

const VENDOR_FILES: Record<string, string> = {
  'marked.esm.js': path.join(path.dirname(require.resolve('marked')), 'marked.esm.js'),
  'purify.es.mjs': path.join(path.dirname(require.resolve('dompurify')), 'purify.es.mjs'),
};

const plainFetch: ResourceFetcher = async (url) => {
  const response = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return { contentType: response.headers.get('content-type') ?? '', body: Buffer.from(await response.arrayBuffer()) };
};

export function createApp(deps: AppDependencies): Express {
  const { config, browser } = deps;
  const logger = deps.logger ?? console;
  const files = new FileService(config.requirementsDir, config.projectRoot);
  const capture = new CaptureService(browser);
  const fallbackFetch = deps.fallbackFetch ?? plainFetch;

  // Prefer the browser context so images behind the same login can be downloaded.
  const fetcher: ResourceFetcher = async (url) => {
    try {
      return await browser.fetchResource(url);
    } catch (err) {
      if (err instanceof AppError && err.code === 'BROWSER_NOT_OPEN') return fallbackFetch(url);
      throw err;
    }
  };

  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeaders);
  app.use(localOnly);
  app.use(express.json({ limit: '12mb' }));

  app.use('/api/health', createHealthRouter({ requirementsDir: files.directory, version: '0.1.0' }));
  app.use('/api/browser', createBrowserRouter(browser));
  app.use('/api/capture', createCaptureRouter(capture));
  app.use('/api/save', createSaveRouter(files, fetcher));
  app.use('/api', notFoundApi);

  app.get('/vendor/:file', (req, res, next) => {
    const file = VENDOR_FILES[req.params.file];
    if (!file) {
      next(new AppError(404, 'NOT_FOUND', '资源不存在'));
      return;
    }
    res.type('application/javascript').sendFile(file);
  });
  app.use(express.static(path.join(config.projectRoot, 'public'), { index: 'index.html' }));

  app.use(createErrorHandler(logger));
  return app;
}
