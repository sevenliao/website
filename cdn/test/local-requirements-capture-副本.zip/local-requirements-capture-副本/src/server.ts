import fs from 'node:fs';
import { createApp } from './app.js';
import { loadConfig } from './config.js';
import { BrowserManager } from './services/browser-manager.js';

const config = loadConfig();
fs.mkdirSync(config.requirementsDir, { recursive: true });

const browser = new BrowserManager({
  profileDir: config.browserProfileDir,
  headless: config.headless,
  navigationTimeoutMs: config.navigationTimeoutMs,
});

const app = createApp({ config, browser });
const server = app.listen(config.port, config.host, () => {
  const host = config.host.includes(':') ? `[${config.host}]` : config.host;
  console.info(`本地需求文档采集工具已启动： http://${host}:${config.port}`);
  console.info(`需求文档保存目录： ${config.requirementsDir}`);
  console.info(`浏览器数据目录： ${config.browserProfileDir}`);
});

server.on('error', (err: NodeJS.ErrnoException) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`端口 ${config.port} 已被占用。请关闭占用该端口的程序，或在 .env 中设置其他 PORT。`);
  } else {
    console.error('服务启动失败：', err.message);
  }
  process.exit(1);
});

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  console.info(`收到 ${signal}，正在关闭浏览器和服务…`);
  await browser.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
