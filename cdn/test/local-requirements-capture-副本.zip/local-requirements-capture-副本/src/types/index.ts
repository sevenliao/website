export interface ApiSuccess<T> {
  ok: true;
  data: T;
}

export interface ApiErrorBody {
  code: string;
  message: string;
  hint?: string;
  details?: Record<string, unknown>;
}

export interface ApiFailure {
  ok: false;
  error: ApiErrorBody;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiFailure;

export type WarningCode =
  | 'CONTAINER_NOT_FOUND'
  | 'CONTENT_PARTIAL'
  | 'CONTENT_SHORT'
  | 'LOGIN_SUSPECTED'
  | 'HTTP_ERROR_STATUS'
  | 'IFRAME_PRESENT'
  | 'IFRAME_CONTENT_USED'
  | 'CANVAS_PRESENT'
  | 'SHADOW_DOM_PRESENT'
  | 'COMPLEX_TABLE'
  | 'UNSUPPORTED_ELEMENT'
  | 'DATA_IMAGE_OMITTED'
  | 'NETWORK_IDLE_TIMEOUT'
  | 'PAGE_STILL_LOADING'
  | 'IMAGE_DOWNLOAD_FAILED';

export interface CaptureWarning {
  code: WarningCode;
  message: string;
}

export type NavigationState = 'idle' | 'navigating' | 'domcontentloaded' | 'loaded' | 'error';

export interface BrowserStatus {
  running: boolean;
  launching: boolean;
  navigating: boolean;
  capturing: boolean;
  headless: boolean;
  pageCount: number;
  currentUrl: string | null;
  title: string | null;
  readyState: string | null;
  navigationState: NavigationState;
  lastHttpStatus: number | null;
  lastError: string | null;
  loginSuspected: boolean;
}

/** Raw DOM snapshot taken inside the real browser page. */
export interface PageSnapshot {
  url: string;
  title: string;
  ogTitle: string;
  html: string;
  readyState: string;
  bodyTextLength: number;
  hasPasswordField: boolean;
  iframeCount: number;
  canvasCount: number;
  largeCanvasCount: number;
  shadowRootCount: number;
  hiddenRemovedCount: number;
}

export interface FrameSnapshot extends PageSnapshot {
  frameUrl: string;
}

export interface SnapshotOptions {
  includeHidden: boolean;
  waitForNetworkIdle: boolean;
  autoScroll: boolean;
}

export interface BrowserSnapshotResult {
  main: PageSnapshot;
  frames: FrameSnapshot[];
  lastHttpStatus: number | null;
  warnings: CaptureWarning[];
}

export type ExtractionMode = 'auto' | 'body' | 'selector';

export interface ExtractOptions {
  mode: ExtractionMode;
  selector?: string;
}

export interface ContentStats {
  characters: number;
  headings: number;
  paragraphs: number;
  lists: number;
  tables: number;
  images: number;
  links: number;
  codeBlocks: number;
  blockquotes: number;
}

export interface ExtractionResult {
  title: string;
  contentHtml: string;
  strategy: {
    type: 'candidate' | 'selector' | 'body-fallback' | 'body';
    selector: string;
    coverage: number;
  };
  textLength: number;
  warnings: CaptureWarning[];
}

export interface ConversionResult {
  markdown: string;
  warnings: CaptureWarning[];
}

export interface CaptureResult {
  title: string;
  sourceUrl: string;
  capturedAt: string;
  markdown: string;
  stats: ContentStats;
  warnings: CaptureWarning[];
  strategy: ExtractionResult['strategy'];
  suggestedFileName: string;
}

export interface SaveTargetInfo {
  fileName: string;
  absolutePath: string;
  relativePath: string;
  exists: boolean;
}

export interface SaveResult extends SaveTargetInfo {
  bytes: number;
  overwritten: boolean;
  assets: {
    downloaded: number;
    failed: { url: string; reason: string }[];
  } | null;
  warnings: CaptureWarning[];
}
