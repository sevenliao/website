import { api, ApiError } from './lib/api.js';
import { diffLines, summarizeDiff } from './lib/diff.js';
import { applyCapture, createEditorState, isDirty, markSaved, recaptureDecision } from './lib/editor-state.js';
import { renderMarkdownInto } from './lib/markdown-render.js';

const $ = (id) => document.getElementById(id);
const el = {
  health: $('health'), healthText: $('health-text'),
  openForm: $('open-form'), url: $('url-input'), openBtn: $('open-btn'), closeBtn: $('close-btn'),
  stBrowser: $('st-browser'), stLoad: $('st-load'), stHttp: $('st-http'), stLogin: $('st-login'),
  stTitle: $('st-title'), stUrl: $('st-url'), stError: $('st-error'),
  mode: $('mode-select'), selector: $('selector-input'),
  optIdle: $('opt-idle'), optScroll: $('opt-scroll'), optHidden: $('opt-hidden'),
  captureBtn: $('capture-btn'), recaptureBtn: $('recapture-btn'),
  stats: $('stats'), warnings: $('warnings'),
  editor: $('editor'), charCount: $('char-count'), dirtyFlag: $('dirty-flag'),
  preview: $('preview'), diff: $('diff'), diffBadge: $('diff-badge'),
  filename: $('filename-input'), optImages: $('opt-images'), saveBtn: $('save-btn'), saveTarget: $('save-target'),
  messages: $('messages'),
  recaptureDialog: $('recapture-dialog'), saveDialog: $('save-dialog'),
  saveDialogTitle: $('save-dialog-title'), saveDialogName: $('save-dialog-name'),
  saveDialogPath: $('save-dialog-path'), saveDialogExists: $('save-dialog-exists'), saveDialogConfirm: $('save-dialog-confirm'),
};

let editorState = createEditorState();
let browserStatus = null;
let filenameTouched = false;
const busy = { open: false, close: false, capture: false, save: false };

// ---------- messages ----------

function showMessage(tone, title, { detail = '', hint = '', code = '', timeout } = {}) {
  const box = document.createElement('div');
  box.className = 'msg';
  box.dataset.tone = tone;
  const head = document.createElement('div');
  head.className = 'msg-head';
  const t = document.createElement('span');
  t.textContent = title;
  const close = document.createElement('button');
  close.className = 'msg-close';
  close.textContent = '×';
  close.setAttribute('aria-label', '关闭提示');
  close.addEventListener('click', () => box.remove());
  head.append(t, close);
  box.append(head);
  if (detail) {
    const d = document.createElement('div');
    d.textContent = detail;
    box.append(d);
  }
  if (hint || code) {
    const h = document.createElement('div');
    h.className = 'msg-hint';
    h.textContent = [hint, code ? `（错误代码：${code}）` : ''].filter(Boolean).join(' ');
    box.append(h);
  }
  el.messages.prepend(box);
  while (el.messages.children.length > 5) el.messages.lastChild.remove();
  const ms = timeout ?? (tone === 'err' ? 0 : tone === 'warn' ? 12000 : 6000);
  if (ms > 0) setTimeout(() => box.remove(), ms);
}

function showError(title, err) {
  if (err instanceof ApiError) {
    showMessage('err', title, { detail: err.message, hint: err.hint, code: err.code });
  } else {
    showMessage('err', title, { detail: err?.message || String(err), hint: '请查看浏览器控制台与服务终端日志。' });
    console.error(err);
  }
}

// ---------- busy / button state ----------

function setBusy(key, value, button, busyLabel) {
  busy[key] = value;
  if (button) {
    if (value) {
      button.dataset.label = button.textContent;
      button.textContent = busyLabel;
      button.classList.add('busy');
    } else if (button.dataset.label) {
      button.textContent = button.dataset.label;
      button.classList.remove('busy');
    }
  }
  refreshButtons();
}

function refreshButtons() {
  const s = browserStatus;
  const anyBrowserBusy = busy.open || busy.close || busy.capture || s?.launching || s?.navigating || s?.capturing;
  const hasPage = Boolean(s?.running && s?.currentUrl && /^https?:/i.test(s.currentUrl));
  el.openBtn.disabled = anyBrowserBusy;
  el.closeBtn.disabled = anyBrowserBusy || !s?.running;
  el.captureBtn.disabled = anyBrowserBusy || !hasPage;
  el.recaptureBtn.disabled = anyBrowserBusy || !hasPage || editorState.captureCount === 0;
  el.saveBtn.disabled = busy.save || el.editor.value.trim() === '';
  el.openBtn.textContent = busy.open ? el.openBtn.textContent : s?.running ? '在浏览器中打开' : '打开浏览器';
}

// ---------- health ----------

async function checkHealth() {
  try {
    const h = await api('/api/health');
    el.health.dataset.state = 'ok';
    el.healthText.textContent = `本地服务正常 · Node ${h.node}`;
    el.saveTarget.dataset.dir = h.requirementsDir;
    if (!el.filename.value) el.saveTarget.textContent = `保存目录：${h.requirementsDir}`;
  } catch (err) {
    el.health.dataset.state = 'error';
    el.healthText.textContent = err.message;
  }
}

// ---------- browser status ----------

const LOAD_LABEL = {
  idle: ['—', 'muted'],
  navigating: ['正在加载…', 'info'],
  domcontentloaded: ['DOM 已就绪，资源加载中', 'info'],
  loaded: ['页面已加载', 'ok'],
  error: ['加载失败', 'err'],
};

function setBadge(node, text, tone) {
  node.textContent = text;
  node.dataset.tone = tone;
}

function renderStatus(s) {
  const wasRunning = browserStatus?.running;
  const hadPages = (browserStatus?.pageCount ?? 0) > 0;
  browserStatus = s;
  if (s.launching) setBadge(el.stBrowser, '启动中…', 'info');
  else if (s.running && s.pageCount === 0) setBadge(el.stBrowser, '运行中 · 页面已全部关闭', 'warn');
  else if (s.running) setBadge(el.stBrowser, `已打开 · ${s.pageCount} 个标签页${s.headless ? '（无头）' : ''}`, 'ok');
  else setBadge(el.stBrowser, '未启动', 'muted');

  if (s.running && hadPages && s.pageCount === 0) {
    showMessage('warn', '浏览器中的页面已被关闭', { hint: '点击“在浏览器中打开”会重新打开窗口并访问输入框中的地址，登录状态仍然保留。' });
  }

  if (s.capturing) setBadge(el.stLoad, '正在采集…', 'info');
  else if (s.running) {
    let [label, tone] = LOAD_LABEL[s.navigationState] ?? LOAD_LABEL.idle;
    if (s.readyState === 'complete' && s.navigationState !== 'error') [label, tone] = ['页面已加载（readyState=complete）', 'ok'];
    setBadge(el.stLoad, label, tone);
  } else setBadge(el.stLoad, '—', 'muted');

  el.stHttp.textContent = s.lastHttpStatus ?? '—';
  el.stHttp.style.color = s.lastHttpStatus >= 400 ? 'var(--err)' : '';
  el.stTitle.textContent = s.title || '—';
  el.stTitle.title = s.title || '';
  el.stUrl.textContent = s.currentUrl || '—';
  el.stUrl.title = s.currentUrl || '';
  if (!s.running) el.stLogin.textContent = '—';
  else if (s.loginSuspected) el.stLogin.innerHTML = '<span class="badge" data-tone="warn">疑似登录页</span> 请在浏览器窗口中完成登录';
  else el.stLogin.textContent = '未检测到登录表单';

  el.stError.hidden = !s.lastError;
  el.stError.textContent = s.lastError ? `最近一次打开失败：${s.lastError}` : '';

  if (wasRunning && !s.running) {
    showMessage('warn', '浏览器已关闭', { hint: '如需继续采集，请重新点击“打开浏览器”。登录状态已保存在本地，通常无需重新登录。' });
  }
  refreshButtons();
}

let statusTimer = null;
async function pollStatus() {
  clearTimeout(statusTimer);
  try {
    renderStatus(await api('/api/browser/status'));
    if (el.health.dataset.state !== 'ok') await checkHealth();
  } catch (err) {
    el.health.dataset.state = 'error';
    el.healthText.textContent = err.message;
  }
  const fast = browserStatus?.running || browserStatus?.launching || busy.open;
  statusTimer = setTimeout(pollStatus, document.hidden ? 10000 : fast ? 2000 : 6000);
}

// ---------- open / close ----------

el.openForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (busy.open) return;
  const url = el.url.value.trim();
  if (!url) {
    showMessage('err', '请输入需求文档 URL', { hint: '示例：https://docs.example.com/requirement/123' });
    el.url.focus();
    return;
  }
  setBusy('open', true, el.openBtn, '正在打开…');
  setTimeout(pollStatus, 300);
  try {
    const status = await api('/api/browser/open', { method: 'POST', body: { url } });
    renderStatus(status);
    const tone = status.lastHttpStatus >= 400 ? 'warn' : 'ok';
    showMessage(tone, '页面已在浏览器中打开', {
      detail: status.title || status.currentUrl,
      hint: status.lastHttpStatus >= 400
        ? `服务器返回 HTTP ${status.lastHttpStatus}，可能需要登录或没有访问权限。请在浏览器窗口中处理后再采集。`
        : '如需登录请在 Chromium 窗口中完成；确认文档内容完整显示后，回到这里点击“开始采集”。',
    });
  } catch (err) {
    showError('打开页面失败', err);
  } finally {
    setBusy('open', false, el.openBtn);
    pollStatus();
  }
});

el.closeBtn.addEventListener('click', async () => {
  setBusy('close', true, el.closeBtn, '正在关闭…');
  try {
    browserStatus = { ...browserStatus, running: false };
    renderStatus(await api('/api/browser/close', { method: 'POST' }));
    showMessage('ok', '浏览器已关闭');
  } catch (err) {
    showError('关闭浏览器失败', err);
  } finally {
    setBusy('close', false, el.closeBtn);
  }
});

// ---------- capture ----------

el.mode.addEventListener('change', () => {
  el.selector.hidden = el.mode.value !== 'selector';
  if (!el.selector.hidden) el.selector.focus();
});

function captureOptions() {
  return {
    mode: el.mode.value,
    selector: el.mode.value === 'selector' ? el.selector.value.trim() : undefined,
    waitForNetworkIdle: el.optIdle.checked,
    autoScroll: el.optScroll.checked,
    includeHidden: el.optHidden.checked,
  };
}

function askRecapture() {
  return new Promise((resolve) => {
    const dialog = el.recaptureDialog;
    const onClick = (e) => {
      const action = e.target.closest('button')?.dataset.action;
      if (!action) return;
      dialog.removeEventListener('click', onClick);
      dialog.close();
      resolve(action);
    };
    dialog.addEventListener('click', onClick);
    dialog.addEventListener('cancel', () => { dialog.removeEventListener('click', onClick); resolve('cancel'); }, { once: true });
    dialog.showModal();
  });
}

async function runCapture(trigger) {
  if (busy.capture) return;
  const opts = captureOptions();
  if (opts.mode === 'selector' && !opts.selector) {
    showMessage('err', '请填写 CSS 选择器', { hint: '“自定义 CSS 选择器”模式下需要指定正文所在元素，例如 #content。' });
    el.selector.focus();
    return;
  }
  if (recaptureDecision(editorState, el.editor.value) === 'confirm') {
    const action = await askRecapture();
    if (action === 'cancel') return;
    if (action === 'save') {
      const saved = await saveFlow();
      if (!saved) {
        showMessage('warn', '已取消重新采集', { hint: '内容没有保存成功，为避免丢失修改，未执行重新采集。' });
        return;
      }
    }
  }

  const button = trigger === 'recapture' ? el.recaptureBtn : el.captureBtn;
  setBusy('capture', true, button, '采集中…');
  try {
    const result = await api('/api/capture', { method: 'POST', body: opts });
    const previous = el.editor.value;
    editorState = applyCapture(editorState, result.markdown, previous);
    el.editor.value = result.markdown;
    if (!filenameTouched || !el.filename.value.trim()) {
      el.filename.value = result.suggestedFileName;
      filenameTouched = false;
      updateSaveTarget();
    }
    renderStats(result);
    onEditorChange();
    renderDiff();
    if (editorState.previousText !== null && trigger === 'recapture') switchTab('diff');
    const tone = result.warnings.length ? 'warn' : 'ok';
    showMessage(tone, `采集完成：${result.title || '（无标题）'}`, {
      detail: `${result.stats.characters} 字符 · ${result.stats.headings} 个标题 · ${result.stats.tables} 个表格 · ${result.stats.images} 张图片`,
      hint: result.warnings.length ? `有 ${result.warnings.length} 条警告，请在采集区查看并核对内容完整性。` : '请检查预览内容后保存。',
    });
  } catch (err) {
    showError('采集失败', err);
  } finally {
    setBusy('capture', false, button);
    pollStatus();
  }
}

el.captureBtn.addEventListener('click', () => runCapture('capture'));
el.recaptureBtn.addEventListener('click', () => runCapture('recapture'));

const STRATEGY_LABEL = {
  candidate: '自动识别正文容器',
  selector: '自定义选择器',
  body: '整页提取',
  'body-fallback': '整页提取（回退）',
};

function renderStats(result) {
  const s = result.stats;
  const items = [
    ['策略', `${STRATEGY_LABEL[result.strategy.type] ?? result.strategy.type} · ${result.strategy.selector}`],
    ['字符数', s.characters], ['标题', s.headings], ['段落', s.paragraphs], ['列表', s.lists],
    ['表格', s.tables], ['图片', s.images], ['链接', s.links], ['代码块', s.codeBlocks], ['引用', s.blockquotes],
    ['正文占页面文字', `${Math.round(result.strategy.coverage * 100)}%`],
  ];
  el.stats.replaceChildren(...items.map(([k, v]) => {
    const span = document.createElement('span');
    span.className = 'stat';
    span.textContent = k;
    const b = document.createElement('b');
    b.textContent = String(v);
    span.append(b);
    return span;
  }));
  el.stats.hidden = false;
  el.warnings.replaceChildren(...result.warnings.map((w) => {
    const li = document.createElement('li');
    const code = document.createElement('code');
    code.textContent = w.code;
    li.append(code, document.createTextNode(w.message));
    return li;
  }));
  el.warnings.hidden = result.warnings.length === 0;
}

// ---------- editor / preview / diff ----------

let renderTimer = null;
function onEditorChange() {
  const text = el.editor.value;
  el.charCount.textContent = `${text.length} 字符`;
  el.dirtyFlag.hidden = !isDirty(editorState, text);
  refreshButtons();
  clearTimeout(renderTimer);
  renderTimer = setTimeout(() => renderPreview(), 150);
}

function renderPreview() {
  try {
    renderMarkdownInto(el.preview, el.editor.value);
  } catch (err) {
    el.preview.textContent = `预览渲染失败：${err.message}`;
  }
}

function renderDiff() {
  const prev = editorState.previousText;
  if (prev === null) {
    el.diffBadge.hidden = true;
    return;
  }
  const ops = diffLines(prev, editorState.baseline ?? '');
  const sum = summarizeDiff(ops);
  el.diffBadge.hidden = false;
  el.diffBadge.textContent = sum.changed ? `+${sum.added} −${sum.removed}` : '无变化';
  el.diffBadge.dataset.tone = sum.changed ? 'warn' : 'ok';

  const nodes = [];
  const summary = document.createElement('div');
  summary.className = 'summary';
  summary.textContent = sum.changed
    ? `重新采集前的编辑区内容 → 新采集结果：新增 ${sum.added} 行，删除 ${sum.removed} 行。`
    : '新采集结果与之前的内容完全一致。';
  nodes.push(summary);
  // Collapse long unchanged runs so changes stay visible.
  for (let i = 0; i < ops.length; i++) {
    const op = ops[i];
    if (op.type === 'same') {
      let j = i;
      while (j < ops.length && ops[j].type === 'same') j++;
      const run = j - i;
      if (run > 6) {
        for (let k = i; k < i + 2; k++) nodes.push(lineNode(ops[k]));
        const skip = document.createElement('div');
        skip.className = 'line skip';
        skip.textContent = `… ${run - 4} 行未变化 …`;
        nodes.push(skip);
        for (let k = j - 2; k < j; k++) nodes.push(lineNode(ops[k]));
      } else {
        for (let k = i; k < j; k++) nodes.push(lineNode(ops[k]));
      }
      i = j - 1;
    } else {
      nodes.push(lineNode(op));
    }
  }
  el.diff.replaceChildren(...nodes);
}

function lineNode(op) {
  const div = document.createElement('div');
  div.className = `line ${op.type === 'same' ? '' : op.type}`;
  div.textContent = op.text || ' ';
  return div;
}

function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t) => {
    const active = t.dataset.tab === name;
    t.classList.toggle('active', active);
    t.setAttribute('aria-selected', String(active));
  });
  el.preview.hidden = name !== 'preview';
  el.diff.hidden = name !== 'diff';
}

document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
el.editor.addEventListener('input', onEditorChange);

// ---------- save ----------

let targetTimer = null;
async function updateSaveTarget() {
  clearTimeout(targetTimer);
  const name = el.filename.value.trim();
  if (!name) {
    el.saveTarget.textContent = `保存目录：${el.saveTarget.dataset.dir ?? '—'}`;
    el.saveTarget.style.color = '';
    return;
  }
  targetTimer = setTimeout(async () => {
    try {
      const info = await api('/api/save/check', { method: 'POST', body: { fileName: name } });
      el.saveTarget.textContent = `将保存到：${info.absolutePath}${info.exists ? '（文件已存在，保存时需确认覆盖）' : ''}`;
      el.saveTarget.style.color = info.exists ? 'var(--warn)' : '';
    } catch (err) {
      el.saveTarget.textContent = `文件名无效：${err.message}${err.hint ? ` ${err.hint}` : ''}`;
      el.saveTarget.style.color = 'var(--err)';
    }
  }, 250);
}

el.filename.addEventListener('input', () => { filenameTouched = true; updateSaveTarget(); });

function confirmSave(info) {
  return new Promise((resolve) => {
    const d = el.saveDialog;
    el.saveDialogTitle.textContent = info.exists ? '文件已存在，确认覆盖？' : '确认保存';
    el.saveDialogName.textContent = info.fileName;
    el.saveDialogPath.textContent = info.absolutePath;
    el.saveDialogExists.hidden = !info.exists;
    el.saveDialogConfirm.textContent = info.exists ? '覆盖保存' : '保存';
    el.saveDialogConfirm.className = info.exists ? 'danger' : 'primary';
    const onClick = (e) => {
      const action = e.target.closest('button')?.dataset.action;
      if (!action) return;
      d.removeEventListener('click', onClick);
      d.close();
      resolve(action === 'confirm');
    };
    d.addEventListener('click', onClick);
    d.addEventListener('cancel', () => { d.removeEventListener('click', onClick); resolve(false); }, { once: true });
    d.showModal();
  });
}

/** Returns true when the content was saved. */
async function saveFlow() {
  if (busy.save) return false;
  const markdown = el.editor.value;
  if (!markdown.trim()) {
    showMessage('err', '没有可保存的内容', { hint: '请先采集页面或在编辑区输入内容。' });
    return false;
  }
  const fileName = el.filename.value.trim();
  if (!fileName) {
    showMessage('err', '请输入文件名', { hint: '文件会自动添加 .md 后缀并保存到需求文档目录。' });
    el.filename.focus();
    return false;
  }
  setBusy('save', true, el.saveBtn, '保存中…');
  try {
    let info = await api('/api/save/check', { method: 'POST', body: { fileName } });
    if (!(await confirmSave(info))) {
      showMessage('info', '已取消保存');
      return false;
    }
    let result;
    try {
      result = await api('/api/save', {
        method: 'POST',
        body: { fileName, markdown, overwrite: info.exists, downloadImages: el.optImages.checked },
      });
    } catch (err) {
      if (!(err instanceof ApiError) || err.code !== 'FILE_EXISTS') throw err;
      // The file appeared between the check and the write: ask again explicitly.
      info = { ...info, exists: true };
      if (!(await confirmSave(info))) {
        showMessage('info', '已取消保存，原文件未被修改');
        return false;
      }
      result = await api('/api/save', {
        method: 'POST',
        body: { fileName, markdown, overwrite: true, downloadImages: el.optImages.checked },
      });
    }
    editorState = markSaved(editorState, markdown, result.absolutePath);
    onEditorChange();
    updateSaveTarget();
    let hint = `${result.bytes} 字节，UTF-8 编码。`;
    if (result.assets) {
      hint += ` 已下载 ${result.assets.downloaded} 张图片到 assets。`;
      if (result.assets.failed.length) {
        hint += ` ${result.assets.failed.length} 张下载失败，已保留原始 URL：${result.assets.failed.map((f) => `${f.url}（${f.reason}）`).join('；')}`;
      }
    }
    showMessage(result.warnings.length ? 'warn' : 'ok', result.overwritten ? '已覆盖保存' : '保存成功', {
      detail: result.absolutePath,
      hint,
      timeout: result.warnings.length ? 0 : 10000,
    });
    return true;
  } catch (err) {
    showError('保存失败', err);
    return false;
  } finally {
    setBusy('save', false, el.saveBtn);
  }
}

el.saveBtn.addEventListener('click', () => { saveFlow(); });

window.addEventListener('beforeunload', (e) => {
  if (isDirty(editorState, el.editor.value)) {
    e.preventDefault();
    e.returnValue = '';
  }
});
document.addEventListener('visibilitychange', () => { if (!document.hidden) pollStatus(); });

// ---------- init ----------

renderPreview();
refreshButtons();
checkHealth();
pollStatus();
