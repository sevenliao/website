# 本地需求文档采集工具（Local Requirements Capture）

在本机运行的 Web 工具：用 Playwright 启动**真实的 Chromium 浏览器**打开在线需求文档。你可以在浏览器里手动登录，确认内容加载完成后一键采集，把页面转换成结构化 Markdown，预览、编辑后保存到项目的 `docs/requirements/` 目录，供 Cursor、Codex、Claude Code 等 AI 编码工具读取。

- 不调用任何大模型 API，不依赖云端服务，全部在本机完成。
- 不总结、不改写原文：转换只做 HTML 到 Markdown 的结构映射。
- **不保证支持所有在线文档平台。** 能否完整读取取决于目标网站的登录权限、页面结构和内容加载机制（例如 Canvas 渲染、虚拟滚动、跨域 iframe）。遇到疑似不完整的情况，工具会给出可见警告，而不是静默丢弃内容。

---

## 环境要求

| 项目 | 要求 |
| --- | --- |
| Node.js | ≥ 20.12，已在 **22.17** 上验证 |
| npm | 10.x |
| 操作系统 | macOS / Windows / Linux 桌面环境（需要能弹出浏览器窗口） |
| 磁盘 | Chromium 约 300 MB |

## 安装

```bash
npm install
# 首次使用需要下载 Playwright 自带的 Chromium（只需一次）
npx playwright install chromium     # 等同于 npm run browser:install
```

> 如果 Playwright 升级后提示 `Executable doesn't exist`，重新执行 `npx playwright install chromium` 即可。工具界面也会给出这个提示（错误代码 `BROWSER_NOT_INSTALLED`）。

可选：复制 `.env.example` 为 `.env`，修改端口、保存目录等配置。

## 启动

```bash
npm start            # 使用 tsx 直接运行 TypeScript 源码
# 或
npm run build && npm run start:prod   # 编译到 dist/ 后用 node 运行
```

启动后访问：**http://127.0.0.1:3789**

服务只监听 `127.0.0.1`。按 `Ctrl+C` 停止服务时，会一并关闭工具打开的 Chromium。

## 使用流程

1. **打开目标文档**：在第 1 步输入框粘贴文档 URL（必须是 `http://` 或 `https://`），点击“打开浏览器”。工具会弹出一个独立的 Chromium 窗口并访问该地址。浏览器已经打开时，按钮会变成“在浏览器中打开”，在当前标签页跳转到新地址。
2. **手动登录**：如果目标网站需要登录、扫码或验证码，直接在弹出的 Chromium 窗口中按正常流程完成。第 2 步“浏览器状态”会显示当前地址、标题、HTTP 状态码和加载状态；检测到密码输入框或登录类 URL 时会标记“疑似登录页”。本工具**不会**尝试绕过任何登录、验证码或权限控制。
3. **确认内容已加载**：在 Chromium 窗口中打开真正要采集的文档，等待正文完整显示。如果在浏览器里跳转了页面或打开了新标签页，采集会针对**当前活动页面**进行。
4. **采集**：回到工具页面，点击“开始采集”。可选项：
   - **提取范围**：
     - 自动识别正文（默认）：依次尝试 `article`、`main`、`[role=main]`，以及常见的富文本或文档容器（`.markdown-body`、`.ProseMirror`、`.ql-editor`、`.ck-content`、`#main-content`、`.wiki-content` 等）。
     - 整页提取：去除导航、页脚、侧边栏后提取整页。
     - 自定义 CSS 选择器：精确指定正文所在元素（可在浏览器开发者工具中查找）。
   - **等待网络空闲**：采集前最多等待 10 秒，直到页面没有网络请求。
   - **自动滚动**：滚动页面以触发懒加载内容。
   - **包含隐藏元素**：默认只采集页面上可见的内容。
5. **检查**：采集区会显示字符数、标题数、表格数、图片数等统计，以及所有警告（正文过短、疑似登录页、iframe 或 Canvas 内容、复杂表格等）。请对照原页面核对完整性。
6. **预览与编辑**：左侧是可编辑的 Markdown 源码，右侧是安全渲染的预览。重新采集后，“与上次内容对比”标签会显示逐行差异。
7. **重新采集**：如果编辑区有未保存的修改，会弹窗让你选择“先保存，再重新采集”、“放弃修改并重新采集”或“取消”，不会直接覆盖你的修改。
8. **保存**：填写文件名（自动补 `.md`），工具会实时显示完整保存路径；点击“保存 Markdown”后，确认对话框会再次显示文件名和路径。目标文件已存在时，必须明确点击“覆盖保存”才会覆盖。

## 文件保存位置

```
docs/
  requirements/
    <文件名>.md
    assets/
      <文件名>/<图片哈希>.png    # 仅在勾选“下载图片”时生成
```

保存的文件为 UTF-8 编码，开头是来自真实采集结果的元数据（拿不到的字段会直接省略，不会编造）：

```markdown
---
title: "实际文档标题"
source_url: "实际来源 URL"
captured_at: "2026-10-25T09:43:28.756Z"
---

# 实际文档标题

正文……
```

- 文件名只能是单纯的文件名。包含 `/`、`\`、`..`、绝对路径、控制字符或系统保留名时会被拒绝。
- 所有写入都限制在需求文档目录内，并拒绝写入符号链接。接口不接受客户端传入的目录参数。
- 可以通过 `.env` 中的 `REQUIREMENTS_DIR` 修改保存目录（只能由本机配置修改，无法通过请求修改）。

### 图片（实验性）

默认只保留图片的原始 URL。勾选“下载图片到 assets”后，工具会通过**当前浏览器会话**下载图片（因此可以下载需要同一登录状态的图片），保存到 `assets/<文件名>/`，把 Markdown 中的链接改写为相对路径，并在后面附加 `<!-- original-src: 原始URL -->`。下载失败（例如返回登录页、403、网络错误）的图片会保留原始 URL，并在保存结果中逐条列出失败原因，不会把失败伪装成成功。

## 命令一览

| 命令 | 作用 |
| --- | --- |
| `npm start` | 启动本地服务（tsx 运行源码） |
| `npm run dev` | 监听源码变化自动重启 |
| `npm run build` / `npm run start:prod` | 编译到 `dist/` 并用 node 运行 |
| `npm run typecheck` | TypeScript 类型检查 |
| `npm test` | 单元测试与 API 测试（不启动浏览器） |
| `npm run test:e2e` | 使用真实 Chromium（无头模式）的端到端测试 |
| `npm run test:all` | 全部测试 |
| `npm run demo:fixtures` | 在 `http://127.0.0.1:4500` 启动本地测试文档，用于体验完整流程 |
| `npm run browser:install` | 安装 Playwright Chromium |

### 用本地测试页面体验

```bash
npm run demo:fixtures   # 终端 1
npm start               # 终端 2
```

然后在工具里依次打开：

- `http://127.0.0.1:4500/doc.html`：示例需求文档，包含标题、嵌套列表、表格、复杂表格、图片、代码块、隐藏内容和 JS 动态渲染内容。
- `http://127.0.0.1:4500/protected`：需要登录的文档。先返回 401 登录页，在 Chromium 中点击“登录”后进入文档，用来体验登录状态的持久化。
- `http://127.0.0.1:4500/frame-host`：正文位于 iframe 中的页面。

## 接口

所有接口都返回统一格式：

```jsonc
// 成功
{ "ok": true, "data": { ... } }
// 失败
{ "ok": false, "error": { "code": "FILE_EXISTS", "message": "文件已存在：…", "hint": "请确认是否覆盖…", "details": { } } }
```

| 方法与路径 | 说明 |
| --- | --- |
| `GET /api/health` | 服务健康检查 |
| `POST /api/browser/open` `{ url }` | 启动或复用浏览器，并打开 URL |
| `GET /api/browser/status` | 浏览器状态、当前 URL、标题、加载状态、HTTP 状态码、登录提示 |
| `POST /api/browser/close` | 关闭浏览器 |
| `POST /api/capture` `{ mode, selector?, waitForNetworkIdle?, autoScroll?, includeHidden? }` | 采集当前页面并返回 Markdown、统计和警告 |
| `POST /api/save/check` `{ fileName }` | 预览目标路径，以及文件是否已存在 |
| `POST /api/save` `{ fileName, markdown, overwrite?, downloadImages? }` | 保存；仅当 `overwrite === true` 时覆盖已有文件 |

POST 请求必须是 `application/json`，并带有请求头 `X-LRC-Client: web`（工具页面会自动添加）。

## 常见问题

| 现象 | 原因与解决 |
| --- | --- |
| 提示 `BROWSER_NOT_INSTALLED` | 执行 `npx playwright install chromium`。 |
| 提示 `PROFILE_LOCKED` | 已有另一个使用同一数据目录的 Chromium 在运行（比如另一个工具实例）。关闭它后重试。 |
| 端口被占用 | 在 `.env` 中设置其他 `PORT`。 |
| `NAVIGATION_TIMEOUT` | 页面在超时时间内没有加载完。浏览器窗口仍保持打开，如果页面已经显示，可以直接采集；也可以调大 `NAVIGATION_TIMEOUT_MS`。 |
| `DNS_ERROR` / `NETWORK_ERROR` / `TLS_ERROR` | 检查网址、网络、VPN 或内网证书。工具不会忽略证书错误。注意：部分代理或 VPN 会把所有域名都“解析成功”再断开连接，此时会显示为网络错误而不是 DNS 错误。 |
| `EMPTY_CONTENT`（正文为空） | 页面没加载完、还停留在登录页、没有访问权限，或正文由 Canvas 绘制。在浏览器中确认文档已显示后重试，或改用“整页提取”或自定义选择器。 |
| 警告 `CONTENT_PARTIAL` / `CONTAINER_NOT_FOUND` | 自动识别的正文容器可能不准确。改用“整页提取”或自定义选择器，并对照原页面检查。 |
| 警告 `CANVAS_PRESENT` | 部分在线文档用 Canvas 渲染正文，无法从 DOM 读取。可以尝试平台自带的“导出”功能。 |
| 警告 `IFRAME_CONTENT_USED` / `IFRAME_PRESENT` | 正文在 iframe 中。工具会在主页面文字很少时自动改用文字最多的 iframe，否则只保留 iframe 链接。 |
| 长文档只采到一部分 | 部分平台使用虚拟滚动，只渲染可视区域的内容。勾选“自动滚动”可能有所改善，但无法保证完整。 |
| Chromium 窗口被关掉了 | 状态栏会显示“页面已全部关闭”或“未启动”。重新点击打开按钮即可，登录状态仍然保留。 |

## 安全说明

- **登录状态保存在 `data/browser-profile/`**（Chromium 用户数据目录，含 Cookie 与本地存储）。该目录已在 `.gitignore` 中排除，**请勿提交、上传或分享**。想清除登录状态，关闭工具后删除该目录即可。
- 服务只监听回环地址；`HOST` 配置为非回环地址时服务拒绝启动。
- 拒绝 `Host` 不是 `127.0.0.1` / `localhost` 的请求（防 DNS 重绑定），拒绝来自外部 `Origin` 的请求。写操作必须带自定义请求头并使用 JSON，因此其他网站（包括被采集的网站）无法通过跨站请求触发本地写文件。
- 目标网站的 HTML 不会被当作可信内容渲染：预览经 marked 渲染后，再经 DOMPurify 白名单过滤；页面使用严格的 CSP（`script-src 'self'`），外链统一使用 `noopener noreferrer`。
- 日志只记录接口路径、错误码和去掉查询参数的 URL，不记录请求体、Cookie、密码或令牌。
- 只有在你点击按钮后才会访问目标 URL；工具不提供任何命令执行接口。

## 项目结构

```
src/
  server.ts                 # 启动入口：读取配置、监听 127.0.0.1、优雅退出
  app.ts                    # 组装 Express 应用（中间件、路由、静态资源）
  config.ts                 # 环境变量与路径配置
  routes/                   # 薄路由层：参数解析 → 调用服务 → 统一响应
    browser.ts  capture.ts  save.ts  health.ts
  services/
    browser-manager.ts      # Playwright 持久化上下文单例、页面跟踪、错误映射
    page-snapshot-script.ts # 在页面内执行的快照脚本（去除隐藏元素、补全绝对 URL、懒加载图片）
    content-extractor.ts    # cheerio 正文识别、降噪、回退策略、统计与警告
    markdown-converter.ts   # Turndown 规则（表格、代码块、任务列表、媒体）与 front matter
    capture-service.ts      # 采集编排：选择主页面或 iframe、合并警告
    file-service.ts         # 路径受限、防覆盖、原子写入
    asset-service.ts        # 图片下载与链接改写（实验性）
  utils/                    # URL / 文件名校验、错误类型、HTTP 中间件
  types/index.ts
public/                     # 原生 HTML/CSS/JS 前端
  lib/                      # 可单独测试的纯函数：diff、未保存状态、front matter
tests/                      # vitest 单元测试、API 测试与 e2e 测试（本地 HTML，不依赖第三方网站）
scripts/serve-fixtures.ts   # 本地测试文档服务
docs/requirements/          # Markdown 输出目录
data/                       # 浏览器用户数据（已 gitignore）
```

## 已知限制与后续扩展

- 不同文档平台的 DOM 结构差异很大，自动识别正文是启发式的。对固定使用的平台，建议记下一个自定义选择器。
- Canvas 渲染、虚拟滚动、跨域 iframe 的内容可能无法完整获取，工具只能给出警告。
- 合并单元格的表格以精简 HTML `<table>` 形式保留（Markdown 表格无法表达合并单元格）。
- 图片下载是实验功能：目前只处理 Markdown 图片语法 `![](...)`，不处理复杂表格 HTML 里的 `<img>`；也不下载附件。
- 后续可扩展：按站点保存选择器预设、附件下载、批量采集多个 URL、按标题拆分多个文件等。
