import fs from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../src/app.js';
import { PROJECT_ROOT } from '../../src/config.js';
import { BrowserManager } from '../../src/services/browser-manager.js';
import { CaptureService } from '../../src/services/capture-service.js';
import { silentLogger } from '../helpers.js';
import { startFixtureServer } from './fixture-server.js';

const H = { 'x-lrc-client': 'web' };
const CAPTURE_DEFAULTS = { mode: 'auto' as const, includeHidden: false, waitForNetworkIdle: true, autoScroll: false };

let tmp: string;
let fixtures: Awaited<ReturnType<typeof startFixtureServer>>;

beforeAll(async () => {
  tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'lrc-e2e-'));
  fixtures = await startFixtureServer();
});

afterAll(async () => {
  await fixtures?.close();
  await fs.rm(tmp, { recursive: true, force: true });
});

async function closedPort(): Promise<number> {
  const server = net.createServer();
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address() as net.AddressInfo;
  await new Promise((resolve) => server.close(resolve));
  return port;
}

function manager(profile: string, navigationTimeoutMs = 15_000) {
  return new BrowserManager({ profileDir: path.join(tmp, profile), headless: true, navigationTimeoutMs, logger: silentLogger });
}

describe('real Chromium capture', () => {
  it('runs the full open → capture → save flow through the HTTP API', async () => {
    const browser = manager('profile-api');
    const requirementsDir = path.join(tmp, 'requirements');
    const app = createApp({ config: { projectRoot: PROJECT_ROOT, requirementsDir }, browser, logger: silentLogger });
    try {
      const open = await request(app).post('/api/browser/open').set(H).send({ url: `${fixtures.baseUrl}/doc.html` });
      expect(open.status).toBe(200);
      expect(open.body.data).toMatchObject({ running: true, lastHttpStatus: 200, loginSuspected: false });
      expect(open.body.data.title).toBe('订单退款需求 - 示例文档中心');

      const cap = await request(app).post('/api/capture').set(H).send({});
      expect(cap.status).toBe(200);
      const md: string = cap.body.data.markdown;
      expect(md).toContain(`source_url: "${fixtures.baseUrl}/doc.html"`);
      expect(md).toContain('# 订单退款需求');
      expect(md).toContain('- 申请退款\n  - 选择退款原因');
      expect(md).toContain('| PENDING | 待审核 \\| 等待客服 | 撤销 |');
      expect(md).toContain(`![退款流程图](${fixtures.baseUrl}/images/refund-flow.png)`);
      expect(md).toContain('![懒加载图片](https://cdn.example.com/lazy.png)');
      expect(md).toContain('由 JavaScript 动态渲染的段落。');
      expect(md).not.toContain('这是隐藏内容');
      expect(md).not.toContain('should-not-appear');
      expect(md).not.toContain('版权所有');
      expect(md).toContain('- [x] 已完成的任务');

      const save = await request(app).post('/api/save').set(H).send({ fileName: cap.body.data.suggestedFileName, markdown: md });
      expect(save.status).toBe(200);
      expect(await fs.readFile(path.join(requirementsDir, '订单退款需求.md'), 'utf8')).toBe(md);

      const again = await request(app).post('/api/save').set(H).send({ fileName: '订单退款需求', markdown: 'changed' });
      expect(again.status).toBe(409);
      expect(again.body.error.code).toBe('FILE_EXISTS');

      const closed = await request(app).post('/api/browser/close').set(H).send({});
      expect(closed.body.data.running).toBe(false);
      const afterClose = await request(app).post('/api/capture').set(H).send({});
      expect(afterClose.status).toBe(409);
      expect(afterClose.body.error.code).toBe('BROWSER_NOT_OPEN');
    } finally {
      await browser.close();
    }
  });

  it('detects a login page and keeps the login session in the persistent profile', async () => {
    const first = manager('profile-login');
    try {
      const status = await first.open(new URL(`${fixtures.baseUrl}/protected`));
      expect(status.lastHttpStatus).toBe(401);
      expect(status.loginSuspected).toBe(true);
      const capture = new CaptureService(first);
      await expect(capture.capture(CAPTURE_DEFAULTS)).rejects.toMatchObject({ code: 'EMPTY_CONTENT' });

      // Simulates the user completing the login form in the real browser window.
      const loggedIn = await first.open(new URL(`${fixtures.baseUrl}/login?user=u`));
      expect(loggedIn.currentUrl).toBe(`${fixtures.baseUrl}/protected`);
      expect(loggedIn.lastHttpStatus).toBe(200);
    } finally {
      await first.close();
    }

    const second = manager('profile-login');
    try {
      const status = await second.open(new URL(`${fixtures.baseUrl}/protected`));
      expect(status.lastHttpStatus).toBe(200);
      const result = await new CaptureService(second).capture(CAPTURE_DEFAULTS);
      expect(result.title).toBe('订单退款需求');

      // Images behind the same login are downloadable through the browser session.
      const img = await second.fetchResource(`${fixtures.baseUrl}/images/refund-flow.png`);
      expect(img.contentType).toBe('image/png');
    } finally {
      await second.close();
    }
  });

  it('captures the page the browser is currently on after navigation', async () => {
    const browser = manager('profile-nav');
    try {
      await browser.open(new URL(`${fixtures.baseUrl}/missing`));
      const s = await browser.status();
      expect(s.lastHttpStatus).toBe(404);
      await browser.open(new URL(`${fixtures.baseUrl}/doc.html`));
      const result = await new CaptureService(browser).capture(CAPTURE_DEFAULTS);
      expect(result.sourceUrl).toBe(`${fixtures.baseUrl}/doc.html`);
    } finally {
      await browser.close();
    }
  });

  it('uses iframe content when the main page is only a shell', async () => {
    const browser = manager('profile-frame');
    try {
      await browser.open(new URL(`${fixtures.baseUrl}/frame-host`));
      const result = await new CaptureService(browser).capture(CAPTURE_DEFAULTS);
      expect(result.warnings.map((w) => w.code)).toContain('IFRAME_CONTENT_USED');
      expect(result.markdown).toContain('## 一、背景');
    } finally {
      await browser.close();
    }
  });

  it('rejects a second open while the first is still running', async () => {
    const browser = manager('profile-busy');
    try {
      const a = browser.open(new URL(`${fixtures.baseUrl}/doc.html`));
      await expect(browser.open(new URL(`${fixtures.baseUrl}/doc.html`))).rejects.toMatchObject({ code: 'BROWSER_BUSY' });
      await a;
    } finally {
      await browser.close();
    }
  });

  it('maps navigation failures to clear errors', async () => {
    const browser = manager('profile-errors', 2000);
    try {
      await expect(browser.open(new URL(`${fixtures.baseUrl}/slow`))).rejects.toMatchObject({ code: 'NAVIGATION_TIMEOUT', status: 504 });
      await expect(browser.open(new URL(`http://127.0.0.1:${await closedPort()}/`))).rejects.toMatchObject({ code: 'NETWORK_ERROR' });
      await expect(browser.open(new URL('http://127.0.0.1:1/'))).rejects.toMatchObject({ code: 'UNSAFE_PORT' });
      const s = await browser.status();
      expect(s.running).toBe(true);
      expect(s.navigationState).toBe('error');
      expect(s.lastError).toBeTruthy();
    } finally {
      await browser.close();
    }
  });

  it('reports unresolvable hosts', async () => {
    const browser = manager('profile-dns', 20_000);
    try {
      // Networks with fake-IP DNS (VPN/TUN proxies) resolve every name and then drop the
      // connection, so Chromium reports a connection error instead of a DNS error.
      const err = await browser.open(new URL('https://lrc-test.invalid/')).catch((e) => e);
      expect(['DNS_ERROR', 'NETWORK_ERROR']).toContain(err.code);
      expect(err.hint).toBeTruthy();
    } finally {
      await browser.close();
    }
  }, 30_000);
});
