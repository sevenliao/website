import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { readFixture } from '../helpers.js';

const PNG_1X1 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  'base64',
);

const LOGIN_PAGE = `<!DOCTYPE html><html><head><title>登录</title></head><body>
<form action="/login" method="get"><input name="user"><input type="password" name="pwd"><button>登录</button></form>
</body></html>`;

/** Local HTTP server with deterministic pages for end-to-end tests. */
export async function startFixtureServer(listenPort = 0): Promise<{ baseUrl: string; close: () => Promise<void> }> {
  const sample = readFixture('sample-doc.html');
  const hanging = new Set<http.ServerResponse>();

  const server = http.createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    const cookies = req.headers.cookie ?? '';
    const html = (status: number, body: string, headers: Record<string, string> = {}) => {
      res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', ...headers });
      res.end(body);
    };

    switch (url.pathname) {
      case '/doc.html':
        return html(200, sample);
      case '/protected':
        return cookies.includes('session=ok') ? html(200, sample) : html(401, LOGIN_PAGE);
      case '/login':
        res.writeHead(302, { 'set-cookie': 'session=ok; Max-Age=3600; Path=/; HttpOnly', location: '/protected' });
        return res.end();
      case '/frame-host':
        return html(200, '<!DOCTYPE html><html><head><title>外壳</title></head><body><header>导航</header><iframe src="/doc.html" width="800" height="600"></iframe></body></html>');
      case '/images/refund-flow.png':
        if (!cookies.includes('session=ok')) return html(403, LOGIN_PAGE);
        res.writeHead(200, { 'content-type': 'image/png' });
        return res.end(PNG_1X1);
      case '/slow':
        hanging.add(res);
        return;
      default:
        return html(404, '<html><body><h1>Not Found</h1></body></html>');
    }
  });

  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(listenPort, '127.0.0.1', resolve);
  });
  const { port } = server.address() as AddressInfo;
  return {
    baseUrl: `http://127.0.0.1:${port}`,
    close: () =>
      new Promise<void>((resolve) => {
        for (const res of hanging) res.destroy();
        server.closeAllConnections();
        server.close(() => resolve());
      }),
  };
}
