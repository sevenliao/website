import { describe, expect, it } from 'vitest';
import { extractContent, statsFromHtml } from '../src/services/content-extractor.js';
import { htmlToMarkdown } from '../src/services/markdown-converter.js';
import { AppError } from '../src/utils/errors.js';
import { readFixture } from './helpers.js';

const URL_ = 'https://docs.example.com/req/1';

describe('extractContent', () => {
  const html = readFixture('sample-doc.html');

  it('prefers the article container and strips navigation, sidebar and footer', () => {
    const r = extractContent({ html, url: URL_, pageTitle: '订单退款需求 - 示例文档中心' });
    expect(r.strategy.type).toBe('candidate');
    expect(r.strategy.selector).toBe('article');
    expect(r.title).toBe('订单退款需求');
    expect(r.contentHtml).not.toContain('文档中心首页');
    expect(r.contentHtml).not.toContain('其他文档一');
    expect(r.contentHtml).not.toContain('版权所有');
    expect(r.contentHtml).not.toContain('should-not-appear');
    expect(r.contentHtml).not.toContain('<button');
  });

  it('resolves relative links and lazy-loaded images to absolute URLs', () => {
    const r = extractContent({ html, url: URL_ });
    expect(r.contentHtml).toContain('href="https://docs.example.com/specs/payment"');
    expect(r.contentHtml).toContain('src="https://docs.example.com/images/refund-flow.png"');
    expect(r.contentHtml).toContain('src="https://cdn.example.com/lazy.png"');
  });

  it('produces markdown that keeps headings, lists, tables, links and images', () => {
    const r = extractContent({ html, url: URL_ });
    const { markdown } = htmlToMarkdown(r.contentHtml);
    expect(markdown).toContain('# 订单退款需求');
    expect(markdown).toContain('## 一、背景');
    expect(markdown).toContain('### 2.1 状态说明');
    expect(markdown).toContain('- 申请退款\n  - 选择退款原因');
    expect(markdown).toContain('| 状态 | 说明 | 可操作 |');
    expect(markdown).toContain('[支付规范](https://docs.example.com/specs/payment)');
    expect(markdown).toContain('![退款流程图](https://docs.example.com/images/refund-flow.png)');
    expect(markdown).toContain('```json');
    expect(markdown).toContain('> 注意：退款金额不能超过实付金额。');

    const stats = statsFromHtml(r.contentHtml, markdown);
    expect(stats.headings).toBe(6);
    expect(stats.tables).toBe(2);
    expect(stats.images).toBe(2);
    expect(stats.codeBlocks).toBe(1);
    expect(stats.characters).toBe(markdown.length);
  });

  it('removes elements marked hidden by the in-page snapshot script', () => {
    const r = extractContent({ html: '<body><main><p>可见内容</p><p data-lrc-hidden="1">隐藏</p></main></body>', url: URL_ });
    expect(r.contentHtml).toContain('可见内容');
    expect(r.contentHtml).not.toContain('隐藏');
  });

  it('falls back to the whole page with a warning when no container is found', () => {
    const page = `<body><nav>导航</nav><div><h1>标题</h1><p>${'正文内容'.repeat(80)}</p></div><footer>页脚</footer></body>`;
    const r = extractContent({ html: page, url: URL_ });
    expect(r.strategy.type).toBe('body-fallback');
    expect(r.warnings.map((w) => w.code)).toContain('CONTAINER_NOT_FOUND');
    expect(r.contentHtml).toContain('正文内容');
    expect(r.contentHtml).not.toContain('导航');
    expect(r.contentHtml).not.toContain('页脚');
  });

  it('does not silently drop most of the page when the container is tiny', () => {
    const page = `<body><main><p>${'短'.repeat(60)}</p></main><div class="doc"><p>${'大量真实正文'.repeat(100)}</p></div></body>`;
    const r = extractContent({ html: page, url: URL_ });
    expect(r.strategy.type).toBe('body-fallback');
    expect(r.contentHtml).toContain('大量真实正文');
    expect(r.warnings.map((w) => w.code)).toContain('CONTENT_PARTIAL');
  });

  it('warns when <main> holds content outside the chosen <article>', () => {
    const page = `<body><main><article><h1>标题</h1><p>${'文章正文'.repeat(60)}</p></article><section><p>${'文章之外的补充说明'.repeat(10)}</p></section></main></body>`;
    const r = extractContent({ html: page, url: URL_ });
    expect(r.strategy.selector).toBe('article');
    expect(r.warnings.some((w) => w.code === 'CONTENT_PARTIAL' && w.message.includes('main'))).toBe(true);
  });

  it('supports a custom selector and reports a missing selector', () => {
    const r = extractContent({ html, url: URL_ }, { mode: 'selector', selector: 'blockquote' });
    expect(r.contentHtml).toContain('退款金额不能超过实付金额');
    expect(r.contentHtml).not.toContain('一、背景');
    expect(() => extractContent({ html, url: URL_ }, { mode: 'selector', selector: '#nope' })).toThrowError(
      expect.objectContaining({ code: 'SELECTOR_NOT_FOUND' }),
    );
  });

  it('throws EMPTY_CONTENT for pages without content', () => {
    try {
      extractContent({ html: '<body><nav>菜单</nav><script>x()</script></body>', url: URL_ });
      expect.unreachable();
    } catch (err) {
      expect(err).toBeInstanceOf(AppError);
      expect((err as AppError).code).toBe('EMPTY_CONTENT');
      expect((err as AppError).status).toBe(422);
      expect((err as AppError).hint).toBeTruthy();
    }
  });

  it('warns when the content is suspiciously short', () => {
    const r = extractContent({ html: '<body><article><h1>标题</h1><p>只有一句话的正文内容。只有一句话的正文内容。只有一句话的正文内容。</p></article></body>', url: URL_ });
    expect(r.warnings.map((w) => w.code)).toContain('CONTENT_SHORT');
  });

  it('drops javascript: links but keeps the link text', () => {
    const r = extractContent({ html: '<body><article><p><a href="javascript:alert(1)">危险链接</a> 正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文</p></article></body>', url: URL_ });
    expect(r.contentHtml).not.toContain('javascript:');
    expect(r.contentHtml).toContain('危险链接');
  });

  it('replaces iframes with their link and drops large inline data images with a warning', () => {
    const big = `data:image/png;base64,${'A'.repeat(5000)}`;
    const r = extractContent({
      html: `<body><article><p>${'正文'.repeat(60)}</p><iframe src="/embed/1"></iframe><img src="${big}" alt="截图"></article></body>`,
      url: URL_,
    });
    expect(r.contentHtml).toContain('https://docs.example.com/embed/1');
    expect(r.contentHtml).not.toContain('base64');
    expect(r.contentHtml).toContain('内嵌图片');
    expect(r.warnings.map((w) => w.code)).toContain('DATA_IMAGE_OMITTED');
  });
});
