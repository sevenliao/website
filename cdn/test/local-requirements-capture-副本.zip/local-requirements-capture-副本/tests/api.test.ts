import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import type { Express } from 'express';
import { createApp } from '../src/app.js';
import { PROJECT_ROOT } from '../src/config.js';
import { AppError } from '../src/utils/errors.js';
import { FakeBrowser, pageSnapshot, readFixture, silentLogger } from './helpers.js';

let tmp: string;
let browser: FakeBrowser;
let app: Express;

const H = { 'x-lrc-client': 'web' };

beforeEach(async () => {
  tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'lrc-api-'));
  browser = new FakeBrowser();
  app = createApp({
    config: { projectRoot: PROJECT_ROOT, requirementsDir: path.join(tmp, 'requirements') },
    browser,
    logger: silentLogger,
  });
});

afterEach(async () => {
  await fs.rm(tmp, { recursive: true, force: true });
});

function expectError(res: request.Response, status: number, code: string) {
  expect(res.status).toBe(status);
  expect(res.body.ok).toBe(false);
  expect(res.body.error.code).toBe(code);
  expect(typeof res.body.error.message).toBe('string');
  expect(res.body.error.message.length).toBeGreaterThan(0);
}

describe('health & static', () => {
  it('GET /api/health returns ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ ok: true, data: { status: 'ok' } });
  });

  it('serves the UI with a strict CSP', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('需求文档采集');
    expect(res.headers['content-security-policy']).toContain("script-src 'self'");
  });

  it('serves vendored marked and DOMPurify', async () => {
    expect((await request(app).get('/vendor/marked.esm.js')).status).toBe(200);
    expect((await request(app).get('/vendor/purify.es.mjs')).status).toBe(200);
    expect((await request(app).get('/vendor/../package.json')).status).not.toBe(200);
  });

  it('unknown API routes return the unified error format', async () => {
    expectError(await request(app).get('/api/nope'), 404, 'NOT_FOUND');
  });
});

describe('local-only protections', () => {
  it('rejects non-loopback Host headers (DNS rebinding)', async () => {
    expectError(await request(app).get('/api/health').set('Host', 'evil.example.com'), 403, 'FORBIDDEN_HOST');
  });

  it('rejects requests from foreign origins', async () => {
    const res = await request(app).post('/api/save').set(H).set('Origin', 'https://evil.example.com').send({ fileName: 'x', markdown: 'y' });
    expectError(res, 403, 'FORBIDDEN_ORIGIN');
  });

  it('rejects mutating requests without the client header', async () => {
    expectError(await request(app).post('/api/save').send({ fileName: 'x', markdown: 'y' }), 403, 'MISSING_CLIENT_HEADER');
  });

  it('rejects non-JSON bodies (simple cross-site form posts)', async () => {
    const res = await request(app).post('/api/save').set(H).type('form').send('fileName=x&markdown=y');
    expectError(res, 415, 'UNSUPPORTED_CONTENT_TYPE');
  });

  it('rejects malformed JSON', async () => {
    const res = await request(app).post('/api/save').set(H).set('Content-Type', 'application/json').send('{bad');
    expectError(res, 400, 'INVALID_JSON');
  });
});

describe('POST /api/browser/open', () => {
  it('rejects invalid URLs', async () => {
    for (const url of ['', 'nope', 'ftp://x.com', 'file:///etc/passwd']) {
      expectError(await request(app).post('/api/browser/open').set(H).send({ url }), 400, 'INVALID_URL');
    }
    expect(browser.running).toBe(false);
  });

  it('opens a valid URL and reports status', async () => {
    const res = await request(app).post('/api/browser/open').set(H).send({ url: 'https://docs.example.com/x' });
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ running: true, currentUrl: 'https://docs.example.com/x' });
    const status = await request(app).get('/api/browser/status');
    expect(status.body.data.running).toBe(true);
  });

  it('passes navigation errors through with hints', async () => {
    browser.openError = new AppError(502, 'DNS_ERROR', '无法解析目标域名（DNS 错误）。', { hint: '检查网络' });
    const res = await request(app).post('/api/browser/open').set(H).send({ url: 'https://nx.invalid/' });
    expectError(res, 502, 'DNS_ERROR');
    expect(res.body.error.hint).toBe('检查网络');
  });
});

describe('POST /api/capture', () => {
  it('returns 409 when the browser is not open', async () => {
    expectError(await request(app).post('/api/capture').set(H).send({}), 409, 'BROWSER_NOT_OPEN');
  });

  it('captures the current page into markdown with metadata and stats', async () => {
    browser.running = true;
    browser.url = 'https://docs.example.com/req/1';
    browser.snapshotResult = { main: pageSnapshot(readFixture('sample-doc.html')), frames: [], lastHttpStatus: 200, warnings: [] };
    const res = await request(app).post('/api/capture').set(H).send({ mode: 'auto', autoScroll: true });
    expect(res.status).toBe(200);
    const data = res.body.data;
    expect(data.title).toBe('订单退款需求');
    expect(data.sourceUrl).toBe('https://docs.example.com/req/1');
    expect(data.markdown).toMatch(/^---\ntitle: "订单退款需求"\nsource_url: "https:\/\/docs\.example\.com\/req\/1"\ncaptured_at: "\d{4}-\d{2}-\d{2}T/);
    expect(data.stats.tables).toBe(2);
    expect(data.suggestedFileName).toBe('订单退款需求');
    expect(data.warnings.map((w: { code: string }) => w.code)).toContain('COMPLEX_TABLE');
    expect(browser.snapshotCalls[0]).toEqual({ includeHidden: false, waitForNetworkIdle: true, autoScroll: true });
  });

  it('returns EMPTY_CONTENT for empty pages', async () => {
    browser.running = true;
    browser.snapshotResult = { main: pageSnapshot('<body><nav>菜单</nav></body>', { hasPasswordField: true }), frames: [], lastHttpStatus: 200, warnings: [] };
    const res = await request(app).post('/api/capture').set(H).send({});
    expectError(res, 422, 'EMPTY_CONTENT');
    expect(res.body.error.hint).toContain('登录');
  });

  it('warns about login pages and HTTP 403', async () => {
    browser.running = true;
    browser.snapshotResult = {
      main: pageSnapshot('<body><main><h1>请登录</h1><p>您没有权限访问此文档，请登录后重试。</p></main></body>', { hasPasswordField: true }),
      frames: [],
      lastHttpStatus: 403,
      warnings: [],
    };
    const res = await request(app).post('/api/capture').set(H).send({});
    const codes = res.body.data.warnings.map((w: { code: string }) => w.code);
    expect(codes).toEqual(expect.arrayContaining(['LOGIN_SUSPECTED', 'HTTP_ERROR_STATUS', 'CONTENT_SHORT']));
  });

  it('uses iframe content when the document lives inside a frame', async () => {
    browser.running = true;
    browser.snapshotResult = {
      main: pageSnapshot('<body><main><p>外壳页面外壳页面外壳页面外壳页面外壳页面外壳页面外壳页面外壳页面</p><iframe src="/f"></iframe></main></body>', { bodyTextLength: 40, iframeCount: 1 }),
      frames: [{ ...pageSnapshot(`<body><article><h1>真正的文档</h1><p>${'内容'.repeat(400)}</p></article></body>`, { bodyTextLength: 900 }), frameUrl: 'https://docs.example.com/f' }],
      lastHttpStatus: 200,
      warnings: [],
    };
    const res = await request(app).post('/api/capture').set(H).send({});
    expect(res.body.data.markdown).toContain('# 真正的文档');
    expect(res.body.data.warnings.map((w: { code: string }) => w.code)).toContain('IFRAME_CONTENT_USED');
  });

  it('validates capture options', async () => {
    browser.running = true;
    expectError(await request(app).post('/api/capture').set(H).send({ mode: 'magic' }), 400, 'INVALID_CAPTURE_OPTIONS');
    expectError(await request(app).post('/api/capture').set(H).send({ mode: 'selector', selector: '' }), 400, 'INVALID_SELECTOR');
  });
});

describe('POST /api/save', () => {
  it('checks the target path, saves, and protects existing files', async () => {
    const check = await request(app).post('/api/save/check').set(H).send({ fileName: 'doc' });
    expect(check.body.data).toMatchObject({ fileName: 'doc.md', exists: false });
    expect(check.body.data.absolutePath).toBe(path.join(tmp, 'requirements', 'doc.md'));

    const first = await request(app).post('/api/save').set(H).send({ fileName: 'doc', markdown: '# v1\n' });
    expect(first.status).toBe(200);
    expect(first.body.data).toMatchObject({ fileName: 'doc.md', overwritten: false });

    expectError(await request(app).post('/api/save').set(H).send({ fileName: 'doc', markdown: '# v2\n' }), 409, 'FILE_EXISTS');
    expect(await fs.readFile(path.join(tmp, 'requirements', 'doc.md'), 'utf8')).toBe('# v1\n');

    const over = await request(app).post('/api/save').set(H).send({ fileName: 'doc', markdown: '# v2\n', overwrite: true });
    expect(over.body.data.overwritten).toBe(true);
    expect(await fs.readFile(path.join(tmp, 'requirements', 'doc.md'), 'utf8')).toBe('# v2\n');
  });

  it('rejects path traversal through the API', async () => {
    for (const fileName of ['../../evil', '/etc/passwd', 'a/b']) {
      expectError(await request(app).post('/api/save').set(H).send({ fileName, markdown: 'x' }), 400, 'INVALID_FILE_NAME');
      expectError(await request(app).post('/api/save/check').set(H).send({ fileName }), 400, 'INVALID_FILE_NAME');
    }
  });

  it('ignores any client supplied directory field', async () => {
    const res = await request(app).post('/api/save').set(H).send({ fileName: 'safe', markdown: 'x', dir: '/tmp', path: '/etc/x.md' });
    expect(res.body.data.absolutePath).toBe(path.join(tmp, 'requirements', 'safe.md'));
  });

  it('rejects empty markdown', async () => {
    expectError(await request(app).post('/api/save').set(H).send({ fileName: 'a', markdown: '' }), 400, 'EMPTY_MARKDOWN');
  });

  it('downloads images through the browser session when requested', async () => {
    browser.running = true;
    browser.resources.set('https://e.com/a.png', { contentType: 'image/png', body: Buffer.from([1, 2, 3]) });
    const res = await request(app).post('/api/save').set(H).send({
      fileName: 'imgs',
      markdown: '![x](https://e.com/a.png) ![y](https://e.com/missing.png)',
      downloadImages: true,
    });
    expect(res.status).toBe(200);
    expect(res.body.data.assets.downloaded).toBe(1);
    expect(res.body.data.assets.failed).toEqual([{ url: 'https://e.com/missing.png', reason: 'HTTP 404' }]);
  });
});
