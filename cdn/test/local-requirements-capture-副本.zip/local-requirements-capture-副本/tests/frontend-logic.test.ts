import { describe, expect, it } from 'vitest';
import { diffLines, summarizeDiff } from '../public/lib/diff.js';
import { applyCapture, createEditorState, isDirty, markSaved, recaptureDecision } from '../public/lib/editor-state.js';
import { splitFrontMatter } from '../public/lib/frontmatter.js';

describe('unsaved edit protection', () => {
  it('a fresh editor is clean until the user types', () => {
    const s = createEditorState();
    expect(isDirty(s, '')).toBe(false);
    expect(recaptureDecision(s, '')).toBe('proceed');
    expect(isDirty(s, 'typed by hand')).toBe(true);
    expect(recaptureDecision(s, 'typed by hand')).toBe('confirm');
  });

  it('recapture proceeds when the editor still matches the last capture', () => {
    const s = applyCapture(createEditorState(), '# A', '');
    expect(isDirty(s, '# A')).toBe(false);
    expect(recaptureDecision(s, '# A')).toBe('proceed');
  });

  it('recapture asks for confirmation when the capture was edited and not saved', () => {
    const s = applyCapture(createEditorState(), '# A', '');
    expect(recaptureDecision(s, '# A edited')).toBe('confirm');
  });

  it('saving makes edited content safe again', () => {
    let s = applyCapture(createEditorState(), '# A', '');
    s = markSaved(s, '# A edited', '/x/a.md');
    expect(recaptureDecision(s, '# A edited')).toBe('proceed');
    expect(recaptureDecision(s, '# A edited again')).toBe('confirm');
    expect(s.savedPath).toBe('/x/a.md');
  });

  it('keeps the previous editor text for comparison after recapture', () => {
    let s = applyCapture(createEditorState(), 'v1', '');
    expect(s.previousText).toBeNull();
    s = applyCapture(s, 'v2', 'v1 edited');
    expect(s.previousText).toBe('v1 edited');
    expect(s.baseline).toBe('v2');
    expect(s.captureCount).toBe(2);
  });
});

describe('diffLines', () => {
  it('reports added and removed lines', () => {
    const ops = diffLines('a\nb\nc\nd', 'a\nB\nc\nd\ne');
    expect(ops).toEqual([
      { type: 'same', text: 'a' },
      { type: 'del', text: 'b' },
      { type: 'add', text: 'B' },
      { type: 'same', text: 'c' },
      { type: 'same', text: 'd' },
      { type: 'add', text: 'e' },
    ]);
    expect(summarizeDiff(ops)).toEqual({ added: 2, removed: 1, changed: true });
  });

  it('reports no change for identical text', () => {
    expect(summarizeDiff(diffLines('x\ny', 'x\ny')).changed).toBe(false);
  });
});

describe('splitFrontMatter', () => {
  it('separates YAML front matter from the body', () => {
    expect(splitFrontMatter('---\ntitle: "A"\n---\n\n# A\n')).toEqual({ frontMatter: 'title: "A"', body: '\n# A\n' });
    expect(splitFrontMatter('# no front matter')).toEqual({ frontMatter: null, body: '# no front matter' });
  });
});
