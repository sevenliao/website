import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { localizeImages } from '../src/services/asset-service.js';
import { FileService } from '../src/services/file-service.js';

let root: string;
let dir: string;
let service: FileService;

beforeEach(async () => {
  root = await fs.mkdtemp(path.join(os.tmpdir(), 'lrc-fs-'));
  dir = path.join(root, 'docs', 'requirements');
  service = new FileService(dir, root);
});

afterEach(async () => {
  await fs.rm(root, { recursive: true, force: true });
});

describe('FileService', () => {
  it('creates the directory and saves UTF-8 markdown', async () => {
    const result = await service.save({ fileName: '退款需求', markdown: '# 标题\n\n中文内容 ✓\n' });
    expect(result.fileName).toBe('退款需求.md');
    expect(result.absolutePath).toBe(path.join(dir, '退款需求.md'));
    expect(result.relativePath).toBe('docs/requirements/退款需求.md');
    expect(result.overwritten).toBe(false);
    expect(await fs.readFile(result.absolutePath, 'utf8')).toBe('# 标题\n\n中文内容 ✓\n');
    expect(result.bytes).toBe(Buffer.byteLength('# 标题\n\n中文内容 ✓\n'));
  });

  it('reports whether the target exists before saving', async () => {
    expect((await service.describeTarget('a')).exists).toBe(false);
    await service.save({ fileName: 'a', markdown: 'x' });
    const info = await service.describeTarget('a.md');
    expect(info.exists).toBe(true);
    expect(info.absolutePath).toBe(path.join(dir, 'a.md'));
  });

  it('refuses to overwrite an existing file without explicit confirmation', async () => {
    await service.save({ fileName: 'a', markdown: 'original' });
    await expect(service.save({ fileName: 'a', markdown: 'new' })).rejects.toMatchObject({ code: 'FILE_EXISTS', status: 409 });
    await expect(service.save({ fileName: 'a', markdown: 'new', overwrite: 'true' })).rejects.toMatchObject({ code: 'FILE_EXISTS' });
    expect(await fs.readFile(path.join(dir, 'a.md'), 'utf8')).toBe('original');
  });

  it('overwrites only when overwrite === true', async () => {
    await service.save({ fileName: 'a', markdown: 'original' });
    const result = await service.save({ fileName: 'a', markdown: 'new', overwrite: true });
    expect(result.overwritten).toBe(true);
    expect(await fs.readFile(path.join(dir, 'a.md'), 'utf8')).toBe('new');
    const leftovers = (await fs.readdir(dir)).filter((f) => f.endsWith('.tmp'));
    expect(leftovers).toEqual([]);
  });

  it('rejects path traversal and never writes outside the directory', async () => {
    for (const fileName of ['../escape', '../../escape', '/tmp/escape', 'sub/escape']) {
      await expect(service.save({ fileName, markdown: 'x' })).rejects.toMatchObject({ code: 'INVALID_FILE_NAME' });
    }
    await expect(fs.access(path.join(root, 'docs', 'escape.md'))).rejects.toThrow();
  });

  it('refuses to write through a symlink', async () => {
    await fs.mkdir(dir, { recursive: true });
    const outside = path.join(root, 'outside.md');
    await fs.writeFile(outside, 'outside');
    await fs.symlink(outside, path.join(dir, 'link.md'));
    await expect(service.save({ fileName: 'link', markdown: 'x', overwrite: true })).rejects.toMatchObject({ code: 'PATH_OUTSIDE_ALLOWED_DIR' });
    expect(await fs.readFile(outside, 'utf8')).toBe('outside');
  });

  it('rejects empty markdown', async () => {
    await expect(service.save({ fileName: 'a', markdown: '   ' })).rejects.toMatchObject({ code: 'EMPTY_MARKDOWN' });
    await expect(service.save({ fileName: 'a', markdown: 123 })).rejects.toMatchObject({ code: 'EMPTY_MARKDOWN' });
  });

  it('maps write failures to FILE_WRITE_FAILED', async () => {
    await fs.mkdir(dir, { recursive: true });
    await fs.chmod(dir, 0o500);
    try {
      await expect(service.save({ fileName: 'ro', markdown: 'x' })).rejects.toMatchObject({ code: 'FILE_WRITE_FAILED' });
    } finally {
      await fs.chmod(dir, 0o700);
    }
  });

  it('downloads images to assets when requested and keeps failures as original URLs', async () => {
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47]);
    const fetcher = async (url: string) => {
      if (url.endsWith('ok.png')) return { contentType: 'image/png', body: png };
      if (url.endsWith('login.png')) return { contentType: 'text/html; charset=utf-8', body: Buffer.from('<html>login</html>') };
      throw new Error('HTTP 403');
    };
    const md = '![a](https://e.com/ok.png)\n\n![b](https://e.com/login.png)\n\n![c](https://e.com/denied.png "t")';
    const result = await service.save({ fileName: 'img doc', markdown: md, downloadImages: true }, fetcher);
    expect(result.assets?.downloaded).toBe(1);
    expect(result.assets?.failed.map((f) => f.url)).toEqual(['https://e.com/login.png', 'https://e.com/denied.png']);
    expect(result.warnings.map((w) => w.code)).toContain('IMAGE_DOWNLOAD_FAILED');
    const saved = await fs.readFile(result.absolutePath, 'utf8');
    expect(saved).toMatch(/!\[a\]\(assets\/img%20doc\/[0-9a-f]{16}\.png\)<!-- original-src: https:\/\/e\.com\/ok\.png -->/);
    expect(saved).toContain('![b](https://e.com/login.png)');
    expect(saved).toContain('![c](https://e.com/denied.png "t")');
    const files = await fs.readdir(path.join(dir, 'assets', 'img doc'));
    expect(files).toHaveLength(1);
  });

  it('keeps CJK asset paths readable and reports clean failure reasons', async () => {
    const fetcher = async (url: string) => {
      if (url.endsWith('denied.png')) throw new Error('apiRequestContext.get: socket hang up\nCall log:\n  - → GET https://e.com/denied.png\n  - cookie: secret');
      return { contentType: 'image/png', body: Buffer.from([1]) };
    };
    const result = await service.save(
      { fileName: '退款需求', markdown: '![流程](https://e.com/ok.png) ![x](https://e.com/denied.png)', downloadImages: true },
      fetcher,
    );
    const saved = await fs.readFile(result.absolutePath, 'utf8');
    expect(saved).toMatch(/!\[流程\]\(assets\/退款需求\/[0-9a-f]{16}\.png\)/);
    expect(result.assets?.failed).toEqual([{ url: 'https://e.com/denied.png', reason: 'socket hang up' }]);
  });
});

describe('localizeImages', () => {
  it('refuses an assets directory outside the markdown directory', async () => {
    await expect(
      localizeImages('x', { markdownDir: '/tmp/a', assetsDir: '/tmp/b', fetcher: async () => ({ contentType: '', body: Buffer.alloc(0) }) }),
    ).rejects.toThrow();
  });
});
