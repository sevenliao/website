import { describe, expect, it } from 'vitest';
import { mapNavigationError } from '../src/services/browser-manager.js';

describe('mapNavigationError', () => {
  it.each([
    ['page.goto: net::ERR_NAME_NOT_RESOLVED at https://x/', 'DNS_ERROR'],
    ['page.goto: net::ERR_CERT_AUTHORITY_INVALID at https://x/', 'TLS_ERROR'],
    ['page.goto: net::ERR_CERT_DATE_INVALID at https://x/', 'TLS_ERROR'],
    ['page.goto: net::ERR_SSL_PROTOCOL_ERROR at https://x/', 'TLS_ERROR'],
    ['page.goto: net::ERR_CONNECTION_REFUSED at http://x/', 'NETWORK_ERROR'],
    ['page.goto: net::ERR_INTERNET_DISCONNECTED at http://x/', 'NETWORK_ERROR'],
    ['page.goto: Timeout 45000ms exceeded.', 'NAVIGATION_TIMEOUT'],
    ['page.goto: net::ERR_UNSAFE_PORT at http://x:1/', 'UNSAFE_PORT'],
    ['page.goto: net::ERR_ABORTED at http://x/', 'NAVIGATION_ABORTED'],
    ['page.goto: Target page, context or browser has been closed', 'BROWSER_CLOSED'],
    ['something unexpected', 'NAVIGATION_FAILED'],
  ])('%s -> %s', (message, code) => {
    const err = mapNavigationError(new Error(message), 'https://x/?token=secret', 45_000);
    expect(err.code).toBe(code);
    expect(err.hint).toBeTruthy();
    expect(JSON.stringify(err.details ?? {})).not.toContain('secret');
  });
});
