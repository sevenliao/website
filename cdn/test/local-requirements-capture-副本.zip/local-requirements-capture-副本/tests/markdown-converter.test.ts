import { describe, expect, it } from 'vitest';
import { buildMarkdownDocument, htmlToMarkdown } from '../src/services/markdown-converter.js';

describe('htmlToMarkdown', () => {
  it('keeps heading levels and paragraphs on separate lines', () => {
    const { markdown } = htmlToMarkdown('<h1>标题</h1><p>第一段</p><h2>子标题</h2><p>第二段</p><h3>三级</h3><p>第三段</p>');
    expect(markdown).toBe('# 标题\n\n第一段\n\n## 子标题\n\n第二段\n\n### 三级\n\n第三段');
  });

  it('keeps nested ordered and unordered lists', () => {
    const { markdown } = htmlToMarkdown('<ul><li>A<ul><li>A1</li><li>A2<ol><li>x</li><li>y</li></ol></li></ul></li><li>B</li></ul>');
    expect(markdown).toBe('- A\n  - A1\n  - A2\n    1. x\n    2. y\n- B');
  });

  it('respects the start attribute of ordered lists', () => {
    const { markdown } = htmlToMarkdown('<ol start="3"><li>c</li><li>d</li></ol>');
    expect(markdown).toBe('3. c\n4. d');
  });

  it('converts simple tables to GFM tables and escapes pipes', () => {
    const { markdown, warnings } = htmlToMarkdown(
      '<table><thead><tr><th>字段</th><th>说明</th></tr></thead><tbody><tr><td>a|b</td><td>第一行<br>第二行</td></tr><tr><td>c</td></tr></tbody></table>',
    );
    expect(markdown).toBe('| 字段 | 说明 |\n| --- | --- |\n| a\\|b | 第一行<br>第二行 |\n| c |  |');
    expect(warnings).toEqual([]);
  });

  it('keeps tables with merged cells as cleaned HTML and warns', () => {
    const { markdown, warnings } = htmlToMarkdown(
      '<table class="x" style="color:red"><tr><td colspan="2" onclick="evil()">合并</td></tr><tr><td>A</td><td>B</td></tr></table>',
    );
    expect(markdown).toContain('<td colspan="2">合并</td>');
    expect(markdown).not.toContain('onclick');
    expect(markdown).not.toContain('style=');
    expect(warnings.map((w) => w.code)).toContain('COMPLEX_TABLE');
  });

  it('keeps original links and images with alt text', () => {
    const { markdown } = htmlToMarkdown(
      '<p>见 <a href="https://example.com/spec?a=1">规范</a></p><p><img src="https://example.com/a.png" alt="流程图" title="图1"></p>',
    );
    expect(markdown).toContain('[规范](https://example.com/spec?a=1)');
    expect(markdown).toContain('![流程图](https://example.com/a.png "图1")');
  });

  it('keeps blockquotes and fenced code blocks with language', () => {
    const { markdown } = htmlToMarkdown(
      '<blockquote><p>注意事项</p></blockquote><pre><code class="language-ts">const a = 1;\nconsole.log(a);</code></pre><pre>plain pre</pre>',
    );
    expect(markdown).toContain('> 注意事项');
    expect(markdown).toContain('```ts\nconst a = 1;\nconsole.log(a);\n```');
    expect(markdown).toContain('```\nplain pre\n```');
  });

  it('uses a longer fence when code contains backticks', () => {
    const { markdown } = htmlToMarkdown('<pre><code>```inner```</code></pre>');
    expect(markdown).toContain('````\n```inner```\n````');
  });

  it('drops script, style and interactive controls', () => {
    const { markdown } = htmlToMarkdown('<p>正文</p><script>alert(1)</script><style>p{}</style><button>点我</button><select><option>x</option></select>');
    expect(markdown).toBe('正文');
  });

  it('renders task list checkboxes', () => {
    const { markdown } = htmlToMarkdown('<ul><li><input type="checkbox" checked> 完成</li><li><input type="checkbox"> 未完成</li></ul>');
    expect(markdown).toBe('- [x] 完成\n- [ ] 未完成');
  });

  it('keeps media as links instead of silently dropping them', () => {
    const { markdown } = htmlToMarkdown('<video src="https://example.com/v.mp4"></video>');
    expect(markdown).toContain('[视频](https://example.com/v.mp4)');
  });

  it('does not collapse a document into a single line', () => {
    const { markdown } = htmlToMarkdown('<div><div>块一</div><div>块二</div></div><p>段落</p>');
    expect(markdown.split('\n').length).toBeGreaterThan(1);
  });
});

describe('buildMarkdownDocument', () => {
  it('writes front matter from real metadata and adds a title heading when missing', () => {
    const doc = buildMarkdownDocument(
      { title: '需求 "A"', sourceUrl: 'https://e.com/x', capturedAt: '2026-01-01T00:00:00.000Z' },
      '正文',
    );
    expect(doc).toBe('---\ntitle: "需求 \\"A\\""\nsource_url: "https://e.com/x"\ncaptured_at: "2026-01-01T00:00:00.000Z"\n---\n\n# 需求 "A"\n\n正文\n');
  });

  it('omits unknown fields and does not duplicate an existing H1', () => {
    const doc = buildMarkdownDocument({ title: '', sourceUrl: 'https://e.com', capturedAt: '2026' }, '# 已有标题\n\n内容');
    expect(doc).not.toContain('title:');
    expect(doc.match(/^# /gm)?.length).toBe(1);
  });
});
