import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { BrowserController, FetchedResource } from '../src/services/browser-manager.js';
import type { BrowserSnapshotResult, BrowserStatus, PageSnapshot, SnapshotOptions } from '../src/types/index.js';
import { AppError } from '../src/utils/errors.js';

export const FIXTURES = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures');

export function readFixture(name: string): string {
  return fs.readFileSync(path.join(FIXTURES, name), 'utf8');
}

export function pageSnapshot(html: string, overrides: Partial<PageSnapshot> = {}): PageSnapshot {
  return {
    url: 'https://docs.example.com/req/1',
    title: '订单退款需求 - 示例文档中心',
    ogTitle: '',
    html,
    readyState: 'complete',
    bodyTextLength: 1000,
    hasPasswordField: false,
    iframeCount: 0,
    canvasCount: 0,
    largeCanvasCount: 0,
    shadowRootCount: 0,
    hiddenRemovedCount: 0,
    ...overrides,
  };
}

/** In-memory BrowserController used by API tests so they never launch Chromium. */
export class FakeBrowser implements BrowserController {
  running = false;
  url: string | null = null;
  snapshotResult: BrowserSnapshotResult | null = null;
  openError: AppError | null = null;
  snapshotCalls: SnapshotOptions[] = [];
  resources = new Map<string, FetchedResource>();

  async open(url: URL): Promise<BrowserStatus> {
    if (this.openError) throw this.openError;
    this.running = true;
    this.url = url.href;
    return this.status();
  }

  async status(): Promise<BrowserStatus> {
    return {
      running: this.running,
      launching: false,
      navigating: false,
      capturing: false,
      headless: true,
      pageCount: this.running ? 1 : 0,
      currentUrl: this.url,
      title: this.running ? 'Fake' : null,
      readyState: this.running ? 'complete' : null,
      navigationState: this.running ? 'loaded' : 'idle',
      lastHttpStatus: this.running ? 200 : null,
      lastError: null,
      loginSuspected: false,
    };
  }

  async snapshot(options: SnapshotOptions): Promise<BrowserSnapshotResult> {
    this.snapshotCalls.push(options);
    if (!this.running || !this.snapshotResult) {
      throw new AppError(409, 'BROWSER_NOT_OPEN', '浏览器尚未打开或没有可采集的页面。');
    }
    return this.snapshotResult;
  }

  async fetchResource(url: string): Promise<FetchedResource> {
    const r = this.resources.get(url);
    if (!r) throw new Error('HTTP 404');
    return r;
  }

  async close(): Promise<void> {
    this.running = false;
    this.url = null;
  }
}

export const silentLogger = { info: () => {}, warn: () => {}, error: () => {} };
