import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { normalizeMarkdownFileName, resolveInsideDirectory, suggestFileName } from '../src/utils/path-validator.js';
import { redactUrl, validateDocumentUrl } from '../src/utils/url-validator.js';

describe('validateDocumentUrl', () => {
  it('accepts http and https URLs', () => {
    expect(validateDocumentUrl('https://docs.example.com/a?b=1').href).toBe('https://docs.example.com/a?b=1');
    expect(validateDocumentUrl('  http://127.0.0.1:8080/x ').hostname).toBe('127.0.0.1');
  });

  it.each([
    ['', 'INVALID_URL'],
    ['not a url', 'INVALID_URL'],
    ['docs.example.com/page', 'INVALID_URL'],
    ['ftp://example.com/file', 'INVALID_URL'],
    ['file:///etc/passwd', 'INVALID_URL'],
    ['javascript:alert(1)', 'INVALID_URL'],
    ['https://user:pass@example.com/', 'INVALID_URL'],
  ])('rejects %j', (input, code) => {
    expect(() => validateDocumentUrl(input)).toThrowError(expect.objectContaining({ code, status: 400 }));
  });

  it('rejects non-string input', () => {
    expect(() => validateDocumentUrl(42)).toThrowError(expect.objectContaining({ code: 'INVALID_URL' }));
  });

  it('redacts query strings for logs', () => {
    expect(redactUrl('https://e.com/doc?token=secret#x')).toBe('https://e.com/doc?…');
  });
});

describe('normalizeMarkdownFileName', () => {
  it('adds a single .md suffix and keeps CJK characters', () => {
    expect(normalizeMarkdownFileName('退款需求')).toBe('退款需求.md');
    expect(normalizeMarkdownFileName('refund.md')).toBe('refund.md');
    expect(normalizeMarkdownFileName('refund.MD')).toBe('refund.md');
    expect(normalizeMarkdownFileName('v1.2-spec')).toBe('v1.2-spec.md');
  });

  it.each([
    '../secret',
    '..\\secret',
    '../../etc/passwd',
    'sub/dir',
    'sub\\dir',
    '/etc/passwd',
    'C:\\Windows\\x',
    'a..b',
    '.env',
    '.md',
    'con',
    'name?',
    'a\u0000b',
    '   ',
    'x'.repeat(200),
  ])('rejects %j', (input) => {
    expect(() => normalizeMarkdownFileName(input)).toThrowError(expect.objectContaining({ code: 'INVALID_FILE_NAME' }));
  });
});

describe('resolveInsideDirectory', () => {
  const base = path.resolve('/tmp/requirements');
  it('allows files inside the directory', () => {
    expect(resolveInsideDirectory(base, 'a.md')).toBe(path.join(base, 'a.md'));
  });
  it('rejects escapes', () => {
    expect(() => resolveInsideDirectory(base, '../a.md')).toThrowError(expect.objectContaining({ code: 'PATH_OUTSIDE_ALLOWED_DIR' }));
    expect(() => resolveInsideDirectory(base, '/etc/passwd')).toThrowError(expect.objectContaining({ code: 'PATH_OUTSIDE_ALLOWED_DIR' }));
    expect(() => resolveInsideDirectory(base, '.')).toThrowError(expect.objectContaining({ code: 'PATH_OUTSIDE_ALLOWED_DIR' }));
  });
});

describe('suggestFileName', () => {
  it('builds a safe name from a title', () => {
    expect(suggestFileName('订单退款需求 V1.2 / 草稿')).toBe('订单退款需求-v1-2-草稿');
    expect(suggestFileName('')).toBe('requirement');
    expect(suggestFileName('../..')).toBe('requirement');
  });
  it('produces names accepted by the validator', () => {
    for (const t of ['A: B?', '  ..hidden', 'CON', '多 空格   标题']) {
      expect(() => normalizeMarkdownFileName(suggestFileName(t))).not.toThrow();
    }
  });
});
